function [texStr,stimData] = CLVirtualObjectShadowingPositionOnly(Q)

    % Created May 11 2021
    
    % May 13 2021
    % Adding in closed loop background feature
    
    % Based on CLVirtualObjectShadowing
    % Do not update size of the object; fix it at the initial angular size
    % Update only position with the real closed loop way
   
    % Present a rectangular object with physical dimensions, whose position
    % is synced to the fly's walking (turning is ignored)
    % More specifically, if we define the position of the fly at time t as
    % r(t) = [0, y(t)], the position of the object is determined as
    % s(t) = [X0 + ay(t), Y0 + by(t), Z0]
    % Gain in z is disabled because it makes things too complicated and I
    % probably would not use it anyways
    
    % Object is assumed to be a circular column (changed 3/29/21)
    
    % This function assumes there is only one fly being run per experiment
    % at position 1 unless explicitly provided with the number of the flies
    % through the comment section ('condstr'). If condstr is set to some
    % number larger than 1, this function assumes there are flies loaded on
    % position 1 thorugh N, and randomly decide one of them to be the lead
    % fly in each epoch.
    
    % Not sure if this works when the plane is strongly oriented and the
    % side of the obejct is reveresed
    
    %% Parameters
    p = Q.stims.currParam;                               % Struct with current epoch stimulus parameters
    f = Q.timing.framenumber - Q.timing.framelastchange; % Relative frame number
    stimData = Q.stims.stimData;                         % Struct to communicate between multiple calls of this function
    
    % degree per pixel (usually fixed at 1)
    numDeg = p.numDeg;
    % define output bitmap dimensions
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    cH = Q.cylinder.cylinderHeight;
    cR = Q.cylinder.cylinderRadius;
    
    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.
    
    %% Beginnig of epoch initialization
    if f==0 
        % Reset the current position of the fly
        stimData.flypos = 0;
        % Read how many flies are being run (if not specified, 1)
        nFly = max(1,str2double(Q.condstr));
        % Decide which fly to use as the lead fly randomly
        stimData.leadFly = randi(nFly);
    end
    
    %% Closed loop read-outs
    % Get flies' walking response
    [~,walkingSpeed,stimData] = GetFlyResponse(Q.timing.framenumber,Q.stims.duration,Q.flyTimeline.curFlyStates,stimData);
    % rewrite stimData.cl(1) (GetFlyResponse assign lead fly but we ignore that 
    % -- stmData.cl is saved in stimData.mat -- see WriteStimData())
    stimData.cl(1) = stimData.leadFly;
    % We only care lead fly walking speed
    walkingSpeed = walkingSpeed(stimData.leadFly); % this is in mm/s unit (see FlyTimeline)
    flypos = stimData.flypos;
    
    %% Stimulus parameters
    fPU   = p.framesPerUp;  % frames per 60Hz update
    mLum  = p.mLum;         % mean luminance
    obC   = p.objectContrast; 
    
    % Open loop stuff -- if openLoopForwardVelocity is specified, ignore
    % flies' walking speed and do open loop (just for checking how stimulus
    % looks)
    OLFlag = 0;
    OLV = [];
    if isfield(p,'openLoopForwardVelocity')
        OLV = p.openLoopForwardVelocity;
        OLFlag = 1;
    end
    if isempty(OLV)
        OLFlag = 0;
    end
    % Overwrite closed loop related fields
    if OLFlag == 1
        walkingSpeed = OLV;
        stimData.cl(1) = 0; % no fly was the lead
    end
    
    % object initial position (in mm)
    X0 = p.initialX;
    Y0 = p.initialY;
    Z0 = p.initialZ;
    
    % object movement gain (in mm)
    gX = p.xGain;
    gY = p.yGain;
    
    % object size (in mm)
    obW = p.objectWidth; % diameter
    obH = p.objectHeight;
    
    % Calculate the (initial) visual angle of the object
    R0 = sqrt(X0^2 + Y0^2);
    obAngHalf = atand(abs(obW/2/R0)); % apparent "radius" of the object (in visual angles)
    
    % background related ones
    % Set closedLoopBackgroundFlag = 1 if you are using background
    if isfield(p,'closedLoopBackgroundFlag')
        % This two step if statements allow you to include epochs with and
        % without CL background in a single paramfile
        % If this flag is 1, we assume other BG related fields as well
        clbgFlag = p.closedLoopBackgroundFlag;
        if clbgFlag
            % contrast as in [-1,1]
            bgCMax = p.backgroundMaxContrast;
            bgCMin = p.backgroundMinContrast;
            % checker can be binary, ternary... (drawn from unifrom distribution)
            bgSteps = p.backgroundSteps;      % integer (most likely 2)
            bgReso  = p.backgroundResolution; % in degrees (not pixel!)
            % for feedback
            bgGain  = p.backgroundGain;       % (deg/s)/(mm/s) = deg/mm
            % When the observer moves forward at velocity v, the angular velocity
            % of the object to the side at the distance d is v/d (rad/s)
            % Thus, gain of the background is inverse of the distance of the side
            % wall
        end
    else
        clbgFlag = 0;
    end
    
    if ~clbgFlag
        bgC   = p.backgroundContrast; % We only use the scaler uniform BG if we are not doing closed loop BG stuff
    end
    
    %% Prepare background if this is the first frame
    if clbgFlag
        if f==0 
            % Because we do not want to be generating new checker patterns in
            % every frame, we will just prepare two panels with 180 azimuthal
            % degree wide, and loop that
            numPxX = ceil(sizeX/numDeg/bgReso/2); % divide by 2 because left/right walls
            numPxY = ceil(sizeY/numDeg/bgReso);
            % create checker
            checker_orig = randi(bgSteps,[numPxY,numPxX,2]); % third dim. for left/right walls
            % adjust range
            checker_orig = (checker_orig-1)/(bgSteps-1)*(bgCMax-bgCMin) + bgCMin;
            bgPattern = imresize(checker_orig,bgReso/numDeg,'box');
            stimData.checker_expanded = bgPattern;
        else
            % if this is not the first frame, read the background
            bgPattern = stimData.checker_expanded;
        end
    end
    
    %% Update of visual stimuli and drawing
    bitMap = zeros(sizeY,sizeX,fPU);
    for ff = 1:fPU
        %% Object
        % Prepare the matrix to draw things into
        objectMask = zeros(sizeY,sizeX);
        % Update fly position (in mm)
        flypos = flypos + walkingSpeed/60/fPU;
 
        % Calculate the object position in fly centered coordinate (in XY)
        objpos = [X0+gX*flypos, Y0+(gY-1)*flypos];

        % Covnert position to visual angle
        
        edge1ang = 270-atan2d(objpos(2),objpos(1))-obAngHalf;
        edge2ang = 270-atan2d(objpos(2),objpos(1))+obAngHalf;
        
        edge1ind = min(max(round(mod(edge1ang,360)/numDeg),1),sizeX);
        edge2ind = min(max(round(mod(edge2ang,360)/numDeg),1),sizeX);
        
        % Calculate vertical edges
        topang = atan2d(Z0-obH/2,R0);
        botang = atan2d(Z0+obH/2,R0);
        
        % convert angles to index
        topind = max(round(sizeY/2*(2*cR*tand(topang)/cH + 1)),1);
        botind = min(round(sizeY/2*(2*cR*tand(botang)/cH + 1)),sizeY);
        
        % object mask
        objectMask(topind:botind,edge1ind:edge2ind) = 1;        
        
        if clbgFlag
            %% background 
            % convert fly position into angular position into bitmap pixels
            flyshiftind = round(flypos*bgGain/numDeg);
            % When fly moves forward, flyshiftind>0, and positive circshift
            % in 2nd dimension makes the content of the matrix move rightward
            bgShifted = circshift(bgPattern,[0,flyshiftind,0]);
            % unfold the checker
            bgUnfolded = [fliplr(bgShifted(:,:,1)),bgShifted(:,:,2)];
            % trimming
            % In case expanded checker matrix is larger than the sizeX (because
            % bg resolution did not cleanly divide sizeX etc.)
            numTrimmedPixelX = size(bgUnfolded,2)-sizeX;
            bgTrimmed = bgUnfolded(1:sizeY,(1:sizeX)+round(numTrimmedPixelX/2));
        else
            bgTrimmed = bgC; % scaler contrasts
        end
        
        % fill in
        bitMap(:,:,ff) = objectMask*obC + (1-objectMask).*bgTrimmed;
        
        % Save fly position (object position can be easily recovered within
        % the analysis function so I'm not saving it)
        stimData.mat(ff) = flypos;
    end
    
    % pass the position variable to the next loop
    stimData.flypos  = flypos;
    
    % convert contrast to luminance
    bitMap =  mLum * ( 1 + bitMap );
    
    % convert bitmap to a PTB texture
    texStr.tex = CreateTexture(bitMap,Q);
end
