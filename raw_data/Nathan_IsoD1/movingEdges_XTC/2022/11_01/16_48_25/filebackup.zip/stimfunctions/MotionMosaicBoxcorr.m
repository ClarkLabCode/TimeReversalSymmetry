function [texStr,stimData] = MotionMosaicBoxcorr(Q)

    % Created Aug 5 2020 by RT
    % introduce spatial correlation into pattern by box car filtering
    
    % Added mirroring feature Mar 2 2020 by RT
    % shouldn't affect previously created stimulus
    
    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %% Stimulus Parameters %%  
    %% System stuffs
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    %% basics
    duration = p.duration;
    numDeg = p.numDeg;
    sizeX = round(360/numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    fPU = p.framesPerUp;
    mlum=p.mLum;

    %% Texture related
    % spatial
    fResoDeg = p.foregroundResolution;  % in degrees, should be integer multiplication of numDeg
    bResoDeg = p.backgroundResolution;  % in degrees, should be integer multiplication of numDeg
    mResoDeg = p.mosaicResolution;   % in degrees, should be integer multiplication of numDeg
    
    fResoPx = round(fResoDeg/numDeg);
    bResoPx = round(bResoDeg/numDeg);
    mResoPx = round(mResoDeg/numDeg);
    
    fSize = ceil([sizeY,sizeX]/fResoPx); % the size of random matrices to be generated
    bSize = ceil([sizeY,sizeX]/bResoPx); % the size of random matrices to be generated
    mSize = ceil([sizeY,sizeX]/mResoPx); 
    
    bcs = p.boxcarSizes; % background and foreground
    
    fBG   = p.fractionBackground; % 0~1, 1 = all background (moving), 0 = all foreground
    
    % intensity related
    cont = p.maxContrast;   % 0~1 - can be 2D if you want different contrasts for fore/backgorunds
    cS   = p.contrastSteps; % beaware of the bit depth
    
    % temporal
    dR   = p.velocities; % deg/s, 2D matrix
    fF   = p.flickerFrequency; % of foreground
    fPC  = min(60/fF*fPU,duration*2*fPU);
    
    % added feature
    if isfield(p,'isMirrored')
        isMirrored = p.isMirrored;
        if isempty(isMirrored); isMirrored = 1; end % in case another stimfunciton had a field with the same name
    else
        isMirrored = 0;
    end
    
    % create the mosaic pattern, fore/background textures
    % make matrices that are slightly larger than sizeX, sizeY and
    % crop them properly
    if f == 0
        % generate uniform random pattern
        % bring the range into [-1, 1] because zero padding in conv2
        % otherwise brings down contrast at edges
        bgMatOrig = rand(bSize);
        fgMatOrig = rand(fSize);
        % smear the pattern 
        if bcs(1)>1
            bgMatOrig = bgMatOrig*2-1;
            bgMatOrig = conv2(bgMatOrig,ones(bcs(1))/(bcs(1)^2),'same');
            bgMatOrig = bgMatOrig/2+0.5;
        end
        if bcs(2)>1
            fgMatOrig = fgMatOrig*2-1;
            fgMatOrig = conv2(fgMatOrig,ones(bcs(2))/(bcs(2)^2),'same');
            fgMatOrig = fgMatOrig/2+0.5;
        end
        
        % threshold
        bgMatOrig = -1 + 2*floor(bgMatOrig * cS)/(cS-1);
        fgMatOrig = -1 + 2*floor(fgMatOrig * cS)/(cS-1);
        % expand the pattern
        bgMatExpanded = cont(end)*imresize(bgMatOrig,bResoPx,'box');
        fgMatExpanded = cont(1)*imresize(fgMatOrig,fResoPx,'box');
        
        % create the mosaic
        mMatOrig = rand(mSize)<=fBG;
        mMatExpanded = imresize(mMatOrig,mResoPx,'box');
        mMat = mMatExpanded(1:sizeY,1:sizeX); % trimming
        
        
        bgPos = [0,0]; % position of background
        
        % don't trim tMat here because it should be trimmed after moving it
        stimData.bgMatExpanded = bgMatExpanded;
        stimData.fgMatExpanded = fgMatExpanded;
        stimData.mMat = mMat;
        stimData.bgPos = bgPos;
    else
        bgMatExpanded = stimData.bgMatExpanded;
        fgMatExpanded = stimData.fgMatExpanded;
        mMat = stimData.mMat;
        bgPos = stimData.bgPos;
    end
    
    
    bitMap = zeros(sizeY,sizeX,fPU);     
    for cc = 0:1:fPU-1
        % move the background
        bgPos = bgPos + dR/60/fPU;
        temp1 = circshift(bgMatExpanded,round([bgPos(2),bgPos(1)]/numDeg));
        bg = temp1(1:sizeY,1:sizeX); % trimming
        
        % update the foreground
        if mod(f*fPU+cc,fPC)==0 && f+cc/fPU>0
            fgMatOrig = rand(fSize);
            % smear the pattern 
            if bcs(2)>1
                fgMatOrig = conv2(fgMatOrig,ones(bcs(2))/(bcs(2)^2),'same');
            end
            % threshold
            fgMatOrig = -1 + 2*floor(fgMatOrig * cS)/cS;
            % expand the pattern
            fgMatExpanded = imresize(fgMatOrig,fResoPx,'box');
        end
        
        fg = fgMatExpanded(1:sizeY,1:sizeX); % trimming
        % added feature
        if isMirrored == 1
            bg(:,(sizeX/2+1):end) = bg(:,(sizeX/2):-1:1);
        end
        bitMap(:,:,cc+1) = bg.*mMat+fg.*(1-mMat);
    end
    stimData.bgPos = bgPos;
    bitMap=mlum*(1+bitMap); % contrast to luminance conversion
    texStr.tex = CreateTexture(bitMap,Q);
end
