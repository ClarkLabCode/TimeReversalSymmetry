function [texStr,stimData] = MultipleTargets(Q)

    % last update Aug 20 2018

    % This function is to present an arbitrary number of moving/flickering targets
    
    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %when choosing noise values for the sine wave make sure that:
    %noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
    %this insures that 3 std of the noise keeps you below a luminence of 1

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;
    
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % 9/14 using numDeg = 1 - maybe go high reso?
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    
    %% Input parameters
    %% things that concern the entire presentation
    
    fPU = p.framesPerUp;
    duration = p.duration; % frames
    mLum = p.mLum;
    
    if isfield(p, 'backgroundContrast')
        bkgdContrast = p.backgroundContrast;
        if isempty(bkgdContrast); bkgdContrast = 0; end
    else
        bkgdContrast = 0;
    end
    
    if isfield(p, 'testgrid')
        testgrid = p.testgrid;
    else
        testgrid = 0;
    end
    
    %% things that concern targets
    
    % center of presentation - all spatial parameters are relative to this
    % the center can be moved by entering numbers in the comment section of
    % the input GUI (otherwise its gonna be set at the actual center)
    
    if f==0
        if ~isempty(Q.condstr) 
            onlineloc = strsplit(Q.condstr,',');
            midX = str2num(onlineloc{1});
            midY = str2num(onlineloc{2});
        else
            midX = 180;
            midY = 0;
        end
        stimData.midX = midX;
        stimData.midY = midY;
    else
        midX = stimData.midX;
        midY = stimData.midY;
    end
    
    
    % sizes (vector)
    tW = p.targetW; % deg 
    tH = p.targetH; % deg
    % kinetics parameters
    % relative locations (initial) (vector)
    rX = p.relativeX; % deg
    rY = p.relativeY; % deg
    % velocities (vector)
    dX = p.dX; % deg/s
    dY = p.dY; % deg/s
    
    % timings (vector) 
    tApp  = p.targetAppear; % updates (1/60s)
    tDapp = p.targetDisappear; % !!the target disappears at the beginning of this frame!!
    % color (-1~1)
    cont = p.targetContrast;
    % flicker related parameters
    fFreq  = p.flickerFrequency;    % in Hz
    fPhase = p.flickerPhase; % in degrees

    %% match the length of target paramters
    tNum = max([length(tW),length(tH),length(rX),length(rY),...
                length(dX),length(dY),length(tApp),length(tDapp),...
                length(cont),length(fFreq),length(fPhase)]);
    % in case any paramter is shorter than tNum, fill it with the last value
    tW(end+1:tNum) = tW(end);
    tH(end+1:tNum) = tH(end);
    rX(end+1:tNum) = rX(end);
    rY(end+1:tNum) = rY(end);
    dX(end+1:tNum) = dX(end);
    dY(end+1:tNum) = dY(end);
    tApp(end+1:tNum)   = tApp(end);
    tDapp(end+1:tNum)  = tDapp(end);
    cont(end+1:tNum)   = cont(end);
    fFreq(end+1:tNum)  = fFreq(end);
    fPhase(end+1:tNum) = fPhase(end);
    
    % transform flicker paramters into cycle
    fCycle = round(60./fFreq); % in frames (1/60/fPU s)
    % set frequency = 0 to cycle = duration*2 such that it doesn't flicker
    fCycle(fCycle>duration*2) = duration*2; 
    frameOffset = round(fPhase/360.*fCycle); % in frames
    
    %% Draw the bitmap

    bitMap = zeros(sizeY,sizeX,fPU);
    for fr = 1:fPU
        preMap = ones(sizeY,sizeX)*bkgdContrast;
        f2 = f+(fr-1)/fPU; % current time point in "update" unit (1/60s)
        for ii = 1:tNum            
            % Check if we are going to draw this target or not
            isOn = (tApp(ii)<=f2).*(f2<tDapp(ii))*... % appearance/disappearance component
                   (mod(f2-tApp(ii)+frameOffset,fCycle(ii))<fCycle(ii)/2); % flicker component
            if isOn == 1
                elapsed = f2-tApp(ii);
                
                targetX = midX + rX(ii) + elapsed*dX(ii)/60;
                targetY = midY + rY(ii) + elapsed*dY(ii)/60;

                edgeL = targetX - tW(ii)/2;
                edgeR = targetX + tW(ii)/2;
                edgeU = targetY - tH(ii)/2;
                edgeD = targetY + tH(ii)/2;

                VertFrom = max(round(edgeL/numDeg),1);
                VertTo   = min(round(edgeR/numDeg),sizeX);
                HoriFrom = max(round(...
                                sizeY/2*...
                                (2*Q.cylinder.cylinderRadius*tand(edgeU)/Q.cylinder.cylinderHeight+1)),1);
                HoriTo   = min(round(...
                                sizeY/2*...
                                (2*Q.cylinder.cylinderRadius*tand(edgeD)/Q.cylinder.cylinderHeight+1)),sizeY);

                % ignore if outside of the screen
                if (VertFrom-VertTo)*(HoriFrom-HoriTo)~=0
                    preMap(HoriFrom:1:HoriTo,VertFrom:1:VertTo) = cont(ii);
                end
            end
        end
        bitMap(:,:,fr) = preMap;
    end
    
    if testgrid == 1
        bitMap(:,round(360/numDeg):round(-10/numDeg):1,:) = -0.5;
        bitMap(round(...
            sizeY/2*(...
            2*Q.cylinder.cylinderRadius*tand(-50:10:50)/Q.cylinder.cylinderHeight+1)),:,:) = -0.5;
    end    
    bitMap =  mLum * ( 1 + bitMap );
    
    texStr.tex = CreateTexture(bitMap,Q);
end
