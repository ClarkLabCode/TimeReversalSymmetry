function [texStr,stimData] = TargetSweepExtended(Q)

    % Present small targets to probe regressive target motion induced
    % slowing as reported in Zabala et al. (2012). Targets can be made
    % symmetric and background can be rotational or translational (i.e.
    % mirrored) moving sine wave gratings.

    % Created Jun 22 2018 by RT

    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %when choosing noise values for the sine wave make sure that:
    %noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
    %this insures that 3 std of the noise keeps you below a luminence of 1

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;
    
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % 9/14 using numDeg = 1 - maybe go high reso?
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    
    %% Input parameters
    % basics
    fPU = p.framesPerUp;
    targLat = p.targetLaterality; % 0 for left, 1 for right, 2 for bilateral (mirror symmteric)
    targCont = p.targetContrast; % -1 for Black, 1 for White
    
    % spatio temporal paramters of targets (all in deg)
    % size of the target
    targW = p.targetW; % deg 
    targH = p.targetH; % deg
    
    % position and velocity
    targVel = p.targetVelocity; % deg/s, + for BtF (reg), - for FtB (prog)
    initX   = p.initialX; % angle(deg) from the central vertical meridian, 0(front) ~ 180(back)
    Y = p.Y;
    
    % backgrounds
    isBgMirrored = p.isBackgroundMirrored; % 0 or 1
    lambda = p.lambda*pi/180; % wavelength in radians
    bgVel = p.backgroundVelocity*pi/180;  % degree/s into rad/s. when mirrored, + for BtF
    bgCont = p.backgroundContrast; % 0 for mean gray, 1 for full contrast
    
    % durations (all in frames = 1/60 sec)
    totalDuration = p.duration;
    dur_bgON_targON       = p.duration_BackgroundONtoTargetON;
    dur_targON_targMove   = p.duration_TargetONtoTargetMove;
    dur_targMove_targStop = p.duration_TargetMovetoTargetStop;
    dur_targStop_targOFF  = p.duration_TargetStoptoTargetOFF;
    timing_targOFF = dur_bgON_targON + dur_targON_targMove + dur_targMove_targStop + dur_targStop_targOFF;
    if isfield(p,'fade') 
        fade = p.fade;
    else
        fade = 0;
    end
    
    % grids to make sure that targets are shown as intended
    if isfield(p, 'testgrid')
        testgrid = p.testgrid;
    else
        testgrid = 0;
    end
    
    mLum = p.mLum;
    
    %% Draw the bitmap

    bitMap = zeros(sizeY,sizeX,fPU);
    draw = 1;
    
    % prepare background sinewave
    if f == 0 && ~isfield(stimData,'bgPhase')
        stimData.bgPhase = 0;
    end
    
    theta = (0:sizeX-1)/sizeX*2*pi; %theta in radians (for background)

    for fr = 1:fPU
        targMask = zeros(sizeY,sizeX);
        % draw background
        stimData.bgPhase = stimData.bgPhase + bgVel/(60*fPU);
        stimData.mat(fr) = stimData.bgPhase; % not sure if this is necessary
        preMap = bgCont*ones(sizeY,1)*sin(2*pi*(theta-stimData.bgPhase)/lambda);
        if isBgMirrored==1
            preMap(:,sizeX/2+1:sizeX) = fliplr(preMap(:,sizeX/2+1:sizeX));
        end
        
        % draw targets 
        if f+(fr-1)/fPU >= dur_bgON_targON && f+(fr-1)/fPU < timing_targOFF
            % suppose it's only in the left vis field (and
            % then flip if necessary)
            elapsedMoving = min(max(f+(fr-1)/fPU-(dur_bgON_targON+dur_targON_targMove),0),...
                                dur_targMove_targStop);
            currentX = initX - targVel*elapsedMoving/60; % angle from the meridian
            edgeL = (180-currentX) - targW/2; % in degree
            edgeR = (180-currentX) + targW/2;
            edgeU = Y - targH/2;
            edgeD = Y + targH/2;

            % convert spatial variables into pixel
            VertFrom = max(round(edgeL/numDeg),1);
            VertTo   = min(round(edgeR/numDeg),sizeX);
            HoriFrom = max(round(Q.cylinder.cylinderRadius*tand(edgeU)/numDeg + sizeY/2),1);
            HoriTo   = min(round(Q.cylinder.cylinderRadius*tand(edgeD)/numDeg + sizeY/2),sizeY);

            % skip if the whole target is out of the bound
            if (VertFrom-VertTo)*(HoriFrom-HoriTo)~=0 && draw == 1
                targMask(HoriFrom:1:HoriTo,VertFrom:1:VertTo) = 1;
            end
            switch targLat
                case 0
                case 1
                    targMask = targMask(:,end:-1:1);
                case 2
                    targMask = +(targMask|fliplr(targMask));
                otherwise
                    disp('targLat must be 0, 1, or 2')
                    return
            end
            % fading
            if f+(fr-1)/fPU < fade+dur_bgON_targON
                opacity = (f+(fr-1)/fPU - dur_bgON_targON)/fade;
            elseif f+(fr-1)/fPU > timing_targOFF-fade
                opacity = (timing_targOFF - (f+(fr-1)/fPU))/fade;
            else
                opacity = 1;
            end
            preMap(targMask==1) = (1-opacity)*preMap(targMask==1) + opacity*targCont;
        end
        bitMap(:,:,fr) = preMap;
    end
    
    if testgrid == 1
        bitMap(:,round(360/numDeg):round(-15/numDeg):1,:) = -0.5;
        bitMap(round(Q.cylinder.cylinderRadius*tand(-60:15:60)/numDeg+sizeY/2),:,:) = -0.5;
    end    
    bitMap =  mLum * ( 1 + bitMap );
    texStr.tex = CreateTexture(bitMap,Q);
end
