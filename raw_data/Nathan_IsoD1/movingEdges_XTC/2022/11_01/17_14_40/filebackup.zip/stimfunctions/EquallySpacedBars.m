function [texStr,stimData] = EquallySpacedBars(Q)
    % random grating of vertical bars rotated


    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    %% Input parameters

    framesPerUp = p.framesPerUp;
    barWidth = p.barWidth; % degrees
    backLum = p.backLum;
    barLum = p.barLum;
    numBars = p.numBars;
    vel = p.velocity*pi/180;

    sizeX = round(360/p.degreesPerPixel);

    if isfield(p,'randPhase')
        randPhase = p.randPhase;
    else
        randPhase = false;
    end


    %% left eye
    %stimData.mat(1) is used as the wave phase. stimData.mat(2) is the velocity which
    %is constant unless noise is added

    if ~isfield(stimData,'barPhase');
        stimData.barPhase = 0;
    end
        
    if f == 1
        if randPhase
            stimData.barPhase = rand*2*pi;
        end
    end


    theta = (0:sizeX-1)/sizeX*2*pi; %theta in radians
    initialMap = false(1,sizeX,framesPerUp);

    for cc = 1:framesPerUp
        stimData.barPhase = stimData.barPhase + vel/(60*framesPerUp);

        initialMap(1,:,cc) = mod(theta-stimData.barPhase,2*pi/numBars)<(barWidth*pi/180);

        stimData.mat(cc) = stimData.barPhase;
    end

    bitMap = initialMap;
    bitMap(initialMap) = barLum;
    bitMap(~initialMap) = backLum;

    texStr.tex = CreateTexture(bitMap,Q);
end