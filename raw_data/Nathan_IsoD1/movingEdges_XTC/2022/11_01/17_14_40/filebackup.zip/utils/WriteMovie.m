function WriteMovie(bitMap,Q)
    % final number of pixels
    % just assume the final move should be this size
    numPixXY = [153*4 360*4];

    frame = imresize(bitMap(:,:,1),numPixXY,'nearest');
    
    writeVideo(Q.handles.movie,frame);
end