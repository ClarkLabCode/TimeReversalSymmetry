function [texStr,stimData] = SineWaveMirroredWBars(Q)
    % basic sinewave stimulus. Can produce rotation and translation where
    % the opposite eye is the first eye's mirror image

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;

    if p.numDeg == 0
        sizeX = 1;
    else
        sizeX = round(360/p.numDeg);
    end

    mlum = p.lum;
    c = p.contrast;
    
    if ~isfield(p,'temporalFrequency')
        vel = p.velocity*pi/180; % degree/s into rad/s
    else
        vel = p.temporalFrequency*p.lambda*pi/180;
    end
    
    lambda = p.lambda*pi/180; %wavelength in radians
    framesPerUp = p.framesPerUp;


    stimSegLength = p.stimSegLength; %size of sine wave window in degrees
    greySegLength = p.greySegLength; %size of bar window

    %% closed loop stuff
    if isfield(p,'CLType')
        [flyTurningSpeed,flyWalkingSpeed,stimData] = GetFlyResponse(Q.timing.framenumber,Q.stims.duration,Q.flyTimeline.curFlyStates,stimData);
        SineWaveClosedLoop;
    end
    
    %% left eye
    %stimData.mat(1) is used as the wave phase. stimData.mat(2) is the velocity which
    %is constant unless noise is added

    if f == 1
        if ~isfield(stimData,'sinPhase');
            stimData.sinPhase = 0;
            % create a matrix for different contrast values, setting it to
            % 'c' over stim regions and 0 over grey bar regions
            stimSize = stimSegLength/p.numDeg;
            greySize = greySegLength/p.numDeg;
            repSeg = horzcat(repmat(c,[1 stimSize]),repmat(0,[1 greySize]));
            fullSeg = repmat(repSeg,[1 ceil(sizeX/length(repSeg))]);
            permutedSeg = circshift(fullSeg,[0 floor(rand*length(repSeg))]);
            stimData.cMatrix = permutedSeg(1,1:sizeX);   
        % this condition is here to let me use the ordertype 5 system
        % to reset window sizes for each different interleave
        elseif p.ordertype == 1
            stimData.sinPhase = 0;
            stimSize = stimSegLength/p.numDeg;
            greySize = greySegLength/p.numDeg;
            repSeg = horzcat(repmat(c,[1 stimSize]),repmat(0,[1 greySize]));
            fullSeg = repmat(repSeg,[1 ceil(sizeX/length(repSeg))]);
            permutedSeg = circshift(fullSeg,[0 floor(rand*length(repSeg))]);
            stimData.cMatrix = permutedSeg(1,1:sizeX);
        end
    end

    theta = (0:sizeX-1)/sizeX*2*pi; %theta in radians
    bitMap = zeros(1,sizeX,framesPerUp);

    for cc = 1:framesPerUp
        stimData.sinPhase = stimData.sinPhase + vel/(60*framesPerUp);

        for xx = 1:sizeX
            bitMap(1,xx,cc) = stimData.cMatrix(1,xx)*sin(2*pi*(theta(1,xx)-stimData.sinPhase)/lambda);
        end
        
        stimData.mat(cc) = stimData.sinPhase;
    end

    bitMap = mlum*(1 + bitMap);

    %% right eye
    if p.twoEyes
        rightEye = fliplr(bitMap);
        
        bitMap = CombEyes(bitMap,rightEye,p,f);
    end

    %always include this line in a stim function to make the texture from the
    %bitmap

    texStr.tex = CreateTexture(bitMap,Q);
end