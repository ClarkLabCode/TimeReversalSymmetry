function [texStr,stimData] = movingCheckerBoard_sparseSweep(Q)
    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework.

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %when choosing noise values for the sine wave make sure that:
    %noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
    %this insures that 3 std of the noise keeps you below a luminence of 1

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;
    stimData.flash = false;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    sizeX = round(360/p.numDeg);
    sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180)));
    

    mlum = p.lum;
    framesPerUp = p.framesPerUp;
    %stdv is a reserved parameter for future contrast controlling
    stdv = p.stdv;
    epochDuration=p.duration;
    vel = p.vel/p.numDeg;% convert degree to pixel
    width = p.width/p.numDeg;
    sparsity=p.sparsity;
    
    
    
    stimData.mat(1)=stdv;
    
    numVerticalBlock=ceil(sizeY/width);
    
    if f == 1
        % in the first frame of this epoch, initialize the sparse matrix
        stimData.sparseMat = sparseMatrixGenerator(sparsity,sizeX,width,vel,numVerticalBlock,epochDuration);
        % expand the matrix to improve the moving resolution to 1 pixel
        stimData.sparseMatExpanded=imresize(stimData.sparseMat,width,'nearest');
        stimData.sparseMatExpanded(1:width-mod(sizeY,width),:)=[];
    end
    
    
    bitMap = zeros(sizeY,sizeX,framesPerUp);
    for cc = 1:framesPerUp
        position=ceil(abs(vel)*1/(60*framesPerUp)*(framesPerUp*(f-1)+cc));%code's refresh rate is 60Hz        
        if vel<0 %vel<0, left
            bitMap(:,:,cc) = stdv*(stimData.sparseMatExpanded(:,position:position+sizeX-1));
        else %vel>0, right
            bitMap(:,end:-1:1,cc) = stdv*(stimData.sparseMatExpanded(:,position:position+sizeX-1));
        end        
    end
    bitMap = mlum*(1 + bitMap);

    %always include this line in a stim function to make the texture from the
    %bitmap 
    texStr.tex = CreateTexture(bitMap,Q);
end