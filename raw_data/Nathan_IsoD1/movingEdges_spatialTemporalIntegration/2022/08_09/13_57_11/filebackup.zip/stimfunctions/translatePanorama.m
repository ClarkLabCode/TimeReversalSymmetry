function [texStr,stimData] = translatePanorama(Q)

    params = Q.stims.currParam;
    updateNum = Q.timing.framenumber - Q.timing.framelastchange + 1; %number of frame changes since start of epoch
    stimData = Q.stims.stimData;
    
    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.
    
    setLuminance = 0;
    if isfield(params,'newMeanLuminance')
        newMeanLuminance = params.newMeanLuminance;
        setLuminance = 1;
    else
        if isfield(params,'meanLuminanceAdjust')
            meanLuminanceAdjust = params.meanLuminanceAdjust;
        else
            meanLuminanceAdjust = 0;
        end
    end
            
    
    contrastAdjust = params.contrastAdjust;
    velocity = params.velocity;
    
    folderPath = params.folderPath;
    imgNum = params.imgNum;
    
    framesPerUpdate = params.framesPerUp;
    
    if ~isfield(stimData,'prevEpochLastPos')
            stimData.prevEpochLastPos = 0;
    end
    if ~isfield(stimData,'thisEpochLastPos')
            stimData.thisEpochLastPos = 0;
    end
    if updateNum == 1 %We are in a new epoch
        stimData.prevEpochLastPos = stimData.thisEpochLastPos;
        stimData.thisEpochLastPos = 0;
    end
    if isfield(params,'resetPos') && params.resetPos
        stimData.prevEpochLastPos = 0;
    end
    
    if ~isfield(stimData,['img' num2str(imgNum)])
        files = dir(folderPath);
        fileNames = {files.name};
        numStr = num2str(imgNum,'%04i');
        fileNum = find(strncmp(numStr,fileNames,4));
        load(fullfile(folderPath,fileNames{fileNum}))
        stimData.(['img' num2str(imgNum)]) = projection/max(projection(:));
    end
    
    projection = stimData.(['img' num2str(imgNum)]);
    
    imgMean = mean(projection(:));
    imgContrasts = (projection-imgMean)/imgMean;
    
    if setLuminance
        newMean = newMeanLuminance;
    else
        newMean = imgMean + meanLuminanceAdjust;
    end
    
    img = uint8(255*(imgContrasts*contrastAdjust + 1)*newMean);

    [sizeY,sizeX] = size(img);
    bitmap(sizeY,sizeX,framesPerUpdate) = uint8(0);
    
%     imgDoubled = [img img];
    for f = 1:framesPerUpdate
        t =(updateNum-1)*(1/60) + f*(1/60)*(1/framesPerUpdate);
        pos = velocity*(sizeX/360)*t+stimData.prevEpochLastPos;
        shift = round(mod(pos,sizeX));
%         bitmap(:,:,f) = imgDoubled(:,shift+1:sizeX+shift);
        bitmap(:,:,f) = circshift(img,shift,2);
    end
    stimData.thisEpochLastPos = pos;
    texStr.tex = CreateTexture(bitmap,Q);
end