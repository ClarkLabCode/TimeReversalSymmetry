function [texStr,stimData] = SineWaveRandomMasks(Q)
    % basic sinewave stimulus. Can produce rotation and translation where
    % the opposite eye is the first eye's mirror image

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;

    if p.numDeg == 0
        sizeX = 1;
        sizeY = 1;
    else
        sizeX = round(360/p.numDeg);
        sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180)));
    end

    mlum = p.lum;
    c = p.contrast;
    
    if ~isfield(p,'temporalFrequency')
        vel = p.velocity*pi/180; % degree/s into rad/s
    else
        vel = p.temporalFrequency*p.lambda*pi/180;
    end
    
    lambda = p.lambda*pi/180; %wavelength in radians
    framesPerUp = p.framesPerUp;
    
    % We define two windows that will be masked out
    numMaskLocsX = p.numMaskLocsX;
    numMaskLocsY = p.numMaskLocsY;
    maskSizeX = floor(sizeX/numMaskLocsX);
    maskSizeY = floor(sizeY/numMaskLocsY);
    
%     if abs(maskSizeX - round(maskSizeX)) > 0.001 || abs(maskSizeY - round(maskSizeY)) > 0.001
%         error('numMaskLocs does not evenly divide size')
%     end
    
    if f == 1
        stimData.maskRows = randi(numMaskLocsY,2,1);
        stimData.maskCols = randi(numMaskLocsX,2,1);
        stimData.mat(1:4) = [stimData.maskRows; stimData.maskCols];
    end
    
    maskStartRows = 1 + maskSizeY*(stimData.maskRows-1);
    maskEndRows = maskSizeY*stimData.maskRows;
    maskStartCols = 1 + maskSizeX*(stimData.maskCols-1);
    maskEndCols = maskSizeX*stimData.maskCols;

    

    %% closed loop stuff
    if isfield(p,'CLType')
        [flyTurningSpeed,flyWalkingSpeed,stimData] = GetFlyResponse(Q.timing.framenumber,Q.stims.duration,Q.flyTimeline.curFlyStates,stimData);
        SineWaveClosedLoop;
    end
    
    %% left eye
    %stimData.mat(1) is used as the wave phase. stimData.mat(2) is the velocity which
    %is constant unless noise is added

    if f == 1 && ~isfield(stimData,'sinPhase')
        stimData.sinPhase = 0;
    end

    theta = (0:sizeX-1)/sizeX*2*pi; %theta in radians
    bitMap = zeros(sizeY,sizeX,framesPerUp);

    for cc = 1:framesPerUp
        stimData.sinPhase = stimData.sinPhase + vel/(60*framesPerUp);

        sine1d = c*sin(2*pi*(theta-stimData.sinPhase)/lambda);
        bitMap(:,:,cc) = repmat(sine1d,[sizeY,1,1]);
        
        for ii = 1:2
            bitMap(maskStartRows(ii):maskEndRows(ii),...
                   maskStartCols(ii):maskEndCols(ii),cc) = 0;
        end
    end

    bitMap = mlum*(1 + bitMap);

    %% right eye
    if p.twoEyes
        rightEye = fliplr(bitMap);
        
        bitMap = CombEyes(bitMap,rightEye,p,f);
    end

    %always include this line in a stim function to make the texture from the
    %bitmap

    texStr.tex = CreateTexture(bitMap,Q);
end