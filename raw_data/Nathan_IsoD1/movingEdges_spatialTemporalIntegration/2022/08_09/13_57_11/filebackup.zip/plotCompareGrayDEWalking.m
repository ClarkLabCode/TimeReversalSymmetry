function comparisonPlot = plotCompareGrayDEWalking(path, titles)
    VELOCITY_2880 = 90*sqrt(2).^(0:2:10);
    
    %%
    
    grayPaths_edgeStim = 'Z:\behavior_data\data\IsoD1_24H_Gray\LDedgeMHL_vVel_Back05_light1dark1_vel2880';
    IsoD1_DEStim_gray24H = RunAnalysis('analysisFile',{'CombAndSep'},'dataPath',grayPaths_edgeStim,'tickX',log(VELOCITY_2880),...
    'dataX',log(VELOCITY_2880),'tickLabelX',VELOCITY_2880,'labelX',['Velocity (' char(186) '/s)'],'combOpp',1,...
    'numSep',2,'sepType','contiguous','numIgnore',1,'figLeg',{'Light Edges' 'Dark Edges'});

    gray_DE = IsoD1_DEStim_gray24H.analysis{1}.respMatPlot(:,2,2);
    gray_DE_sem =IsoD1_DEStim_gray24H.analysis{1}.respMatSemPlot(:,2,2);


    temp_struct = RunAnalysis('analysisFile',{'CombAndSep'},'dataPath',path,'tickX',log(VELOCITY_2880),...
    'dataX',log(VELOCITY_2880),'tickLabelX',VELOCITY_2880,'labelX',['Velocity (' char(186) '/s)'],'combOpp',1,...
    'numSep',2,'sepType','contiguous','numIgnore',1,'figLeg',{'Light Edges' 'Dark Edges'},'plotFigs', false);

    temp_DE = temp_struct.analysis{1}.respMatPlot(:,2,2);
    temp_DE_sem =temp_struct.analysis{1}.respMatSemPlot(:,2,2);

    comparisonPlot = MakeFigure; hold on;
    PlotXvsY([(log(VELOCITY_2880))',(log(VELOCITY_2880))'],[gray_DE, temp_DE],'error',[gray_DE_sem,temp_DE_sem], 'plotColor',[0,0,0;1,0,0] );
    xticks(log(VELOCITY_2880));xticklabels(VELOCITY_2880); xlabel(['Velocity (' char(186) '/s)']); ylabel("walking response (fold change)");
    legend(strcat(titles{1}, ' DE stim'), strcat(titles{2},' DE stim')); hold off;

    
    %%
    
    

end


