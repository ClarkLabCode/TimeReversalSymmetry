function [texStr,stimData] = HarshLoomReal(Q)

    % Created 03/10/2021
    
    % Looming disc with realistic expansion rate (arctangent)
    % Take R/v value and initial angular radius
    % Terminal radius is fixed at 90deg (i.e. full screen)
    
    % Under this constraint, expansion takes R/v/tan(r1) where r1 is the
    % initial radius (1/tan(r1) = 11.43 if r1 = 5 deg, for example)
    
    % Since the duration of expansion is not explicitly parametrized,
    % epoch duration needs to be pre-calculated manually
    % (i.e. epoch duration should be longer than pre-expansion duration +
    % R/v/tan(r1) + post-expansion duration)
    
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;
    
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % 9/14 using numDeg = 1 - maybe go high reso?
    cR = Q.cylinder.cylinderRadius;
    cH = Q.cylinder.cylinderHeight;
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(cH/2/cR)/numDeg);
    
    %% Input parameters
    %% things that concern the entire presentation
    
    fPU = p.framesPerUp;
    duration = p.duration; % frames
    mLum = p.mlum;
    eqLum=p.eqLum;
    width=p.width;
    
    if isfield(p, 'backgroundContrast')
        bkgdContrast = p.backgroundContrast;
        if isempty(bkgdContrast); bkgdContrast = 0; end
    else
        bkgdContrast = 0;
    end
    
    if isfield(p, 'testgrid')
        testgrid = p.testgrid;
    else
        testgrid = 0;
    end
    
    %% things that concern targets
    
    % center of presentation - all spatial parameters are relative to this
    % the center can be moved by entering numbers in the comment section of
    % the input GUI (otherwise its gonna be set at the actual center)
    
    if f==0
        if ~isempty(Q.condstr) 
            onlineloc = strsplit(Q.condstr,',');
            midX = str2num(onlineloc{1});
            midY = str2num(onlineloc{2});
        else
            midX = 180;
            midY = 0;
        end
        stimData.midX = midX;
        stimData.midY = midY;
%         
%     ord continuous value of turning angle (unit:n_pixel)
    
    

        
    else
        midX = stimData.midX;
        midY = stimData.midY;
    end
   
    % sizes (vector)
    iR = p.initialRadius; % deg 
    
    % kinetics parameters
    % relative locations (initial) (vector)
    if isfield(p,'relativeX')
        rX = p.relativeX; % deg
        rY = p.relativeY; % deg
        if isempty(rX) || isempty(rY)
            rX = 0;
            rY = 0;
        end
    else
        rX = 0;
        rY = 0;
    end
    
    % expansion rate
    RoverV = p.RoverV; % in s
    
    % timings (vector)
    preLD  = p.preLoomDuration/60;
    postLD = p.postLoomDuration/60;
    
    cont = p.targetContrast;
    
    %% Calculate duration it takes to expand all the way
    loomDuration   = RoverV / tand(iR); % in s
    collisionPoint = preLD + loomDuration; % in s 
    
    %% Draw the bitmap
    
    
     rng(1); %let the random number keep the same each time!
    
    %         init_stim = randi([-1,1],round(sizeY/5),round(sizeX/5)); %2D
    
    init_stim = 2*(rand(round(sizeY/width),round(sizeX/width))>0.5) - 1;
    %        init_stim = init_stim*p.contrast+0.5*(1-p.contrast);
    
    init_stim = imresize(init_stim,width,"nearest");
%     stimData.init_stim = init_stim;
%     stimData.theta = 0; %rec
    
    
    
    
    

    [sizeY,sizeX]=size(init_stim);
 

    bitMap = zeros(sizeY,sizeX,fPU);
    for fr = 1:fPU
        preMap = ones(sizeY,sizeX)*bkgdContrast;
        elapsed = (f+(fr-1)/fPU)/60; % current time point in s
        
        if elapsed < preLD
            thisRadius = iR;
        elseif elapsed > collisionPoint
            thisRadius = +Inf;
        else % if it is expanding now
            timeToCollision = collisionPoint - elapsed;
            thisRadius = atand(RoverV/timeToCollision);            
        end
        
        targetX = midX + rX;
        targetY = midY + rY;
        
        [XXdeg,YY] = meshgrid(1:sizeX,(1:sizeY)-sizeY/2);
        YYdeg =  atand(YY*cH/sizeY/cR); % positive angle is down
        mask = sqrt((XXdeg-targetX).^2 + (YYdeg-targetY).^2)<=thisRadius;
        
        % Fill in the object only if it is within the window 
        % (this is to make sure that the duration after the collision is
        % identical across different R/v conditions)
        if elapsed < collisionPoint + postLD
            if eqLum==0
            preMap(mask==1) = cont;
            else
                 preMap=init_stim;
                 preMap(mask==0) = bkgdContrast;
            end
        end
        bitMap(:,:,fr) = preMap;
    end
    
    if testgrid == 1
        bitMap(:,round(360/numDeg):round(-10/numDeg):1,:) = -0.5;
        bitMap(round(...
            sizeY/2*(...
            2*Q.cylinder.cylinderRadius*tand(-50:10:50)/Q.cylinder.cylinderHeight+1)),:,:) = -0.5;
    end    
    bitMap =  mLum * ( 1 + bitMap );
    
    texStr.tex = CreateTexture(bitMap,Q);
end
