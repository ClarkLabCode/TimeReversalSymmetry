
function [texStr,stimData] = EquiluminantRingandDot(Q)
%This function creates looming circle at a position on the screen.
%first the circle remains stationaty for some time then it starts to increase in size on
%the frame specified in param file. The circle increases to a final size
%specified by the user in the param file. The rate of increase of size is
%calculated based on the duration of the epoch.
%% Parameters
p = Q.stims.currParam;
f = Q.timing.framenumber - Q.timing.framelastchange + 1;
% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix
%%
fPU = p.framesPerUp; % framesPerUp
bagContrast=p.bagContrast;
mlum=p.mlum;
ri=p.initialRadius;
rf=p.finalRadius;
r0=p.dotRadius;
LSF=p.loomStartframe;
LEF=p.loomEndframe;
%position on the screen
rX=p.xcoordinate;

if isfield(p,'dot')
    dot=p.dot;
    ci=p.ci;
    cf=p.cf;
    c=ci;
else
    dot=0;
    ci=p.bagContrast;
    cf=p.bagContrast;
    c=ci;

end

%calculate expansion duration
expDur=LEF-LSF;

%radial BITMAP
x=(1:sizeX)-rX;
y=(1:sizeY)-sizeY/2;
[X,Y]=meshgrid(x,y);


theta=atan(Y./X);
r=sqrt((X.^2)+(Y.^2));
n=p.numBlocks;

%calculate expansion/contraction Velocity
v=(rf-ri)/expDur;
%calculate delta contrast for dot
del=(cf-ci)/expDur;

%mask for inner dot
mask3=(r<=r0);
radius=ri;
if f==1
stimData.cir1=sign(sin((n*theta)));
stimData.cir2=sign(sin((n*theta)-pi));
end





%% Initializing BitMap
bitMap= ones(sizeY,sizeX,fPU)*bagContrast;

for fr = 1:fPU
    preMap=ones(sizeY,sizeX)*bagContrast;
    
    if f>=LSF &&f<LEF
        t = (f-1)*fPU + fr; 
        radius=round(ri+(v/3)*(t-((LSF-1)*fPU)));
        mask1=r<=radius+6 &r>radius+3;
        mask2=r>=radius &r<=radius+3;
        
        c=(ci+(del/3)*(t-((LSF-1)*fPU)));
    elseif f<LSF
        radius=ri;
      mask1=r<=radius+6 &r>radius+3;
        mask2=r>=radius &r<=radius+3;
        c=ci;
    elseif f>= LEF
        radius=rf;
       mask1=r<=radius+6 &r>radius+3;
        mask2=r>=radius &r<=radius+3;
        c=cf;
    end
    if radius>0
        preMap(mask1==1)=stimData.cir1(mask1==1);
        preMap(mask2==1)=stimData.cir2(mask2==1);
        if dot==1
            preMap(mask3==1)=c;
        end  
        bitMap(:,:,fr) = preMap;
    end
    
    
end
bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);
end
