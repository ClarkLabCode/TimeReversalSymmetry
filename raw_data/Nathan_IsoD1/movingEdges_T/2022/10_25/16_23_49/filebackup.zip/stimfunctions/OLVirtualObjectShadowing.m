function [texStr,stimData] = OLVirtualObjectShadowing(Q)

    % Created Mar 23 2021

    % Open loop version of CLVirtualObjectShadowing
    % Mostly for reconstructing what flies would see
    
    %% Parameters
    p = Q.stims.currParam;                               % Struct with current epoch stimulus parameters
    f = Q.timing.framenumber - Q.timing.framelastchange; % Relative frame number
    stimData = Q.stims.stimData;                         % Struct to communicate between multiple calls of this function
    
    % degree per pixel (usually fixed at 1)
    numDeg = p.numDeg;
    % define output bitmap dimensions
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    cH = Q.cylinder.cylinderHeight;
    cR = Q.cylinder.cylinderRadius;
    
    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.
    
    %% Beginnig of epoch initialization
    if f==0 
        % Reset the current position of the fly
        stimData.flypos = 0;
        
    end
    
    %% Closed loop read-outs
    % Get flies' walking response
    walkingSpeed = p.walkingSpeed; % in mm/s
    flypos = stimData.flypos;
    
    %% Stimulus parameters
    fPU   = p.framesPerUp;  % frames per 60Hz update
    mLum  = p.mLum;         % mean luminance
    bgC   = p.backgroundContrast; % maybe I should do cluttered background in future?
    obC   = p.objectContrast; 
    
    % object initial position (in mm)
    X0 = p.initialX;
    Y0 = p.initialY;
    Z0 = p.initialZ;
    
    % object movement gain (in mm)
    gX = p.xGain;
    gY = p.yGain;
    
    % object size (in mm)
    obW = p.objectWidth;
    obH = p.objectHeight;
        
    %% Update of visual stimuli and drawing
    bitMap = zeros(sizeY,sizeX,fPU);
    for ff = 1:fPU
        % Prepare the matrix to draw things into
        objectMask = zeros(sizeY,sizeX);
        % Update fly position (in mm)
        flypos = flypos + walkingSpeed/60/fPU;
 
        % Calculate the object position in fly centered coordinate (in XY)
        objpos = [X0+gX*flypos, Y0+(gY-1)*flypos];
        
        % Covnert position to visual angle
        centerang = atan2d(objpos(2),objpos(1));
        
        % Calculate the coordinates of the edges of the objects
        edge1pos = objpos + obW*[cosd(centerang+90), sind(centerang+90)]/2;
        edge2pos = objpos + obW*[cosd(centerang-90), sind(centerang-90)]/2;
        
        % Convert to degree
        % Subtract from 270 because cylinder wrapping starts behind
        edge1ang = 270-atan2d(edge1pos(2),edge1pos(1));
        edge2ang = 270-atan2d(edge2pos(2),edge2pos(1));
        
        % Cut off at the edge
        edge1ind = min(max(round(mod(edge1ang,360)/numDeg),1),sizeX);
        edge2ind = min(max(round(mod(edge2ang,360)/numDeg),1),sizeX);
        
        % Calculate vertical edges
        centerDist = sqrt(sum(objpos.^2));
        topang = atan2d(Z0-obH/2,centerDist);
        botang = atan2d(Z0+obH/2,centerDist);
        
        % convert angles to index
        topind = max(round(sizeY/2*(2*cR*tand(topang)/cH + 1)),1);
        botind = min(round(sizeY/2*(2*cR*tand(botang)/cH + 1)),sizeY);
        
        
        % object mask
        objectMask(topind:botind,edge1ind:edge2ind) = 1;
        
        % fill in
        bitMap(:,:,ff) = objectMask*obC + (1-objectMask)*bgC;
        
        % Save fly position (object position can be easily recovered within
        % the analysis function so I'm not saving it)
        stimData.mat(ff) = flypos;
    end
    
    % pass the position variable to the next loop
    stimData.flypos  = flypos;
    
    % convert contrast to luminance
    bitMap =  mLum * ( 1 + bitMap );
    
    % convert bitmap to a PTB texture
    texStr.tex = CreateTexture(bitMap,Q);
end
