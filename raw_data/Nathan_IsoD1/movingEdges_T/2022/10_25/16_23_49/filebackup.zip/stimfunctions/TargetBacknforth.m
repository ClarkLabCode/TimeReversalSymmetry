function [texStr,stimData] = TargetBacknforth(Q)

    % last update Nov 16 2017

    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %when choosing noise values for the sine wave make sure that:
    %noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
    %this insures that 3 std of the noise keeps you below a luminence of 1

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;
    
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % 9/14 using numDeg = 1 - maybe go high reso?
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    
    %% Input parameters

    framesPerFlip = p.framesPerUp;
    
    if isfield(p, 'backgroundContrast')
        bkgdContrast = p.backgroundContrast;
    else
        bkgdContrast = 0;
    end
    
    if isfield(p, 'testgrid')
        testgrid = p.testgrid;
    else
        testgrid = 0;
    end
    
    if isfield(p, 'targetNum')
        targetNum = p.targetNum;
        spacingX_1 = p.spacingX_1;
        spacingY_1 = p.spacingY_1;
        spacingX_2 = p.spacingX_2;
        spacingY_2 = p.spacingY_2;        
    else
        targetNum = 1;
        spacingX_1 = 0;
        spacingY_1 = 0;
        spacingX_2 = 0;
        spacingY_2 = 0;
        
    end    
    
    % spatio temporal paramters (all deg)
    targetW = p.targetW; % deg 
    targetH = p.targetH; % deg
    
    amp_X = p.Xamplitude; % deg
    amp_Y = p.Yamplitude; % deg
    tau_X = p.Xcycle; % s
    tau_Y = p.Ycycle; % s
    
    midX = p.midX;
    midY = p.midY;
    totalDuration = p.duration; % frames
    
    mLum = p.mLum;
    targetContrast = p.Contrast;
    
    flickerFrequency = 0;
    if isfield(p, 'flickerFrequency')
        flickerFrequency = p.flickerFrequency;
    end
    
    %% Draw the bitmap

    bitMap = zeros(sizeY,sizeX,framesPerFlip);
    preMap = ones(size(bitMap,1),size(bitMap,2))*bkgdContrast;

    draw = 1;
    
    for fr = 1:framesPerFlip
        
        if flickerFrequency~=0
            if mod(f*framesPerFlip+fr-1,60*framesPerFlip/flickerFrequency) < 30*framesPerFlip/flickerFrequency
                draw = 1;
            else
                draw = 0;
            end
        end
        
        for tt = 1:targetNum

            if (mod(targetNum,2)==0)
                numSpacing_1 = floor((tt - (targetNum+1)/2)/2)+0.5;
                numSpacing_2 = floor((tt - (targetNum+1)/2)/2 +0.5);
            else
                numSpacing_1 = ceil((tt - (targetNum+1)/2)/2);
                numSpacing_2 = floor((tt - (targetNum+1)/2)/2);
            end


            % Update: Nov 16 - range of f starts from 0 - data taken before
            % should be discarded for formal analysis
            
            % stimData.writeColIndex = 0;
            % total number of frames so far = framesPerFlip*f + fr
            % total elapsed time = (f+fr/framesPerFlip)/60
            
            targetX = midX + amp_X * sin(2*pi*(f+fr/framesPerFlip)/60/tau_X) ...
                + numSpacing_1*spacingX_1 + numSpacing_2*spacingX_2; % deg
            targetY = midY + amp_Y * sin(2*pi*(f+fr/framesPerFlip)/60/tau_Y) ...
                + numSpacing_1*spacingY_1 + numSpacing_2*spacingY_2; % deg

            % these are all in deg
            % Update Sep 25 2017: X change according to elevation
            % compensated
            targetLedge = 2 * asind(min(max(sind((targetX-targetW/2)/2)/cosd(targetY),-1),1));
            targetRedge = 2 * asind(min(max(sind((targetX+targetW/2)/2)/cosd(targetY),-1),1));
            targetUedge = targetY - targetH/2;
            targetDedge = targetY + targetH/2;

            % convert spatial variables into pixel
            VertFrom = max(round(targetLedge/numDeg+sizeX/2),1);
            VertTo   = min(round(targetRedge/numDeg+sizeX/2),sizeX);
            
            HoriFrom = max(round(Q.cylinder.cylinderRadius*tand(targetUedge)/numDeg + sizeY/2),1);
            HoriTo   = min(round(Q.cylinder.cylinderRadius*tand(targetDedge)/numDeg + sizeY/2),sizeY);
            
            % for debugging
            if imag(VertFrom)^2 + imag(VertTo)^2 + imag(HoriFrom)^2 + imag(HoriTo)^2 ~= 0
                disp(targetLedge);
                disp(targetRedge);
                return;
            end

            % skip if the whole target is out of the bound
            if (VertFrom-VertTo)*(HoriFrom-HoriTo)~=0 && draw == 1
                preMap(HoriFrom:1:HoriTo,VertFrom:1:VertTo) = targetContrast;
            end

        end
        bitMap(:,:,fr) = preMap;
    end
    
    if testgrid == 1
        bitMap(:,round(360/numDeg):round(-15/numDeg):1,:) = -0.5;
        bitMap(round(Q.cylinder.cylinderRadius*tand(-60:15:60)/numDeg+sizeY/2),:,:) = -0.5;
    end    
    bitMap =  mLum * ( 1 + bitMap );
    
    texStr.tex = CreateTexture(bitMap,Q);
end
