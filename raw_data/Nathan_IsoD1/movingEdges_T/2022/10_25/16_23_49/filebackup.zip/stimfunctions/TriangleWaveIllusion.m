
function [texStr,stimData] = TriangleWaveIllusion(Q)

%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
% input from user
period = p.period; % period of sawtooth in seconds
amplitude = p.amplitude; % in luminance
numDeg = p.numDeg;
fPU = p.framesPerUp; % framesPerUp
mlum = p.mlum;
isincrease = p.isincrease;
background = p.background; % 0.5, gray, -1 black, 1 white
loomStartFrame = p.loomStartFrame;
sync= p.sync;



%duration = p.duration;
r = p.radius;
a = p.xcoordinate;
b = p.ycoordinate;

[A,B] = meshgrid(a,b);

x = [1:sizeX];
y = [1:sizeY];
[X,Y] = meshgrid(x,y);

if f==1
    %     a = 0.5;
    % b = 1;
    % offset = (b-a).*rand(numel(A),1) + a;
    if sync==0
        offset = rand( numel(A), 1) * period; % random time offset in units of seconds
    else
        offset =zeros(numel(A),1);
    end
    stimData.offset = offset;
    
else
    offset = stimData.offset;
end

%% Initializing BitMap

if f == 1 || f >= loomStartFrame

stimData.cir_pos = zeros(sizeY,sizeX)+ background; %-1 = black background, 0.5 gray background
for i_circ = 1:numel(A)
    circ = ((X-A(i_circ)).^2 + ((Y-B(i_circ)).^2) <= r^2);
    cur_lum = 2*abs(((f/60+offset(i_circ))/period)-floor(((f/60+offset(i_circ))/period)+(1/2)))* amplitude; % current time in seconds
    if ~isincrease
        cur_lum = 1 - cur_lum;
    end
    stimData.cir_pos( circ ) = cur_lum;
end
end
bitMap = repmat(stimData.cir_pos, 1, 1, fPU);
%end


%bitMap = mlum*(1 + bitMap); % converts contrast to luminance

%always include this line in a stim function to make the texture from the
%bitmap

texStr.tex = CreateTexture(bitMap,Q);


end