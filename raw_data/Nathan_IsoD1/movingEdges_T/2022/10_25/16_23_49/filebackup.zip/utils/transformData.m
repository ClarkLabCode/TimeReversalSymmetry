transformData

remember to put option for taking abs of turn