function [texStr,stimData] = motionMosaicRandomUpdateFixedWindowWithAnnulus(Q)

    % Created Feb 26 2020 by RT
    % for imaging experiments for the surround suppression / vetoing
    % project
    % fix the location of "center" (so it's no longer really a mosaic)
    % 'Background' is what I meant to be directionally moving
    % Sorry for confusing naming
    
    %% Stimulus Parameters %%  
    %% System stuffs
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    %% basics
    duration = p.duration;
    numDeg = p.numDeg;
    
    cR = Q.cylinder.cylinderRadius;
    cH = Q.cylinder.cylinderHeight;
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(cH/2/cR)/numDeg);
    
    fPU = p.framesPerUp;
    mlum=p.mLum;
    flipWindow = p.flipWindow;

    %% Texture related
    % spatial
    tResoDeg = p.textureResolution;  % in degrees, should be integer multiplication of numDeg
    
    windowSize  = p.windowSize; % in degrees (radius)
    annulusSize = p.annulusSize;% in degrees
    windowX = p.windowX+sizeX/2; % in degrees
    windowY = p.windowY; % in degrees
    
    tResoPx = round(tResoDeg/numDeg);
    tSize = ceil([sizeY,sizeX]/tResoPx); % the size of random matrices to be generated
        
    % intensity related
    cont = p.maxContrast;   % 0~1 - can be 2D if you want different contrasts for fore/backgorunds
    cS   = p.contrastSteps; % beaware of the bit depth
    
    % temporal
    dR   = p.velocities; % deg/s, 2D matrix
    fF   = p.flickerFrequency; % of foreground
    fPC  = min(60/fF*fPU,duration*2*fPU);
    
    if isfield(p,'backgroundFrequency')
        bfF = p.backgroundFrequency;
    else
        bfF = 0;
    end
    bfPC  = min(60/bfF*fPU,duration*2*fPU);
    
    
    
    if isfield(p,'foregroundVelocities')
        fdR = p.foregroundVelocities;
    else
        fdR = [0,0];
    end
    % create the mosaic pattern, fore/background textures
    % make matrices that are slightly larger than sizeX, sizeY and
    % crop them properly
    if f == 0
        % make background matrix with checkerboard resolution
        bgMatOrig = cont(end)*((randi(cS,tSize)-1)/(cS-1)*2-1);
        % Expand it
        bgMatExpanded = imresize(bgMatOrig,tResoPx,'box');
        bgPos = [0,0]; % position of background
        fgPos = [0,0];
        % make foreground matrix with checkerboard resolution 
        fgMatOrig = ((randi(cS,tSize)-1)/(cS-1)*2-1)*cont(1);
        % expand it
        fgMatExpanded = imresize(fgMatOrig,tResoPx,'box');

        % prepare window mask
        [XXdeg,YY] = meshgrid(1:sizeX,(1:sizeY)-sizeY/2);
        YYdeg = atand(YY*cH/sizeY/cR); % positive angle is down
        
        mask = sqrt((XXdeg-windowX).^2 + (YYdeg-windowY).^2)<windowSize;
        annulusmask = sqrt((XXdeg-windowX).^2 + (YYdeg-windowY).^2)<annulusSize;
        
        if flipWindow
            mask = 1-annulusmask;
            annulusmask = mask;
        end
        
        % don't trim tMat here because it should be trimmed after moving it
        % save the matrix into the structure
        stimData.bgMatExpanded = bgMatExpanded;
        stimData.fgMatExpanded = fgMatExpanded;
        stimData.bgPos = bgPos;
        stimData.fgPos = fgPos;
        stimData.mask = mask;
        stimData.annulusmask = annulusmask;
    else
        % load matrices from the previous frame
        bgMatExpanded = stimData.bgMatExpanded;
        fgMatExpanded = stimData.fgMatExpanded;
        bgPos = stimData.bgPos;
        fgPos = stimData.fgPos;
        mask = stimData.mask;
        annulusmask = stimData.annulusmask;
    end
      
    bitMap = zeros(sizeY,sizeX,fPU);     
    for cc = 0:1:fPU-1
        
        % update the background (when it is supposed to be flickerly)
        if mod(f*fPU+cc,bfPC)==0 && f+cc/fPU>0
            bgMatOrig = cont(end)*((randi(cS,tSize)-1)/(cS-1)*2-1);
            bgMatExpanded = imresize(bgMatOrig,tResoPx,'box');
            stimData.bgMatExpanded = bgMatExpanded;
        end
        % move the background
        bgPos = bgPos + dR/60/fPU;
        temp1 = circshift(bgMatExpanded,round([bgPos(2),bgPos(1)]/numDeg));
        bg = temp1(1:sizeY,1:sizeX); % trimming
        
        % update the foreground (when it is supposed to be flickerly)
        if mod(f*fPU+cc,fPC)==0 && f+cc/fPU>0
            fgMatOrig = cont(1)*((randi(cS,tSize)-1)/(cS-1)*2-1);
            fgMatExpanded = imresize(fgMatOrig,tResoPx,'box');
            stimData.fgMatExpanded = fgMatExpanded;
        end
        fgPos = fgPos + fdR/60/fPU;
        temp2 = circshift(fgMatExpanded,round([fgPos(2),fgPos(1)]/numDeg));
        fg = temp2(1:sizeY,1:sizeX); % trimming
        
        bitMap(:,:,cc+1) = bg.*mask+fg.*(1-annulusmask);
    end
    stimData.bgPos = bgPos;
    stimData.fgPos = fgPos;
    bitMap=mlum*(1+bitMap); % contrast to luminance conversion
    texStr.tex = CreateTexture(bitMap,Q);
end
