function [mask] = MultiMaskMakerRegular(sizes, gridDist, radish)

    sizeY = sizes(:,1);
    sizeX = sizes(:,2);

    maskP = zeros([sizeY, sizeX]);
    
    [xx, yy] = meshgrid(1:sizeX, 1:sizeY);
    
    % fixed size
    if nargin < 3
        radish = sqrt(-log(0.1*atanh(0.5))/(2/100));
    end
    slopey = 10;
    
    % generate grid 
    gridX = (-1:1:ceil(sizeX/gridDist))*gridDist +...
            (randi(gridDist)*2-gridDist); % phase scrambring
    gridY = (-1:1:ceil(sizeY/gridDist))*gridDist +...
            (randi(gridDist)*2-gridDist);
    

    for ii = 1:length(gridX)
       for jj = 1:length(gridY)
         yLoc = gridY(jj);
         xLoc = gridX(ii);
         scaleFactor = log(0.1*atanh(0.5))/(radish.^2);
         maskP = maskP + exp(scaleFactor*((xx-xLoc).^2+(yy-yLoc).^2));
       end
    end

    mask = tanh(slopey*maskP);

end