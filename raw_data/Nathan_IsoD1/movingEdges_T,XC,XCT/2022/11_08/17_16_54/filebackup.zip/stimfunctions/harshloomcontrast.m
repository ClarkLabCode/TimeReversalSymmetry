function [texStr,stimData] = HarshLoom3(Q)
%This function creates looming circle at a position on the screen.
%first the circle remains stationaty for some time then it starts to increase in size on
%the frame specified in param file. The circle increases to a final size
%specified by the user in the param file. The rate of increase of size is
%calculated based on the duration of the epoch.



%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
%User inputs
%User inputs

numDeg = p.numDeg;
fPU = p.framesPerUp; % framesPerUp
contrast = p.contrast;
bagContrast=p.bagContrast;
duration = p.duration;
mlum=p.mlum;

if isfield(p, 'randContra')
    randContra=p.randContra;
else
    randContra=0;
end

%Loom size
iR= p.initialRadius;
fR=p.finalRadius;


% looming duration
LSF = p.loomStartFrame;%loom start frame

if isfield(p, 'loomEndFrame')
    LEF= p.loomEndFrame;
else
    LEF=duration;%Loom end frame
end
    

%calculate velocity and initial diatance
L=p.L;
dInitial=L/tand(iR);
v=(1/(LEF-LSF+1))*(dInitial-(L/tand(fR))); %


%position on the screen
rX=p.xPosition;
rY=round(sizeY/2);


stimdata.contrast=p.contrast;


%% Initializing BitMap
bitMap= zeros(sizeY,sizeX,fPU);
bitMap(:,:,:) =bagContrast;



for fr = 1:fPU
    
  cont=stimdata.contrast;
    
    if f>=LSF &&f<LEF
        t = (f-1)*fPU + fr; % index for all fPU
        d=dInitial-(v/3)*(t-((LSF-1)*fPU));
        radius=atand(L/d);
    elseif f<LSF
        radius=iR;
    elseif f>= LEF
        radius=fR;
    end
    if radius>0
       
        cont=-(radius/fR);
        preMap = ones(sizeY,sizeX)*bagContrast;
        [XX,YY] = meshgrid(1:sizeX,(1:sizeY));
        mask = sqrt((XX-rX).^2 + (YY-rY).^2)<radius;
        if randContra==0  
        preMap(mask==1) = cont;
        else
             M = ones(sizeY,sizeX)*bagContrast;
        B = reshape(mask,[numel(mask),1]);
        for i=1:length(B)
           if B(i)==1
               M(i)= (rand(1)>0.5);
           end
        end
%         [row,col]=size(preMap);
        preMap = reshape(M,size(preMap));
        end
        bitMap(:,:,fr) = preMap;
    end
   
end
stimData.contrast=cont;
bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);
end