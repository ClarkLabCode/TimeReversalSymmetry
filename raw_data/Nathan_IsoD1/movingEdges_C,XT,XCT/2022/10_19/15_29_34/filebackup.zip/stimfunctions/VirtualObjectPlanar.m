function [texStr,stimData] = VirtualObjectPlanar(Q)

    % Present a virtual object moving 2-dimensionally on a virtual plane

    % Created Jul 20 2018 by RT

    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    % when choosing noise values for the sine wave make sure that:
    % noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
    % this insures that 3 std of the noise keeps you below a luminence of 1

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;
    
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    %% Geometrical basics
    cH = Q.cylinder.cylinderHeight;
    cR = Q.cylinder.cylinderRadius;
    sizeX = round(360/numDeg);
    sizeY = round(2*atand(cH/2/cR)/numDeg);
    
    %% Input parameters
    % basics
    fPU        = p.framesPerUp;
    mirrorType = p.mirrorType; % 0 for normal, 1 for flipped, 2 for bilateral (mirror symmteric)
 
    % plane paramters
    % the plane is going to be parallel to the cylinder
    pD = p.planeDistance; % distance from the center of the cylinder to the plane (mm)
    pA = p.planeAngle;    % the angle b/w the normal vector of the plane and the fly's gaze direction
                          % negative value for plane on the left side
                          % (degree)
    
    % spatio temporal paramters of the object
    % size 
    oW = p.objectWidth;  % (mm) 
    oH = p.objectHeight; % (mm)
    % position 
    initX  = p.initialX; % (mm) positive = right (when viewed from the flY's position)
    initY  = p.initialY; % (mm) positive = up
    % velocity
    dX = p.velocityX; % (mm/s)
    dY = p.velocityY; % (mm/s)
    % color
    oC = p.objectContrast; % -1~1
    
    % backgrounds
    bC = p.backgroundContrast; % 0 for mean gray, 1 for full contrast
    
    % durations (all in frames = 1/60 sec)
    dT   = p.duration;
    dAM  = p.duration_AppearToMove;
    dMS  = p.duration_MoveToStop;
        
    % mean luminance
    mLum = p.mLum;
    
    %% initialize location parameter
    if f == 1 || ~isfield(stimData,'objectPosition')
        stimData.objectPosition = [initX,initY]; % (mm)
    end
    oP = stimData.objectPosition; % (mm)
    
    %% Draw the bitmap
    bitMap = zeros(sizeY,sizeX,fPU);
    objectMask = zeros(sizeY,sizeX);
        
    for fr = 1:fPU
        % clean up preMap
        objectMask(:) = 0;
        
        isMove = +(f+(fr-1)/fPU>=dAM && f+(fr-1)/fPU<(dAM+dMS));
        oP = oP + isMove*[dX,dY]/60/fPU; % update position (mm)
        
        % transform mm into visual angles (deg)
        vaL = pA + atand((oP(1)-oW/2)/pD);
        vaR = pA + atand((oP(1)+oW/2)/pD);
        vaU = atand((oP(2)-oH/2)/sqrt(oP(1)^2+pD^2)); % negative = up, positive = down;
        vaD = atand((oP(2)+oH/2)/sqrt(oP(1)^2+pD^2));
        
        % transform deg into pixel
        pixL = max(round(vaL/numDeg+sizeX/2),1);
        pixR = min(round(vaR/numDeg+sizeX/2),sizeX);
        pixU = max(round(sizeY/2*(2*cR*tand(vaU)/cH + 1)),1);
        pixD = min(round(sizeY/2*(2*cR*tand(vaD)/cH + 1)),sizeY);
        
        % draw the object
        objectMask(pixU:pixD,pixL:pixR) = 1;
        
        % mirroring
        switch mirrorType
            case 0
            case 1
                objectMask = fliplr(objectMask);
            case 2
                objectMask = +( fliplr(objectMask)|objectMask);
        end
        bitMap(:,:,fr) = objectMask*oC + (1-objectMask)*bC;
    end
    
    stimData.objectPosition = oP;
    bitMap =  mLum * ( 1 + bitMap );
    texStr.tex = CreateTexture(bitMap,Q);
end
