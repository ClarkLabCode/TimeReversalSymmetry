function [texStr,stimData] = LightDarkEdgesMirroredHighLow(Q)
    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %when choosing noise values for the sine wave make sure that:
    %noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
    %this insures that 3 std of the noise keeps you below a luminence of 1

    sii = Q.stims.currStimNum;
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;
    floc = Q.flyloc; % could potentially use this to update the stimulus as well

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    numDeg = p.numDeg;
    
    if numDeg == 0
        sizeX = 1;
    else
        sizeX = round(360/numDeg);
    end

    vel = p.velocity*pi/180; % degree/s into rad/s
    distBetweenEdges = p.distBetweenEdges*pi/180; % distance between new in radians
    framesPerUp = p.framesPerUp;
    backgroundLum = p.backgroundLum;
    edgeLum = p.edgeLum;
    
    %% left eye
    if f == 1
        stimData.edgePhase = 0;
        stimData.windowLoc = 2*pi*rand;
    end

    bitMap = zeros(1,sizeX,framesPerUp);
    
    % theta, multiplying by the sign of the velocity will reverse direction
    % of the edge
    theta = linspace(0,2*pi,sizeX)+stimData.windowLoc;
    
    for cc = 1:framesPerUp
        stimData.edgePhase = stimData.edgePhase + vel/(60*framesPerUp);
        
        stimData.edgePhase = mod(stimData.edgePhase,distBetweenEdges);
        
        thetaMod = mod(theta,distBetweenEdges);
        lessThanThetaMod = stimData.edgePhase<thetaMod;
        
        if vel>=0
            bitMap(:,~lessThanThetaMod,cc) = edgeLum;
            bitMap(:,lessThanThetaMod,cc) = backgroundLum;
        else
            bitMap(:,~lessThanThetaMod,cc) = backgroundLum;
            bitMap(:,lessThanThetaMod,cc) = edgeLum;
        end
    end
    
     %% right eye
    if p.twoEyes
        rightEye = fliplr(bitMap);
        
        bitMap = CombEyes(bitMap,rightEye,p,f);
    end
        
    %always include this line in a stim function to make the texture from the
    %bitmap

    texStr.tex = CreateTexture(bitMap,Q);
end
