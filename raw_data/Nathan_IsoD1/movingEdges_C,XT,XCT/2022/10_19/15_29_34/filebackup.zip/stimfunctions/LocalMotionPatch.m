function [texStr,stimData] = LocalMotionPatch(Q)

    % Present small circular envelope with moving sine wave grating
    % to probe regressive motion slowing reported in Zabala et al. (2012).
    % motion can be hemi/bilateral and aperture can be hard-edged/gaussian
    
    % Created Jun 22 2018 by RT

    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %when choosing noise values for the sine wave make sure that:
    %noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
    %this insures that 3 std of the noise keeps you below a luminence of 1

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;
    
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % 9/14 using numDeg = 1 - maybe go high reso?
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    
    %% Input parameters
    % basics
    fPU = p.framesPerUp;
    
    % spatio temporal paramters of targets (all in deg)
    % size of the target
    targR = p.radius; % deg, when gaussian, fwhm
    sigma = targR/sqrt(8*log(2));
    envType = p.envelopeType; % 0 for hard edged circles, 1 for gaussian
    
    % position
    envX = p.envelopeX; % angle(deg) from the central vertical meridian, 0(front) ~ 180(back)
    envY = p.envelopeY; % degree
    envLat = p.envelopeLaterality; % 0 for left, 1 for right, 2 for bilateral
    
    % carrier
    isMirrored = p.isCarrierMirrored; % 0 or 1
    lambda = p.lambda*pi/180; % wavelength in radians
    carVel = p.velocity*pi/180;  % degree/s into rad/s. when mirrored, + for BtF
    carCont = p.carrierContrast; % 0 for mean gray, 1 for full contrast
    carType = p.carrierType; % 0 for sine wave, 1 for square wave
    
    % background
    bgCont = p.backgroundContrast; % -1 to 1
    
    % durations (all in frames = 1/60 sec)
    duration = p.duration;
    
    mLum = p.mLum;
    
    % test grid
    if ~isfield(p,'testgrid')
        testgrid = 0;
    else
        testgrid = p.testgrid;
    end
    
    %% Draw the bitmap

    bitMap  = zeros(sizeY,sizeX,fPU);
    envMask = zeros(sizeY,sizeX);
    
    % prepare background sinewave
    if f == 0 && ~isfield(stimData,'carPhase')
        stimData.carPhase = rand*pi*2; % randomize initial phase
    end
    
    % for carrier wave
    theta = (0:sizeX-1)/sizeX*2*pi; %theta in radians (for background)
    
    % gaze-centered degree map
    azim = ones(sizeY,1)*((1:sizeX)-(sizeX+1)/2);
    alt  = atand(((sizeY:-1:1)'-(sizeY+1)/2)*Q.cylinder.cylinderHeight/sizeY/Q.cylinder.cylinderRadius)*ones(1,sizeX);
    
    for fr = 1:fPU
        % draw carrier
        stimData.carPhase = stimData.carPhase + carVel/(60*fPU);
        stimData.mat(fr) = stimData.carPhase; % not sure if this is necessary
        switch carType
            case 0
                preMap = carCont*ones(sizeY,1)*sin(2*pi*(theta-stimData.carPhase)/lambda);
            case 1
                preMap = carCont*ones(sizeY,1)*...
                         (2*(+(sin(2*pi*(theta-stimData.carPhase)/lambda)>0))-1);
        end
            
        if isMirrored==1
            preMap(:,sizeX/2+1:sizeX) = fliplr(preMap(:,sizeX/2+1:sizeX));
        end
        
        % draw envelope
        d = sqrt((azim+envX).^2+(alt+envY).^2);
        switch envType
            case 0 % hard edged circular envelope
                envMask = d>targR;
            case 1 % gaussian
                envMask = exp(-d.^2/2/(sigma^2));
                envMask = envMask.*(envMask>0.01); % cut off
                envMask = 1-envMask;
            case 2 % square
                envMask = ones(size(d));
                Xfrom = max(round((180-envX-targR)/numDeg),1);
                Xto   = min(round((180-envX+targR)/numDeg),sizeX);
                
                Yfrom = max(round(...
                            sizeY/2*...
                            (2*Q.cylinder.cylinderRadius*tand(envY-targR)/Q.cylinder.cylinderHeight+1)),1);
                Yto   = min(round(...
                            sizeY/2*...
                            (2*Q.cylinder.cylinderRadius*tand(envY+targR)/Q.cylinder.cylinderHeight+1)),sizeY);
                envMask(Yfrom:Yto,Xfrom:Xto) = 0;
        end
        switch envLat
            case 0
            case 1
                envMask = fliplr(envMask);
            case 2
                envMask = fliplr(envMask).*envMask;
        end
        preMap = envMask*bgCont + (1-envMask).*preMap;
        bitMap(:,:,fr) = preMap;
    end
    bitMap =  mLum * ( 1 + bitMap );
    if testgrid == 1
        bitMap(:,round(360/numDeg):round(-15/numDeg):1,:) = -0.5;
        bitMap(round(...
            sizeY/2*(...
            2*Q.cylinder.cylinderRadius*tand(-45:15:45)/Q.cylinder.cylinderHeight+1)),:,:) = -0.5;
    end  
    texStr.tex = CreateTexture(bitMap,Q);
end
