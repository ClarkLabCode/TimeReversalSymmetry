function [texStr,stimData] = SineWaveBars(Q)
    % this stimulus will present a window of sine wave responses between
    % middle gray

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;
    numDeg = p.numDeg;

    if numDeg == 0
        sizeX = 1;
    else
        sizeX = round(360/p.numDeg);
    end

    mlum = p.lum;
    c = p.contrast;
    windowWidth = p.windowWidth;
    
    windowDistanceInd = round(p.windowDistance/numDeg);
    lambda = p.lambda;
    
    tf = p.temporalFrequency;
    
    framesPerUp = p.framesPerUp;

    %% closed loop stuff
    if isfield(p,'CLType')
        [flyTurningSpeed,flyWalkingSpeed,stimData] = GetFlyResponse(Q.timing.framenumber,Q.stims.duration,Q.flyTimeline.curFlyStates,stimData);
        SineWaveClosedLoop;
    end
    
    %% left eye
    %stimData.mat(1) is used as the wave phase. stimData.mat(2) is the velocity which
    %is constant unless noise is added

    if f == 1 && ~isfield(stimData,'sinBarPhase')
        stimData.sinBarPhase = rand*2*pi;
    end
    
    if f == 1 && Q.stims.currStimNum == 1
        stimData.windowPhase = round(rand*sizeX);
    end
    
    phaseOrder = (0:1:round(windowWidth/numDeg)-1)'*numDeg/lambda*2*pi;
    
    if p.reverseWindow
        phaseWindow = [phaseOrder; nan(windowDistanceInd,1); flipud(phaseOrder); nan(windowDistanceInd,1); phaseOrder+pi; nan(windowDistanceInd,1); flipud(phaseOrder)+pi; nan(windowDistanceInd,1)];
    else
        phaseWindow = [phaseOrder; nan(windowDistanceInd,1); phaseOrder+pi; nan(windowDistanceInd,1)];
    end
    
    windowRepeats = ceil(sizeX/length(phaseWindow));
    theta = repmat(phaseWindow,[windowRepeats 1]);
    theta = theta(1:sizeX);
    bitMap = zeros(1,sizeX,framesPerUp);

    for cc = 1:framesPerUp
        stimData.sinBarPhase = stimData.sinBarPhase + 2*pi*tf/(60*framesPerUp);

        bitMap(1,:,cc) = c*sin(theta-stimData.sinBarPhase);

        stimData.mat(cc) = stimData.sinBarPhase;
    end
    
    bitMap(isnan(bitMap)) = 0;

    bitMap = mlum*(1 + bitMap);

    bitMap = circshift(bitMap,[0 stimData.windowPhase]);
    
    %% right eye
    if p.twoEyes
        rightEye = fliplr(bitMap);
        
        bitMap = CombEyes(bitMap,rightEye,p,f);
    end

    %always include this line in a stim function to make the texture from the
    %bitmap

    texStr.tex = CreateTexture(bitMap,Q);
end