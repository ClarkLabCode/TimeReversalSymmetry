function [texStr,stimData] = EvynLoom3(Q)

    % Created 1.25.21
    
    % This function is to present an isovelocity circular loom with a stationary
    % center that changes initial azimuthal positions or elevation position

    p = Q.stims.currParam; % Pulls in the parameter setting from the param text file 
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;
    
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % 9/14 using numDeg = 1 - maybe go high reso?
    cR = Q.cylinder.cylinderRadius;
    cH = Q.cylinder.cylinderHeight;
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(cH/2/cR)/numDeg);
    
    %% Input parameters
    %% things that concern the entire presentation
    
    fPU = p.framesPerUp;
    duration = p.duration; % frames
    mLum = p.mLum;
    
    if isfield(p, 'backgroundContrast')
        bkgdContrast = p.backgroundContrast;
        if isempty(bkgdContrast); bkgdContrast = 0; end
    else
        bkgdContrast = 0;
    end
    
    if isfield(p, 'testgrid')
        testgrid = p.testgrid;
    else
        testgrid = 0;
    end
    
    %% things that concern targets
    
    % center of presentation - all spatial parameters are relative to this
    % the center can be moved by entering numbers in the comment section of
    % the input GUI (otherwise its gonna be set at the actual center)
    
    if f==0
        if ~isempty(Q.condstr) 
            onlineloc = strsplit(Q.condstr,',');
            midX = str2num(onlineloc{1});
            midY = str2num(onlineloc{2});
        else
            midX = 180;
            midY = 0;
        end
        stimData.midX = midX;
        stimData.midY = midY;
    else
        midX = stimData.midX;
        midY = stimData.midY;
    end
    
    
    % sizes (vector)
    iR = p.initialRadius; % deg 
    tR = p.terminalRadius; % deg
    % kinetics parameters
    % relative locations (initial) (vector)
    if isfield(p,'relativeX')
        rX = p.relativeX; % deg
        rY = p.relativeY; % deg
        if isempty(rX) || isempty(rY)
            rX = 0;
            rY = 0;
        end
    else
        rX = 0;
        rY = 0;
    end
    % velocities (vector) *for the center position of the stimuli*
    if isfield(p,'dX')
        dX = p.dX; % deg/s
        dY = p.dY; % deg/s
        if isempty(dX) || isempty(dY)
            dX = 0;
            dY = 0;
        end
    else
        dX = 0;
        dY = 0;
    end
    
    % timings (vector)
    if isfield(p,'loomStartFrame')
        LSF = p.loomStartFrame;
    else
        LSF = 1;
    end
    
    if isfield(p,'loomEndFrame')
        LEF = p.loomEndFrame;
    else
        LEF = duration;
    end
    
    cont = p.targetContrast;
    
    d0 = p.initialDistance;
    v = p.V;
    L = p.L;
    
%     if f == 92
%         disp(length(theta_per))
%     end
    
    %% Draw the bitmap

    bitMap = zeros(sizeY,sizeX,fPU);
    for fr = 1:fPU
        preMap = ones(sizeY,sizeX)*bkgdContrast;
        f2 = f+(fr-1)/fPU; % current time point in "update" unit (1/60s)
        elapsedLooming = min(max(f2 - LSF, 0),LEF-LSF+1); % elapsed time

        CurrTime = elapsedLooming/60; % elapsed time from looming start          
        d = d0 - (v*CurrTime);
        thisRadius = atand(L/d);
        
        targetX = midX + rX + f2*dX/60;
        targetY = midY + rY + f2*dY/60;
        
        [XXdeg,YY] = meshgrid(1:sizeX,(1:sizeY)-sizeY/2);
        YYdeg =  atand(YY*cH/sizeY/cR); % positive angle is down
        mask = sqrt((XXdeg-targetX).^2 + (YYdeg-targetY).^2)<thisRadius;
        
        preMap(mask==1) = cont;
        bitMap(:,:,fr) = preMap;
    end
    
    if testgrid == 1
        bitMap(:,round(360/numDeg):round(-10/numDeg):1,:) = -0.5;
        bitMap(round(...
            sizeY/2*(...
            2*Q.cylinder.cylinderRadius*tand(-50:10:50)/Q.cylinder.cylinderHeight+1)),:,:) = -0.5;
    end    
    bitMap =  mLum * ( 1 + bitMap );
    
    texStr.tex = CreateTexture(bitMap,Q);
end





