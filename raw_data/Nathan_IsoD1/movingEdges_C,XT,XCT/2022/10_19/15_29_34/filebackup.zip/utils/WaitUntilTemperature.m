function WaitUntilTemperature(boxTemperature,port)

%% Commented by RT (5/14/21)
% This function is called by SetupStimulus() (which is called by
% RunMultipleStimulus()) and wait until the rig is heated up to the set
% tempearture before initiating stimulus presentation.
% This function communicate with FTC100D TEC temperature controller through
% a serial port.
% For communication protocol to FTC100D, see the manual
% https://www.tande.com.tw/te-accuthermo/ftc100d-manual/FTC100D%20Communication%20Protocol%20AT100610.pdf

%% First, open a serial port to the FTC100D as specified by sysConfig.
% Communication with FTC100D typically fails after killing the program
% mid-communcation. In such a case, you should run IOPort('CloseAll') and
% close all serial communication, and rerun the program.
try
    [tempPort,~] = IOPort('OpenSerialPort',port,['BaudRate=38400','ReceiveTimeout=1','PollLatency=.001']);
catch
    warning('IOPort:Open','COULD NOT SET TEMPERATURE: COULD NOT OPEN PORT! \nTry running IOPort("CloseAll") and restart program\n');
    return;
end

%% Next, set the set point of FTC100D to the temperature specified by
% sysConfig. This should be typically at 36C.
navailable = IOPort('BytesAvailable', tempPort); % Read whatever in the buffer (ignored)
IOPort('Read',tempPort,1,navailable);
valueSet = 0; % flag that indicates whether the set point is appropriately set
% We are going to make three attempts
for i = 1:3
    % Prepare a command to be sent to FTC100D
    % Command is comprised as
    % <Address 1 byte><Function 1 byte><Starting Address 2 bytes><Data 2 bytes>
    % Our command starts with 01 05 00 00 
    % which stands for <controller #1><write><setpoint value>
    % The following 2 bytes specifies set temperature*10 (so it can
    % represent decimal values)
    % Single byte represents 2 digits hex, hence multiplication by 10
    % followed by division by 256.
    temp = boxTemperature*10;
    command = [uint8(1) uint8(5) uint8([0 0]) uint8([floor(temp/256) temp-floor(temp/256)*256])];
    IOPort('Write',tempPort, command,1);
    % If the controller appropriately registers the command, it should echo
    % it
    readBytes = IOPort('Read',tempPort,1,6);
    if isequal(readBytes,command)
        valueSet = 1;
        break
    end
end
pause(0.1);
navailable = IOPort('BytesAvailable', tempPort);
IOPort('Read',tempPort,1,navailable);
% If all three attempts fails, return warning and continue without heating
if valueSet == 0
    warning('IOPort:read','COULD NOT SET TEMPERATURE! \nPlease check connection and restart program\n');
    IOPort('Close',tempPort);
    return;
end

%% Third, we wait until the rig to be heated up to its set point
currentTemp = 0;
failedReads = 0;
timesCorrect = 0;
while timesCorrect < 1
    % Command read 01 04 10 00 00 01 (in hex!)
    % 01 04 is for read (for read-only variables)
    % Address 10 00 is the process value (= current temp)
    command = [uint8(1) uint8(4) uint8([16 0]) uint8([0 1])];
    IOPort('Write',tempPort, command,1);
    % The first three bytes of the returned message should be 01 04 02
    % The last two digits represents the temperature (in hex)
    readBytes = IOPort('Read',tempPort,1,5);
    if(length(readBytes) == 5)
        % if successfully received the message, show temp
        currentTemp = (readBytes(4)*256+readBytes(5))/10;
        disp(['Current Temperature: ',num2str(currentTemp),' C']);
    else
        % When return message is malformed
        failedReads = failedReads + 1;
    end
    % If fails repeatedly, something is wrong.
    if failedReads > 5
        warning('COULD NOT READ TEMPERATURE! \nPlease restart program\n');
        IOPort('Close',tempPort);
        return;
    end
    % If temperature reading is within .1 deg difference, proceed
    if abs(currentTemp - boxTemperature) > 0.2
        timesCorrect = 0;
    else
        timesCorrect = timesCorrect + 1;
    end
    % Wait for 10 sec or until key is pressed.
    % If key is pressed and it was esc, abort heating and continue
    [~, kbVector, ~] = KbWait([],0,GetSecs()+10);
    if kbVector(27) || kbVector(10)% esc
        fprintf('Warm-up canceled. Continuing');
        IOPort('Close',tempPort);
        return;
    end
end
fprintf('Requested temperature reached. Continuing');
% We do not monitor temperature during experiment.
IOPort('Close',tempPort);

end