function D = ter2dec(T)
%TER2DEC Convert ternary integer to its decimal representation
%   TER2DEC(T) returns the decimal representation of D. T must be a row vector.
D=0;
len=length(T);
for i=len:-1:1
    D=D+T(i)*3^(len-i);
end
end