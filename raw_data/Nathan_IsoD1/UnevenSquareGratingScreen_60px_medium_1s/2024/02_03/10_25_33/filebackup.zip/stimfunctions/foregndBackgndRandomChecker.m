function [texStr,stimData] = foregndBackgndRandomChecker(Q)

% 07/16/20 MA
% Reproduce the stimulus in Drews et al, 2020, Figure 2A


%% Stimulus Parameters %%

p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
stimData = Q.stims.stimData;

texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

epochDuration = p.duration;
numDeg = p.numDeg;

cR = Q.cylinder.cylinderRadius;
cH = Q.cylinder.cylinderHeight;

sizeXDeg = 360;
sizeYDeg = round(2*atand(cH/2/cR));

sizeXPix = round(sizeXDeg/p.numDeg);
sizeYPix = round(sizeYDeg/p.numDeg);

framesPerUp = p.framesPerUp;
mlum=p.mLum;

numberOfStrips=p.numberOfStrips;
orientationOfStrips=p.orientationOfStrips;

if ~orientationOfStrips % horizontal strip
    numberOfStrips=1;
end

epochDurationFrames=round(epochDuration);

% size of checkerboards
checkerSizeDeg = p.checkerSizeDeg;
checkerSizePix = round(checkerSizeDeg/numDeg);
numCheckersX=ceil(sizeXPix/checkerSizePix);
numCheckersY=ceil(sizeYPix/checkerSizePix);
backgndCheckerboardSize = [numCheckersY numCheckersX]; % the size of random matrices to be generated
foregndCheckerboardSize = backgndCheckerboardSize; % the size of random matrices to be generated

% foregnd motion parametes
foregndVelDegPerSec=p.foregndVelDegPerSec;
foregndVelPixPerSec=foregndVelDegPerSec/numDeg;
foregndStaticDurationSec=p.foregndStaticDurationSec;
numFramesStaticForegnd=round(foregndStaticDurationSec*60);
foregndDisplacementPixPerFrame=foregndVelPixPerSec/60/framesPerUp;

% backgnd flicker parameters
backgndFlickerUpdateRate = p.backgndFickerUpdateRate;
numFramesBtwnBackgndUpdates=round(60/backgndFlickerUpdateRate/framesPerUp);

% contrast parameters
backgndContrast=p.backgndContrast;
foregndContrast=p.foregndContrast;

% masks to create foreground and background regions
stripWidthPix=p.stripWidthDeg/numDeg;
[xx,yy]=meshgrid(1:sizeXPix,1:sizeYPix);
strip1LocDeg=90;
strip2LocDeg=270;
strip3LocDeg=180;

strip1LocPix=strip1LocDeg/numDeg;
strip2LocPix=strip2LocDeg/numDeg;
strip3LocPix=strip3LocDeg/numDeg;

switch orientationOfStrips
    case 0 % 1 horizontal strip at the horizont
        backgndRegion=((yy>((sizeYPix/2)+stripWidthPix/2)) | (yy<((sizeYPix/2)-stripWidthPix/2)))...
            & ((yy>((sizeYPix/2)+stripWidthPix/2)) | (yy<((sizeYPix/2)-stripWidthPix/2)));
        
    case 90 % 2 or 3 vertical strips
        switch numberOfStrips
            case 2
                backgndRegion=((xx>(strip1LocPix+stripWidthPix/2)) | (xx<(strip1LocPix-stripWidthPix/2)))...
                    & ((xx>(strip2LocPix+stripWidthPix/2)) | (xx<(strip2LocPix-stripWidthPix/2)));
            case 3
                backgndRegion=((xx>(strip1LocPix+stripWidthPix/2)) | (xx<(strip1LocPix-stripWidthPix/2)))...
                    & ((xx>(strip2LocPix+stripWidthPix/2)) | (xx<(strip2LocPix-stripWidthPix/2)))...
                    & ((xx>(strip3LocPix+stripWidthPix/2)) | (xx<(strip3LocPix-stripWidthPix/2)));
        end
end
foregndRegion=~backgndRegion;

if f == 0
    % create random checkerboard foreground
    foregndCheckersMini=foregndContrast*(2*randi(2,foregndCheckerboardSize)-3);
    foregndCheckers=imresize(foregndCheckersMini,checkerSizePix,'box');
    foregndCheckersCut2Size=foregndCheckers(1:sizeYPix,1:sizeXPix);
    stimData.foregndCheckersCut2Size=foregndCheckersCut2Size;
    foregndPos=[0 0];
    stimData.foregndPos = foregndPos;
else
    foregndCheckersCut2Size=stimData.foregndCheckersCut2Size;
    foregndPos = stimData.foregndPos;
    backgndCheckersCut2Size=stimData.backgndCheckersCut2Size;
end

bitMap = zeros(sizeYPix,sizeXPix,framesPerUp);
for cc=1:framesPerUp
    % update background flicker
    if ~mod(f,2*numFramesBtwnBackgndUpdates) && cc==1
        backgndCheckersMini=backgndContrast*(2*randi(2,backgndCheckerboardSize)-3);
        backgndCheckers=imresize(backgndCheckersMini,checkerSizePix,'box');
        backgndCheckersCut2Size=backgndCheckers(1:sizeYDeg,1:sizeXDeg);
        stimData.backgndCheckersCut2Size = backgndCheckersCut2Size;
    else
        backgndCheckersCut2Size=stimData.backgndCheckersCut2Size;
    end
    
    % move the foreground
    if (f>=numFramesStaticForegnd && f<(epochDurationFrames-numFramesStaticForegnd))
        foregndPos = foregndPos + [0 foregndDisplacementPixPerFrame];
        temp=circshift(foregndCheckersCut2Size,round(foregndPos));
        stimData.foregndPos = foregndPos;
    else
        foregndPos=stimData.foregndPos;
        temp=circshift(foregndCheckersCut2Size,round(foregndPos));
    end
    bitMap(:,:,cc)=backgndCheckersCut2Size.*backgndRegion+...
        temp.*foregndRegion;
end
bitMap=mlum*(1+bitMap);
texStr.tex = CreateTexture(bitMap,Q);
end
