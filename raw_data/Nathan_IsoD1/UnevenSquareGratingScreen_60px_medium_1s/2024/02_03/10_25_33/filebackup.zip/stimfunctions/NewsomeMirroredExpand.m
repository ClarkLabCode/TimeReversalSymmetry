function [texStr,stimData] = NewsomeMirroredExpand(Q)
    %There are a couple things that should be noted about your choice for flick
    %and mot. The ratio of mot to flick can never be greater than 1:2. The
    %final contrast of the stimulus is = sqrt(flicker)
    %so try to keep the contrast below 0.5 so that 2 standard deviations of the
    %mean are between max and min. put it at 0.33 for 3 standard deviations
    
    texStr.opts = 'full'; % see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.sii = Q.stims.currStimNum;
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;
    desiredDensity = p.density;
    componentDensity = 1-(1-desiredDensity).^(1/3);
    c = p.contrast;
    
    % This allows for either an updateRate approach (in Hz) or an update
    % field (in frames)--the updateRate field takes precedence!
    if isfield(p, 'updateRate')
        update = (60*p.framesPerUp)/p.updateRate;
    elseif isfield(p, 'update')
        update = p.update;
    end
    
    if rem(update,1) ~= 0
        error('update is less than 1, check requrested update rate and framesPerUp');
    end
    
    delay = p.delay;
    dirX = p.dirX; %direction and amplitude of the motion
    dirY = p.dirY;
    framesPerUp = p.framesPerUp;
    if p.numDegX == 0
        sizeX = 1;
    else
        sizeX = round(360/p.numDegX);
    end
    
    if p.numDegY == 0
        sizeY = 1;
    else
        sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDegY*pi/180)));
    end
    
    phi = p.phi;
    mlum = p.lum;

    maxDelay = 0;

    if f == 1
        % in the first frame of this epoch see whether the sin wave subfields
        % exist. if they don't initialize them. If they already exist they will
        % be used in the normal loop below to be continuous between epochs
        if ~isfield(stimData,'I1') || sizeY ~= size(stimData.I1, 1) || sizeX ~= size(stimData.I1, 2)
            for ii = 1:size(Q.stims.params,2)
                % add 1 to max delay because to correlate at the max delay you need
                % stimData.mat(maxDelay+1)
                
                if Q.stims.params(ii).delay >= maxDelay
                    maxDelay = Q.stims.params(ii).delay + 1;
                end
            end
            
            % same process as above, but has third dimension maxDelay
            stimData.I1 = 2*round(rand(sizeY,sizeX,maxDelay))-1;
            maskMat = rand(sizeY,sizeX,maxDelay)<componentDensity;
            stimData.I1 = stimData.I1.*maskMat;
            
            % creates a zeros matrix of same dimension
            stimData.corrMat1 = zeros(size(stimData.I1));
            stimData.corrMat2 = zeros(size(stimData.I1));
        end
    end

    %%%%% note this stimulus is designed so that the first correlation occurs
    %%%%% on the first timepoint of a new epoch, but this does NOT work if
    %%%%% there is an updateL difference between the two epochs

    bitMap = zeros(sizeY,sizeX,framesPerUp);
    hzFrame = f*framesPerUp-(framesPerUp-1):f*framesPerUp;
    % creates an array of (0 0 0 ... 1) where the one tell you to update
    updateFrame = mod(hzFrame-1,update) == 0;

    for cc = 1:framesPerUp
        if updateFrame(cc)
            % create a new matrix at front and shift all the left eye
            % matricies back one. Keep all right eye matricies untouched.
            % Appened a new white noise left eye matrix to the end and keep
            % the white noise right eye matrix
            newMat1 = 2*round(rand(sizeY,sizeX))-1;
            maskMat1 = rand(sizeY,sizeX)<componentDensity;
            newMat1 = newMat1.*maskMat1;
            stimData.I1 = cat(3,newMat1,stimData.I1(:,:,1:end-1));
            
            if delay == 0 && dirX == 0 && dirY == 0
                stimData.corrMat1 = 2*round(rand(sizeY,sizeX))-1;
                maskMat1 = rand(sizeY,sizeX)<componentDensity;
                stimData.corrMat1 = stimData.corrMat1.*maskMat1;
                
                stimData.corrMat2 = 2*round(rand(sizeY,sizeX))-1;
                maskMat2 = rand(sizeY,sizeX)<componentDensity;
                stimData.corrMat2 = stimData.corrMat2.*maskMat2;
            else
                stimData.corrMat1 = phi*circshift(stimData.I1(:,:,delay+1),[dirY,dirX]);
                stimData.corrMat2 = phi*circshift(stimData.I1(:,:,delay+1),[dirY,-dirX]);
            end
        end

        bitMap(:,:,cc) = c*SuperImposeRand(stimData.I1(:,:,1),stimData.corrMat1,stimData.corrMat2);
    end
    
    bitMap = mlum*(bitMap+1);

    if p.twoEyes
        rightEye = fliplr(bitMap);
        
        bitMap = CombEyes(bitMap,rightEye,p,f);
    end

    %always include this line in a stim function to make the texture from the
    %bitmap
    texStr.tex = CreateTexture(bitMap,Q);
end
