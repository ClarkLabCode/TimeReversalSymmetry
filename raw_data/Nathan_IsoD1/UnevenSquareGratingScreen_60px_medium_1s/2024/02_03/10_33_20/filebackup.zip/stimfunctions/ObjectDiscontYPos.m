function [texStr,stimData] = ObjectDiscontYPos(Q)

% NOTE: when you create a new stimulus function, you must update the
% stimlookup table in the folder paramfiles. paramfiles will also hold the
% text file giving lists of parameters that comprise an experiment

%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam; 

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1; 

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

% Reading everything from the paramfile
mlum        = p.mlum;
vel         = p.direction * p.vel; %velocity in deg/s
width       = p.width;             %width of square or bar in deg
squareH     = p.squareHeight;
bufferH     = p.bufferH;
offset      = p.blockOffset;
totalUnitH  = width + bufferH;
numBlocks   = ceil(sizeY/totalUnitH);
objType     = p.objType;
framesPerUp = p.framesPerUp; % how many frames you have / update (usually 3)
barPolarity = p.barPolarity;
squareCentered = p.squareCentered; % 1 for yes, 0 for no
squareYpos = p.squareYpos ;
% You are going to store the X-position of the object in stimData.currPos
% field. This will be communicated to subsequent calls of this function
if f == 1 % if this is the first frame of epoch... 
    switch p.direction
        case 1
            stimData.currPos = 1;
        case -1
            stimData.currPos = 360;
    end
end

% Displacement per frame 
dispPerFrame = vel/60/framesPerUp;
xpos = 1:sizeX;
ypos = 1:sizeY;

switch objType

    case 0 % continuous vertical bar
        % You overwrite sizeY so that you only have 1 px height
        bitMap = zeros(1,length(xpos),framesPerUp);
        % Go through all the #framesPerUp frames in each update
        for cc = 1:framesPerUp
            if stimData.currPos > max(xpos)
                stimData.currPos = mod(stimData.currPos, max(xpos));
            elseif stimData.currPos < 0
                stimData.currPos = max(xpos)+stimData.currPos;
            end
            s = xpos<stimData.currPos;
            e = xpos>(stimData.currPos + width-1);
            bitMap(1,~(s | e),cc) = barPolarity;
            stimData.currPos = stimData.currPos + dispPerFrame;
        end

    case 1 % discontinous vertical bar, with our without offset
        yblock = ypos(1:find(ypos>=totalUnitH,1));
        bitMap = zeros(length(xpos),length(ypos),framesPerUp);
        for cc = 1:framesPerUp
            if stimData.currPos > max(xpos)
                stimData.currPos = mod(stimData.currPos, max(xpos));
            elseif stimData.currPos < 0
                stimData.currPos = max(xpos)+stimData.currPos;
            end
            preMap1 = zeros(length(xpos),length(yblock));
            sx = xpos<stimData.currPos;
            ex = xpos> (stimData.currPos + width-1);
            sy = yblock<0;
            ey = yblock>width-1;
            preMap1 (~(sx | ex) , ~(sy | ey)) = barPolarity;
            preMap1 = [preMap1 zeros(size(preMap1))];
            preMap2 = circshift(preMap1,[round(offset),length(yblock)]);
            preMap = preMap1 + preMap2;
            preMap = repmat(preMap,1,ceil(numBlocks/2));
            preMap = circshift(preMap,[0,-bufferH]);
            preMap = preMap(:,round((size(preMap,2)/2-length(ypos)/2)+1):round(size(preMap,2)/2+length(ypos)/2));
            bitMap(:,:,cc) = preMap;
            stimData.currPos = stimData.currPos + dispPerFrame;
        end
        bitMap = permute(bitMap,[2 1 3]);

    case 2 % square
        bitMap = zeros(length(xpos),length(ypos),framesPerUp);
        for cc = 1:framesPerUp
            if stimData.currPos > max(xpos)
                stimData.currPos = mod(stimData.currPos, max(xpos));
            elseif stimData.currPos < 0
                stimData.currPos = max(xpos)+stimData.currPos;
            end
            preMap = zeros(length(xpos),length(ypos));
            sx = xpos<stimData.currPos;
            ex = xpos> (stimData.currPos + width-1);
            sy = ypos<0;
            ey = ypos> squareH-1;
            preMap (~(sx | ex) , ~(sy | ey)) = barPolarity;
            if squareCentered == 1
            preMap = circshift(preMap,[0,round(length(ypos)/2-width/2)]);
            else
            preMap = circshift(preMap,[0,squareYpos]);    
            end
            bitMap(:,:,cc) = preMap;
            stimData.currPos = stimData.currPos + dispPerFrame;
        end
        bitMap = permute(bitMap,[2 1 3]);
end
bitMap = mlum*(1 + bitMap);

%always include this line in a stim function to make the texture from the
%bitmap

texStr.tex = CreateTexture(bitMap,Q);
end