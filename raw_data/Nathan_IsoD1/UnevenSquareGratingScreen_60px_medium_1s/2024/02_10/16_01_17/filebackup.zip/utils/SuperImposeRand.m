function finalMat = SuperImposeRand(varargin)
    numMat = length(varargin);
    matOrder = randperm(numMat);
    matricies = Columnize(varargin(matOrder));

    finalMat = matricies{1};
    
    for mm = 2:numMat
        finalMat(finalMat==0) = matricies{mm}(finalMat==0);
    end
end