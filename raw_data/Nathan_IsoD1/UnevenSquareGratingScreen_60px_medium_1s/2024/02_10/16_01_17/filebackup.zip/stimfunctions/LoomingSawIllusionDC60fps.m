
function [texStr,stimData] = LoomingSawIllusionDC60fps(Q)

%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
% input from user
numDeg = p.numDeg;
fPU = p.framesPerUp; % framesPerUp
mlum = p.mlum;
isincrease = p.isincrease;
background = p.background; % 0, gray, -1 black, 1 white
loomStartFrame = p.loomStartFrame;

%% Define parameters
P=p.period; %period in s
T=P*60; %Convertit to frames
del=1/T; %Offset Increament in each frame

%% Define Duty Cycle
DC=p.DC;
if DC~=0||DC~=1
S1=(2)/(DC);
S2=(-2/(1-DC));
In1=(1-(DC*S1));
In2=(1-(DC*S2));
end

%% Define Piecewise Linear Functions
if DC==1
    fun = @(x) (x == 0).*(-1)+(0 < x).*(-1+2*x);
elseif DC==0
    fun = @(x) (x == 0).*(1)+(0 < x).*(1-2*x);
else
    fun = @(x) (x <= DC).*(S1*x+In1) +(DC < x).*(In2+S2*x);
end

%duration = p.duration;
r = p.radius;
% a = p.xcoordinate;
% b = p.ycoordinate;
sync= p.sync;
fPU = p.framesPerUp; % framesPerUp


% %% Define Grid
% r=round(sizeY/25);


if ~isfield(p,'GridSize')
    n=5;
else
    n = p.GridSize; % degree/s into rad/s
end

ledge=p.xcoordinate-n*r;
redge=p.xcoordinate+n*r;
upedge=-n*r;
doedge=+n*r;

a =[ledge+r:2*(r):redge-r];% p.xcoordinate;
b =[upedge+r:2*(r):doedge-r];%p.ycoordinate;

[A,B] = meshgrid(a,b);
% xx = [1:sizeX];
% yy = [1:sizeY];
% [X,Y] = meshgrid(xx,yy);

%
cR = Q.cylinder.cylinderRadius;
cH = Q.cylinder.cylinderHeight;

[X,YY] = meshgrid(1:sizeX,(1:sizeY)-sizeY/2);
Y =  atand(YY*cH/sizeY/cR); % positive angle is down


%% Create offsets
if f==1
offset = (randperm(numel(A))-1)/(numel(A)-1);
offset = offset + 1E-10*(~offset);
offset = offset - 1E-10*(offset == 1);
%% Create Maps
circ =zeros(sizeY, sizeX);
for i_circ = 1:numel(A)
    circ =    circ + offset(i_circ)*((X-A(i_circ)).^2 /(r*r)+ ((Y-B(i_circ)).^2)/(r*r) < 1);
end
stimData.circ_mask = (circ ~= 0);
% circ(~stimData.circ_mask)=background;
stimData.LinearMap =reshape(circ,[sizeX*sizeY,1]);
patt=fun(stimData.LinearMap);
circ=reshape(patt,[sizeY,sizeX]);
circ(~stimData.circ_mask)=background;
stimData.premap=circ;
end

bitMap= zeros(sizeY,sizeX,fPU);


if f >= loomStartFrame
    stimData.LinearMap=mod(stimData.LinearMap+(del),1);
    patt=fun(stimData.LinearMap);
    circ=reshape(patt,[sizeY,sizeX]);
    circ(~stimData.circ_mask)=background;
    stimData.premap=circ;
end
bitMap = repmat(stimData.premap, 1, 1, fPU);


%always include this line in a stim function to make the texture from the
%bitmap
bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);


end