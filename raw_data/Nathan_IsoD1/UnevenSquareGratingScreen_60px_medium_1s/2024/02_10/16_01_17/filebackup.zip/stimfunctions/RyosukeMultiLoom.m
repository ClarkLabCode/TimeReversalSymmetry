function [texStr,stimData] = RyosukeMultiLoom(Q)

    % Created 11/20/21
    % Present multiple linearly expanding loom stimuli to study escape
    % decision making processes etc.
    % Removed "read comments" features -- this is just for behavior
    
    % Organize basic input arguments
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;
    
    % Variables that define the size of the bitmap
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    cR = Q.cylinder.cylinderRadius;
    cH = Q.cylinder.cylinderHeight;
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(cH/2/cR)/numDeg);
    
    %% Load stimulus parameters
    % background related
    fPU = p.framesPerUp;   % temporal resolution parameter
    duration = p.duration; % in frames
    mLum = p.mLum;         % mean luminance
    bkgdContrast = p.backgroundContrast;
    
    % loom related parameters defined for each looming disc
    % these variables can comma separated multiple values
    cont = p.targetContrast;  
    iR   = p.initialRadius;     % deg 
    tR   = p.terminalRadius;    % deg
    iX   = p.initialX;          % deg (zero-centered)
    iY   = p.initialY;          % deg (zero-centered)
    Vx   = p.velocityX;         % deg/s
    Vy   = p.velocityY;         % deg/s
    LSF  = p.loomStartFrame;
    LEF  = p.loomEndFrame;
    loomAtributeNames = {'cont','iR','tR','iX','iY','Vx','Vy','LSF','LEF'};
    
    % decide the number of looming discs to present based on the longest
    % parameter
    nLoom = 1;
    for aa = 1:length(loomAtributeNames)
        nLoom = max(nLoom, length(eval(loomAtributeNames{aa})));
    end
    
    % extend ones that are too short         
    for aa = 1:length(loomAtributeNames)
        if eval(['length(',loomAtributeNames{aa},')'])<nLoom
            eval([loomAtributeNames{aa}, '(end+1:nLoom) =', loomAtributeNames{aa}, '(end);']);
        end
    end
    
    % Show grids if this is set to 1 (just for debugging purpose)
    if isfield(p, 'testgrid')
        testgrid = p.testgrid;
    else
        testgrid = 0;
    end
    
    
    %% Draw the bitmap
    bitMap = zeros(sizeY,sizeX,fPU);
    % prepare X/Y grids
    [XXdeg,YY] = meshgrid((1:sizeX)-sizeX/2,(1:sizeY)-sizeY/2);
    YYdeg =  atand(YY*cH/sizeY/cR); % positive angle is down
    
    for fr = 1:fPU
        preMap = ones(sizeY,sizeX)*bkgdContrast;
        f2 = f+(fr-1)/fPU; % current time point in "update" unit (1/60s)
        
        % loop through the discs
        
        for ll = 1:nLoom
            thisElapsedLooming = min(max(f2 - LSF(ll), 0),LEF(ll)-LSF(ll)+1);
            thisRadius = iR(ll) + (tR(ll)-iR(ll))*thisElapsedLooming/(LEF(ll)-LSF(ll)+1);
            thisX = iX(ll) + f2*Vx(ll)/60;
            thisY = iY(ll) + f2*Vy(ll)/60;
            mask = sqrt((XXdeg-thisX).^2 + (YYdeg-thisY).^2)<thisRadius;
            preMap(mask==1) = cont(ll);
        end
        
        bitMap(:,:,fr) = preMap;
    end
    
    if testgrid == 1
        bitMap(:,round(360/numDeg):round(-10/numDeg):1,:) = -0.5;
        bitMap(round(...
            sizeY/2*(...
            2*Q.cylinder.cylinderRadius*tand(-50:10:50)/Q.cylinder.cylinderHeight+1)),:,:) = -0.5;
    end    
    bitMap =  mLum * ( 1 + bitMap );
    
    texStr.tex = CreateTexture(bitMap,Q);
end
