function [texStr,stimData] = DanielGrating(Q)

%% Parameters
p = Q.stims.currParam;
f = Q.timing.framenumber - Q.timing.framelastchange + 1;
stimData = Q.stims.stimData;
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

%%
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
fPU = p.framesPerUp; % framesPerUpppp

[XX,YY] = meshgrid(1:sizeX,(1:sizeY));
mlum = p.mlum;
contrast = p.contrast;
bagContrast=p.bagContrast;

%%
if ~isfield(p,'temporalFrequency')
    vel = p.velocity*(pi/180); % rad/s
    vel=vel/60;% rad/frame
    v=vel/fPU;% rad/fPU
    lambda=p.lambda*pi/180;
else
    
    vel = p.temporalFrequency*p.lambda*(pi/180);
    vel=vel/60;
    v=vel/fPU;
    lambda=p.lambda*pi/180;
end

theta = (XX-1)/sizeX*2*pi; %theta in radians

bitMap= ones(sizeY,sizeX,fPU)*bagContrast;

for fr = 1:fPU
    
         preMap = ones(sizeY,sizeX)*bagContrast;
        t = (f-1)*(fPU) + fr; % index for all fPU
        bitMap(:,:,fr)=(sin(2*pi*(theta-v.*t)/lambda))*contrast;
    
end
bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);

end

