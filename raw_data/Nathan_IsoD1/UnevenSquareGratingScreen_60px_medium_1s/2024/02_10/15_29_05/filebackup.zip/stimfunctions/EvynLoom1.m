function [texStr,stimData] = EvynLoom1(Q)

    % Created 01/21/2021
    
    % This function is to present an isovelocity loom with stationary or
    % moving center

    p = Q.stims.currParam; % current epoch stim params
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number (zero indexed)
    stimData = Q.stims.stimData; % retreived by RunMultipleStim and RunStimuli 
    
    numDeg = p.numDeg; % pixels to visual angle conversion (norm: 1 pixel=1 degree)

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % dimension of visual stimuli (e.g. bar = 1, full screen flash = 0)
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % 9/14 using numDeg = 1 - maybe go high reso?
    cR = Q.cylinder.cylinderRadius; %virtual cylindar radius
    cH = Q.cylinder.cylinderHeight; %virtual cylindar height
    sizeX = round(360/numDeg); % total number of pixels for X-axis
    sizeY = round(2*atand(cH/2/cR)/numDeg); % total number of pixels for Y-axis (transformed to account for increasing distance from fly)
    
    %% Input parameters
    %% Must be consistent across all epoch presentations
    
    fPU = p.framesPerUp; % 3 typically  -- each visual frame includes 3 repeat frames (e.g. downsampling)
    duration = p.duration; % frames
    mLum = p.mLum; % mean luminance -- overall light intensity scaling (luminance gain)
    
    if isfield(p, 'backgroundContrast')
        bkgdContrast = p.backgroundContrast;
        if isempty(bkgdContrast); bkgdContrast = 0; end
    else
        bkgdContrast = 0; % the background color -- eventually scaled by the luminence value
    end
    
    if isfield(p, 'testgrid') %for debug/ quality control of angular scaling
        testgrid = p.testgrid;
    else
        testgrid = 0;
    end
    
    %% things that concern targets
    
    % center of presentation - all spatial parameters are relative to this
    % the center can be moved by entering numbers in the comment section of
    % the input GUI (otherwise its gonna be set at the actual center)
    
    if f==0 %used to dynamically update the 'center' position of the grid for individual cell receptive fields
        if ~isempty(Q.condstr) 
            onlineloc = strsplit(Q.condstr,',');
            midX = str2num(onlineloc{1});
            midY = str2num(onlineloc{2});
        else
            midX = 180;
            midY = 0;
        end
        stimData.midX = midX;
        stimData.midY = midY;
    else
        midX = stimData.midX;
        midY = stimData.midY;
    end
    
    % sizes (vector)
    iR = p.initialRadius; % stimulus start radius (for a circle) 
    tR = p.terminalRadius; % stimulus end radius (for a circle)
    % kinetics parameters
    % relative locations (initial) (vector)
    if isfield(p,'relativeX')
        rX = p.relativeX; % deg (position on the screen relative to 0,0)
        rY = p.relativeY; % deg
        if isempty(rX) || isempty(rY)
            rX = 0;
            rY = 0;
        end
    else 
        rX = 0;
        rY = 0;
    end
    % velocities (vector) of the position origin over time (not expansion contraction)
    if isfield(p,'dX')
        dX = p.dX; % deg/s
        dY = p.dY; % deg/s
        if isempty(dX) || isempty(dY)
            dX = 0;
            dY = 0;
        end
    else
        dX = 0;
        dY = 0;
    end
    
    % timings (vector)
    if isfield(p,'loomStartFrame')
        LSF = p.loomStartFrame;
    else
        LSF = 1;
    end
    
    if isfield(p,'loomEndFrame')
        LEF = p.loomEndFrame;
    else
        LEF = duration;
    end
    
    cont = p.targetContrast; % color of the stimulus contrast relative to zero (object color)
    
    %% Draw the bitmap

    bitMap = zeros(sizeY,sizeX,fPU);
    for fr = 1:fPU
        preMap = ones(sizeY,sizeX)*bkgdContrast; %blank template frame
        f2 = f+(fr-1)/fPU; % current time point in "update" unit (1/60s)
        elapsedLooming = min(max(f2 - LSF, 0),LEF-LSF+1);
        %the updated size of the loom radius for the frame
        thisRadius = iR + (tR-iR)*elapsedLooming/(LEF-LSF+1);  
        
        % update the position and size of the stimulus:
        targetX = midX + rX + f2*dX/60; % zero pos + pos offset + (time point*velocity)/frequency
        targetY = midY + rY + f2*dY/60;
        
        % make a blank grid with the degree values (transformed by the cylinder size appropriately
        [XXdeg,YY] = meshgrid(1:sizeX,(1:sizeY)-sizeY/2); %blank grid of degree information
        YYdeg =  atand(YY*cH/sizeY/cR); % positive angle is down % transform the pixel number to degrees from fly
        
        % vertical bar:
        a = abs(YYdeg-targetY)<thisRadius;
        b = abs(XXdeg-targetX)<iR;
        Vert_mask = a & b;
        
        % horizontal bar:
        a = abs(YYdeg-targetY)<iR;
        b = abs(XXdeg-targetX)<thisRadius;
        Hor_mask = a & b; 
        
        %selected dimension that expands:
        if p.dimX == true && p.dimY == false
            mask = Hor_mask;
        elseif p.dimY == true && p.dimX == false
            mask = Vert_mask;
        elseif p.dimY == true && p.dimX == true
            mask = Hor_mask | Vert_mask;
        else
            mask = zeros(sizeY,sizeX);
        end
        
        preMap(mask==1) = cont;
        bitMap(:,:,fr) = preMap;
    end
    % for visual comparison of stimulus alignment (for debugging / quality control)
    if testgrid == 1
        bitMap(:,round(360/numDeg):round(-10/numDeg):1,:) = -0.5;
        bitMap(round(...
            sizeY/2*(...
            2*Q.cylinder.cylinderRadius*tand(-50:10:50)/Q.cylinder.cylinderHeight+1)),:,:) = -0.5;
    end    
    bitMap =  mLum * ( 1 + bitMap ); %luminence scaling
    
    texStr.tex = CreateTexture(bitMap,Q);
end
