function [texStr,stimData] = DanielLoomPrioritization(Q)

%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
% input from user

numDeg = p.numDeg;
fPU = p.framesPerUp; % framesPerUp
mlum = p.mlum;
contrast = p.contrast;
cond=p.cond;
contra=p.contra;
% so if the vel is 180 deg/60f, you use this info to calculate how many
% seconds you want for that amplitude.
% x(duration) = 60*amplitude / vel

%Loom size
iR= p.initialRadius;
fR=p.finalRadius;

% Looming velocity
v=(p.velocity/60);
% looming duration
 LSF = p.loomStartFrame;%loom start frame
 
 dur=(fR-iR)/v;
 LEF=LSF+dur;

%position on the screen
rX=p.xPosition;
rY=round(sizeY/2);

%% Initializing BitMap
[XX,YY] = meshgrid(1:sizeX,(1:sizeY));
bitMap= zeros(sizeY,sizeX,fPU);
trial=1;

for fr = 1:fPU
    
    if f>=LEF+60 && f<LEF+120
        radius=iR;
        trial=2;
        end
        
    if f>=LEF+120 &&f<=LEF+120+dur
        t = (f-1)*fPU + fr; % index for all fPU
        radius=round(iR+(v/3)*(t-((LEF+120-1)*fPU)));  
        trial=2;
    end

    
    if f>=LSF &&f<LEF
        t = (f-1)*fPU + fr; % index for all fPU
        radius=round(iR+(v/3)*(t-((LSF-1)*fPU)));
    elseif f<LSF
        radius=iR;
    elseif f>= LEF&&f<LEF+60
        radius=0;
        
    end

    if radius>0
        preMap = zeros(sizeY,sizeX);

        if cond==2 && trial==2
            rX=90;
            mask = sqrt((XX-rX).^2 + (YY-rY).^2)<radius | sqrt((XX-rX-180).^2 + (YY-rY).^2)<radius;

        elseif contra==1 && trial==2 && cond==0
            if p.xPosition==90
                rX=270;
            elseif p.xPosition==270
                rX=90;
            end
            mask = sqrt((XX-rX).^2 + (YY-rY).^2)<radius;
            
            %disp(['cond: ' num2str(cond) ', trial: ' num2str(trial) ', rX: ' num2str(rX) ', radius: ' num2str(radius) ', contrast: ' num2str(contrast)]);

        else
            mask = sqrt((XX-rX).^2 + (YY-rY).^2)<radius;
        end

        preMap(mask==1) = contrast;

        bitMap(:,:,fr) = preMap;
    end
    
end
bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);

end