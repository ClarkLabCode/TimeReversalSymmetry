function [texStr,stimData] = SnakeJoe(Q)
    % bar equivalent of snake illusion

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;
    
    if p.numDeg == 0
        sizeX = 1;
    else
        sizeX = round(360/p.numDeg);
    end
    
    vertTiles = p.vertTiles;    % Change this value for the number of vertical panels
    fracShift = p.fracShift;    % Fraction of a wavelength to horizontally shift each panel by

    phaseShift = 2*pi*rand;     % Used to provide random phase shift for each epoch
    
    % Stores the random number in stimData.phase and only updates at
    % beginning of each epoch
    if f == 1
        stimData.phase = phaseShift;
    else
        stimData.phase = stimData.phase;
    end
    
    mlum = p.lum;
    c = p.contrast;
    
    lambda = abs(p.lambda*pi/180); %wavelength in radians
    framesPerUp = p.framesPerUp;

    %%
    theta = mod((0:sizeX-1)/sizeX*2*pi + stimData.phase, 2*pi); %theta in radians (with phase shift)
%   theta = (0:sizeX-1)/sizeX*2*pi;     Uncomment this line if no phaseShift is desired
    bitMap = zeros(vertTiles,sizeX,framesPerUp);
    
    for cc = 1:framesPerUp
        %% This inner for-loop is for making horizontal rows (if vertTiles != 1)
        for ii = 1:vertTiles
            bitMap(ii,:,cc) = c*(-1*heaviside(mod(theta-(ii)*fracShift*lambda,lambda))+...
                                2/3*heaviside(mod(theta-(ii)*fracShift*lambda,lambda)-lambda/4)+...
                                4/3*heaviside(mod(theta-(ii)*fracShift*lambda,lambda)-lambda/2)+...
                               -2/3*heaviside(mod(theta-(ii)*fracShift*lambda,lambda)-3*lambda/4)+...
                                 -1*eq((mod(theta-(ii)*fracShift*lambda,lambda)),0)+...
                                2/3*eq((mod(theta-(ii)*fracShift*lambda,lambda)-lambda/4),0)+...
                                4/3*eq((mod(theta-(ii)*fracShift*lambda,lambda)-lambda/2),0)+...
                               -2/3*eq((mod(theta-(ii)*fracShift*lambda,lambda)-3*lambda/4),0));
        %% Heaviside used for bar shape, eq used to deal with bar edges
        end
    end

    bitMap = mlum*(1 + bitMap);
    
    %% Flips direction if lambda < 0
    if p.lambda < 0
        bitMap = fliplr(bitMap);
    end

    %always include this line in a stim function to make the texture from the
    %bitmap

    texStr.tex = CreateTexture(bitMap,Q);
end