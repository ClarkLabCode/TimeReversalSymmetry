function [texStr,stimData] = LoomAndGrating(Q)

%% Parameters
p = Q.stims.currParam;
f = Q.timing.framenumber - Q.timing.framelastchange + 1;
stimData = Q.stims.stimData;
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

%%
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix
%%
[XX,YY] = meshgrid(1:sizeX,(1:sizeY));
fPU = p.framesPerUp; % framesPerUp
mlum = p.mlum;
contrast = p.contrast;
c = p.GratingContrast;
bagContrast=p.bagContrast;

%Loom size
iR= p.initialRadius;
fR=p.finalRadius;

% Looming velocity
vL=(p.velocity/60);
% looming duration
LSF = p.loomStartFrame;%loom start frame

dur=(fR-iR)/vL;
LEF=LSF+dur;

%position on the screen
rX=p.xPosition;
rY=round(sizeY/2);

if ~isfield(p,'temporalFrequency')
    vel = p.velocity*(pi/180); % rad/s
    vel=vel/60;% rad/frame
    v=vel/fPU;% rad/fPU
    lambda=p.lambda*pi/180;
else
    
    vel = p.temporalFrequency*p.lambda*(pi/180);
    vel=vel/60;
    v=vel/fPU;
    lambda=p.lambda*pi/180;
    
    
end

theta = (XX-1)/sizeX*2*pi; %theta in radians
bitMap= ones(sizeY,sizeX,fPU)*bagContrast;

for fr = 1:fPU
    
    preMap = ones(sizeY,sizeX)*bagContrast;
    if f>LEF+60
        radius=0;
        t = (f-(LEF+60))*(fPU) + fr; % index for all fPU
        bitMap(:,:,fr)=(sin(2*pi*(theta-v.*t)/lambda))*c;
    end
    
    if f>LSF &&f<LEF
        t = (f-1)*fPU + fr; % index for all fPU
        radius=round(iR+(vL/fPU)*(t-((LSF-1)*fPU)));
    elseif f<=LSF
        radius=iR;
    elseif f>= LEF&&f<=LEF+60
        radius=0;
    end
    
    if radius>0
        
        [XX,YY] = meshgrid(1:sizeX,(1:sizeY));
        mask = sqrt((XX-rX).^2 + (YY-rY).^2)<radius;
        preMap(mask==1) = contrast;
        bitMap(:,:,fr) = preMap;
    end
    
end
bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);

end

