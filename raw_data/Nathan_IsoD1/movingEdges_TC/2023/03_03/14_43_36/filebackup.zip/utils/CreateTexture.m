function tex = CreateTexture(bitMap,Q)
    
    if isfield(Q.windowIDs,'LED') && Q.windowIDs.active == Q.windowIDs.LED
        timeAveraged = squeeze(mean(bitMap(1,:,:),3)); % Not a display, don't make a real texture
        mapSize = length(timeAveraged);
        leftSide = mean(timeAveraged(1:ceil(mapSize/2)));
        rightSide = mean(timeAveraged(1+floor(mapSize/2):end));
        tex = [leftSide rightSide];
        return;
    end
        
    % image gets transposed and flipped vertically due to reflections and
    % the fact that openGL is in a right handed coordinate system. so
    % always rotrate 90 deg clockwise to counteract -MSC    
    
    if Q.windowIDs.active == Q.windowIDs.pano
        framesPerUp = Q.stims.currParam.framesPerUp;
    else if isfield(Q.stims.currParam,'flatFramesPerUp')
            framesPerUp = Q.stims.currParam.flatFramesPerUp;
        else
            framesPerUp = 12;
        end
    end
    
    outMap(size(bitMap,1),size(bitMap,2),4) = uint8(0);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    %%%%%% THIS ONLY WORKS IF framesPerUp IS DIVISIBLE BY 3
    % bitDepth 7 (essentially 8 bit) 4bit 2bit and 1bit
    % number of frames per color rgb. Its also not necessary if framesPerUp
    % = 3

    % "movie" flag is 1 for the bitmap movie, 3 for the 3rd person
    % perspective movie
    if Q.stims.movie==1 && Q.windowIDs.active == Q.windowIDs.pano
        WriteMovie(bitMap,Q);
    end

    if Q.stims.xtPlot && Q.windowIDs.active == Q.windowIDs.pano
        WriteXtPlot(bitMap(1,:,:),Q);
    end
    
    if framesPerUp ~= 3
        
        fpc = framesPerUp/3;
        % puts the bitMap into values between 0 and the bitsize
                
        nBitMap = uint8(bitMap.*255);
        nBitMap = nBitMap/uint8(255/(2^(8/fpc)-1));

        weights = repmat(uint8(2.^(0:(8/fpc):7)),[1 3]);
        weights = permute(weights,[1 3 2]);
        
        % weight the matrix so that the bits are properly shifted
        wBitMap = bsxfun(@times,nBitMap,weights);

        % now that the bits are aligned simply sum them together
        for ii = 1:3
            outMap(:,:,ii) = sum(wBitMap(:,:,((ii-1)*fpc+1):ii*fpc),3);
        end
    else
        if isinteger(bitMap)
            outMap(:,:,1:3) = uint8(bitMap);
        else
            outMap(:,:,1:3) = uint8(bitMap*255);
        end
    end
    
    % add alpha values to outMap. They won't be used but they keep
    % makeTexture from converting the format, slowing down, and droping
    % frames.
    repX = ceil(size(outMap,2)/2);
    repY = size(outMap,1);
    if isfield(Q.windowIDs,'pano') && Q.windowIDs.active == Q.windowIDs.pano
        alpha = repmat([100 200],[repY,repX]);
        outMap(:,:,4) = alpha(:,1:size(outMap,2));
    else
        outMap(:,:,4) = 255;
    end
    
    % put bitMap in the right order
    outMap = outMap(:,:,[2 3 1 4]);
    
    tex = Screen('MakeTexture', Q.windowIDs.active, outMap, [], 1);
end