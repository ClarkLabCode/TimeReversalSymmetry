function SaveFigs(folderName)
% This function allows you to quickly save all currently open figures with
% a custom filename for each in multiple formats.  To use the function
% simply call savefigs with no arguments, then follow the prompts
%
% Upon execution this function will one-by-one bring each currently open
% figure to the foreground.  Then it will supply a text prompt in the main
% console window asking you for a filename.  It will save that figure to
% that filename in the .fig, .emf, .png, and .eps formats.
%
% The formats that it saves in can be changed by commenting out or adding
% lines below.
%
% Copyright 2010 Matthew Guidry
% matt.guidry ATT gmail DOTT com  (Email reformatted for anti-spam)

%% MODIFIED BY MATT CREAMER to work specifically with the fly psychophysics computer
% in this version all you do is designate a folder nam and it saves all current to the
% logbook/figures folder with a bunch of different data types as well
% as extracting the xy data


sysConfig = GetSystemConfiguration();
logFolder = sysConfig.logPath;

hFigs = get(0, 'children'); %Get list of figures
if verLessThan('matlab', '8.4')
    hFigs = sort(hFigs);
else
    [~, srtInds] = sort([hFigs.Number]);
    hFigs = hFigs(srtInds);
end
%     hfigs = findall(0,'type','figure');

powerPointName = fullfile(logFolder,'figures',folderName,folderName);

for hh = 1:length(hFigs)
    filename = [];
    
    if ~isempty(hFigs(hh).Name)
        filename = hFigs(hh).Name;
        filename(filename == '.') = '-';
        filename(filename == ' ') = '_';
        filename = [filename '_' num2str(hh)];
        filename(filename == '/') = '_';
    else
        filename = ['fig' num2str(hh)];
    end
    
    path = fullfile(logFolder,'figures',folderName,filename,filename);
    mkdir(fullfile(logFolder,'figures',folderName,filename));
    
    hFigs(hh).InvertHardcopy = 'off';
    set(hFigs(hh),'Units','Inches');
    pos = get(hFigs(hh),'Position');
    set(hFigs(hh),'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
    print(hFigs(hh),path,'-dpdf','-r0')
%     export_fig(hFigs(hh),path,'-png', '-eps','-transparent','-painters')

    savefig(hFigs(hh),path);
    
    saveppt2(powerPointName,'figure',hFigs(hh), 'title', filename);
end

end
