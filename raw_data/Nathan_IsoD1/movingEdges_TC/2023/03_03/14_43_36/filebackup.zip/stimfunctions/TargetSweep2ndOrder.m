function [texStr,stimData] = TargetSweep2ndOrder(Q)

    % Added flicker feature to TargetSweepExtended

    % Created Jul 24 2018 by RT

    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %when choosing noise values for the sine wave make sure that:
    %noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
    %this insures that 3 std of the noise keeps you below a luminence of 1

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;
    
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % 9/14 using numDeg = 1 - maybe go high reso?
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    
    %% Input parameters
    % basics
    fPU = p.framesPerUp;
    targLat = p.targetLaterality; % 0 for left, 1 for right, 2 for bilateral (mirror symmteric)
    
    % spatio temporal paramters of targets (all in deg)
    % size of the target
    targW = p.targetW; % deg 
    targH = p.targetH; % deg
    
    % position and velocity
    targVel = p.targetVelocity; % deg/s, + for BtF (reg), - for FtB (prog)
    initX   = p.initialX; % angle(deg) from the central vertical meridian, 0(front) ~ 180(back)
    Y = p.Y;
           
    % grids to make sure that targets are shown as intended
    if isfield(p, 'testgrid')
        testgrid = p.testgrid;
    else
        testgrid = 0;
    end
    
    % texture parameter
    if isfield(p, 'textureResolution')
        texReso = p.textureResolution;
    else
        texReso = 1;
    end
    if isfield(p, 'textureType');
        texType = p.textureType; %0: binary, 1: uniform, 2: gauss
    else
        texType = 0;
    end
    
    
    mLum = p.mLum;
    
    %% Draw the bitmap

    bitMap = zeros(sizeY,sizeX,fPU);
    draw = 1;
    
    % prepare background sinewave
    if f == 0 
        switch texType
            case 0
                tex = +(rand(sizeY/texReso,sizeX/texReso)>=0.5)*2-1;
            case 1
                tex = rand(sizeY/texReso,sizeX/texReso)*2-1;
            case 2
                tex = randn(sizeY/texReso,sizeX/texReso)/4;
                tex(tex>1) = 1; tex(tex<-1) = -1;
        end 
        stimData.bgTexture = imresize(tex,texReso,'nearest');
    end
    
    for fr = 1:fPU
        targMask = zeros(sizeY,sizeX);        
        % draw targets 
        % suppose it's only in the left vis field (and
        % then flip if necessary)
        currentX = initX - targVel*(f+(fr-1)/fPU)/60; % angle from the meridian
        edgeL = (180-currentX) - targW/2; % in degree
        edgeR = (180-currentX) + targW/2;
        edgeU = Y - targH/2;
        edgeD = Y + targH/2;

        % convert spatial variables into pixel
        VertFrom = max(round(edgeL/numDeg),1);
        VertTo   = min(round(edgeR/numDeg),sizeX);
        HoriFrom = max(round(...
                        sizeY/2*...
                        (2*Q.cylinder.cylinderRadius*tand(edgeU)/Q.cylinder.cylinderHeight+1)),1);
        HoriTo   = min(round(...
                        sizeY/2*...
                        (2*Q.cylinder.cylinderRadius*tand(edgeD)/Q.cylinder.cylinderHeight+1)),sizeY);
        % skip if the whole target is out of the bound
        if (VertFrom-VertTo)*(HoriFrom-HoriTo)~=0 && draw == 1
            targMask(HoriFrom:1:HoriTo,VertFrom:1:VertTo) = 1;
        end
        switch targLat
            case 0
            case 1
                targMask = targMask(:,end:-1:1);
            case 2
                targMask = +(targMask|fliplr(targMask));
            otherwise
                disp('targLat must be 0, 1, or 2')
                return
        end
            
        % draw target only when flicker is ON
        preMap = stimData.bgTexture.*(1-targMask) - stimData.bgTexture.*targMask;
        bitMap(:,:,fr) = preMap;
    end
    
    if testgrid == 1
        bitMap(:,round(360/numDeg):round(-15/numDeg):1,:) = -0.5;
        bitMap(round(...
            sizeY/2*(...
            2*Q.cylinder.cylinderRadius*tand(-45:15:45)/Q.cylinder.cylinderHeight+1)),:,:) = -0.5;
    end    
    bitMap =  mLum * ( 1 + bitMap );
    texStr.tex = CreateTexture(bitMap,Q);
end
