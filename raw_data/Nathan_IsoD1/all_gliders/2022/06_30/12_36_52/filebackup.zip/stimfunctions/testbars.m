
function [texStr,stimData] = testbars(Q)
% % this is to provide the general structure for the texture generating codes
% to be used with PTB in this framework.

% NOTE: when you create a new stimulus function, you must update the
% stimlookup table in the folder paramfiles. paramfiles will also hold the
% text file giving lists of parameters that comprise an experiment

%% PARAMETERS

p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
stimData = Q.stims.stimData;
texStr.opts = 'full'; 
texStr.dim = 2; % 
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% basic parameters
numDeg = p.numDeg;
sizeX = round(360/p.numDeg);
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180)));
fPU = p.framesPerUp; 
mlum = p.lum;


% define bar
% Find how many bars we need to cover the screen
BW=p.barwidth;%width of the bar
nbars = (sizeY/BW);
BH  = p.barheight;  % height of the bars
BS= p.barstartposition;%barheight from top
BC = p.backgroundContrast; % background contrast from -1 to 1
R=p.radius;%radius of the moving ball
contrast=p.contrast;
fl=p.flicker;



%% Draw Stimulus
if mod(f,fl)==0
    contrast=-contrast;
end


if f == 1
    if ~isfield(stimData,'locX')
        stimData.locX = p.posx;
    end
end

bitMap = ones(sizeY,nbars*BW,fPU)*BC;

        
%location of the moving circle
stimData.locX = stimData.locX+(sizeX/(p.duration*3));
locY = p.posy;

for cc = 1:fPU
    for ll = 1:nbars
        x = linspace(1,sizeX,sizeX);
        if mod(ll-1,2)==0 %assigning contrast to bars
            bitMap(BS:BS+BH,(1:BW)+(ll-1)*BW,cc) = contrast;
        else
            bitMap(BS:BS+BH,(1:BW)+(ll-1)*BW,cc) = -contrast;
        end
    end
      
 
%     for yy = 1:sizeY
%         for xx = 1:sizeX           
%             if ((stimData.locX-xx)^2+(locY-yy)^2)<R
%                 bitMap(yy,xx,cc) = -1;
%             end
%         end
%     end
   
    
end





bitMap=mlum*(1+bitMap); % contrast to luminance conversion

%always include this line in a stim function to make the texture from the
%bitmap

texStr.tex = CreateTexture(bitMap,Q);
end
