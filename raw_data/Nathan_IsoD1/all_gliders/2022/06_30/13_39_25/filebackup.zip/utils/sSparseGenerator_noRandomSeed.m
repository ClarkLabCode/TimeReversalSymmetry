function [sSparse]=sSparseGenerator_noRandomSeed(sparsity)
%Called by func "movingBar_sparse" to generate sparse sequence
T = 120000; %length of the sequence

temp = double(rand(1,T)<sparsity);
sSparse(find(temp)) = (rand(1,sum(temp))>0.5)*2 - 1;
end