function [mask] = MultiMaskMaker(numCirc, sizes)

    sizeY = sizes(:,1);
    sizeX = sizes(:,2);

    maskP = zeros([sizeY, sizeX]);
    
    [xx, yy] = meshgrid(1:sizeX, 1:sizeY);
    radish = -2/100;
    
    slopey = 10;
    
    
    
   for cc = 1:numCirc
       yLoc = randi(sizeY);
       xLoc = randi(sizeX);             
       maskP = maskP + exp(radish*[(xx-xLoc).^2+(yy-yLoc).^2]);
   end

    mask = tanh(slopey*maskP);

end