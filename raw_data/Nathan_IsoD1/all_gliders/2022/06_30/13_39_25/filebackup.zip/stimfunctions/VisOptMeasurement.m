function [texStr,stimData] = VisOptMeasurement(Q)
% basic sinewave stimulus. Can produce rotation and translation where
% the opposite eye is the first eye's mirror image

p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
stimData = Q.stims.stimData;

if p.numDeg == 0
    sizeX = 1;
else
    sizeX = round(360/p.numDeg);
end

framesPerUp = p.framesPerUp;
bitMap(1,1:sizeX,1:framesPerUp) = p.screenIntensity;
%% Optogenetics
backSize = ceil(45/p.numDeg);
bitMap(1,1:backSize,:) = p.optoIntensity;
bitMap(1,sizeX-backSize+1:sizeX,:) = p.optoIntensity;

%always include this line in a stim function to make the texture from the
%bitmap

texStr.tex = CreateTexture(bitMap,Q);
end