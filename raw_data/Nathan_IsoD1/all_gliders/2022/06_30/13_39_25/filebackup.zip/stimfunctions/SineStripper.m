function [texStr,stimData] = SineStripper(Q)
    % basic sinewave stimulus. Can produce rotation and translation where
    % the opposite eye is the first eye's mirror image
    
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;

    if p.numXDeg == 0
        sizeX = 1;
    else
        sizeX = round(360/p.numXDeg);
    end
    
    if p.numYDeg == 0
        sizeY = 1;
    else
        sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numYDeg*pi/180)));
    end

%     sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numYDeg*pi/180)));
    mlum = p.lum;
    cA = p.contrastA;
    cB = p.contrastB;
    
    if ~isfield(p,'temporalFrequencyA')
        velA = p.velocityA*pi/180; % degree/s into rad/s
        velB = p.velocityB*pi/180; % degree/s into rad/s
    else
        velA = p.temporalFrequencyA*p.lambdaA*pi/180;
        velB = p.temporalFrequencyB*p.lambdaB*pi/180;
    end
    
    if ~isfield(p,'innerStripLength')
        innerStripLength = 20;
    else
        innerStripLength = p.innerStripLength;
    end
    
    if ~isfield(p,'grayThickness')
        grayThickness = 5;
    else
        grayThickness = p.grayThickness;
    end        
    
      if ~isfield(p,'changeEveryEpoch')
        changeEveryEpoch = 0;
    else
        changeEveryEpoch = p.changeEveryEpoch;
      end  
    
     if ~isfield(p,'innerStripLocation')
        innerStripLocation = round(sizeY./2);
    else
        innerStripLocation = p.innerStripLocation;
     end 
    
    if ~isfield(p,'twoInFrame')
        twoInFrame = 0;
    else
        twoInFrame = p.twoInFrame;
    end 
    
    if ~isfield(p,'circle')
        circle = 0;

    else
        circle = p.circle;
  
    end
    
    if ~isfield(p,'whichStrip')
        whichStrip = 0;
    else
        whichStrip = p.whichStrip;
    end
%     circle =1;
%         innerRadius = 10;
%         outerRadius = 20;
%         xLocation = 210;
%         yLocation = 60;
        
        
    lambdaA = p.lambdaA*pi/180; %wavelength in radians
    lambdaB = p.lambdaB*pi/180;
    framesPerUp = p.framesPerUp;
    
    psiA = p.psiA*pi/180; % vertical angle to rad/s
    psiB = p.psiB*pi/180;

    %% left eye
    %stimData.mat(1) is used as the wave phase. stimData.mat(2) is the velocity which
    %is constant unless noise is added

    if f == 1 && ~isfield(stimData,'sinPhaseA')
        stimData.sinPhaseA = rand*2*pi;
        stimData.sinPhaseB = rand*2*pi;
    end
    
    thetaX = (0:sizeX-1)/sizeX*2*pi; %thetaX in radians
    % fraction of cylinder height to cylinder circumference
    circToHeight = Q.cylinder.cylinderHeight/(2*Q.cylinder.cylinderRadius*pi);
    thetaY = (0:sizeY-1)/sizeY*2*pi*circToHeight; %thetaY in radians
    [thetaXMat,thetaYMat] = meshgrid(thetaX,thetaY);
    
    thetaCombA = cos(-psiA)*thetaXMat+sin(-psiA)*thetaYMat;
    thetaCombB = cos(-psiB)*thetaXMat+sin(-psiB)*thetaYMat;
    
    bitMap(sizeY,sizeX,framesPerUp) = 0;

if (~isfield(stimData,'stimWeights')||(changeEveryEpoch&&f==1)) 
    if sizeY==1&&sizeX == 1
    innerWeights = false([sizeY, sizeX]);
    outerWeights = false([sizeY, sizeX]);
    innerWeights= repmat(innerWeights,[1, 1, framesPerUp]);
    outerWeights= repmat(outerWeights,[1, 1, framesPerUp]);
    stimData.stimWeights{1} = innerWeights; 
    stimData.stimWeights{2} = outerWeights; 
    else

    if ~circle  
        if whichStrip == 0
            innerWeights = false([sizeY, sizeX]);
            outerWeights = false([sizeY, sizeX]);
            innerWeights(innerStripLocation-innerStripLength:innerStripLocation+innerStripLength,:) = true;

            outerWeights(1:innerStripLocation-innerStripLength-grayThickness,:) = true;
            outerWeights(innerStripLocation+innerStripLength+grayThickness:end,:) = true;
        elseif whichStrip == 1
            innerWeights = false([sizeY, sizeX]);
            outerWeights = false([sizeY, sizeX]);
            innerWeights(innerStripLocation-innerStripLength:innerStripLocation+innerStripLength,:) = true;

            outerWeights(1:innerStripLocation-innerStripLength-grayThickness,:) = true;
%             outerWeights(innerStripLocation+innerStripLength+grayThickness:end,:) = true;
        elseif whichStrip == -1
            innerWeights = false([sizeY, sizeX]);
            outerWeights = false([sizeY, sizeX]);
            innerWeights(innerStripLocation-innerStripLength:innerStripLocation+innerStripLength,:) = true;

%             outerWeights(1:innerStripLocation-innerStripLength-grayThickness,:) = true;
            outerWeights(innerStripLocation+innerStripLength+grayThickness:end,:) = true;
        end
        
    else
        [xx, yy] = meshgrid(1:sizeX, 1:sizeY);
        innerWeights = false([sizeY, sizeX]);
        outerWeights = true([sizeY, sizeX]);
        innerWeights(((xx-xLocation).^2+(yy-yLocation).^2)<innerRadius^2) = true;
        outerWeights(((xx-xLocation).^2+(yy-yLocation).^2)<outerRadius^2) = false;
        
    end
    innerWeights= repmat(innerWeights,[1, 1, framesPerUp]);
    outerWeights= repmat(outerWeights,[1, 1, framesPerUp]);
    stimData.stimWeights{1} = innerWeights; 
    stimData.stimWeights{2} = outerWeights; 
    end
else
    innerWeights = stimData.stimWeights{1};
    outerWeights = stimData.stimWeights{2};
end
    
for cc = 1:framesPerUp
        stimData.sinPhaseA = stimData.sinPhaseA + velA/(60*framesPerUp);
        stimData.sinPhaseB = stimData.sinPhaseB + velB/(60*framesPerUp);
        
        bitMapA(:,:,cc) = cA*sin(2*pi*(thetaCombA-stimData.sinPhaseA)/lambdaA);
        bitMapB(:,:,cc) = cB*sin(2*pi*(thetaCombB-stimData.sinPhaseB)/lambdaB);
        
        

        stimData.mat(cc) = stimData.sinPhaseA;
        stimData.mat(cc+framesPerUp) = stimData.sinPhaseB;
end


    if ~isnan(bitMapA+bitMapB)
        if ~twoInFrame
%             bitMap= innerWeights.*bitMapA+outerWeights.*bitMapB;
            bitMap(innerWeights) = bitMapA(innerWeights);    
            bitMap(outerWeights) = bitMapB(outerWeights);
        else
%              bitMap = (innerWeights+outerWeights).*bitMapA+outerWeights.*bitMapB;
               bitMap(innerWeights) = bitMapA(innerWeights);    
               bitMap(outerWeights) = bitMapB(outerWeights)+bitMapA(outerWeights);
        end
    end
%     bitMap(logical(innerWeights)) = bitMapA(logical(innerWeights));    
%     bitMap(logical(outerWeights)) = bitMapB(logical(outerWeights));
    bitMap = mlum*(1 + bitMap);

    %% right eye
    if p.twoEyes
        rightEye = fliplr(bitMap);
        
        bitMap = CombEyes(bitMap,rightEye,p,f);
    end

    %always include this line in a stim function to make the texture from the
    %bitmap

    texStr.tex = CreateTexture(bitMap,Q);
   
end