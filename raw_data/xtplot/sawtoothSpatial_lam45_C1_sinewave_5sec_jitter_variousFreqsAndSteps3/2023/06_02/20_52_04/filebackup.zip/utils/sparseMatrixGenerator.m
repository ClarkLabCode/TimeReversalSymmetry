function [sparseMat]=sparseMatrixGenerator(sparsity,sizeX,barWidth,velocity,numVerticalBlock,epochDuration)
%Called by func "movingCheckerBoard_sparseSweep" to generate sparse matrix
T = (ceil(sizeX/barWidth)+ceil(abs(velocity)*epochDuration/barWidth))*2; %calculate length of the matrix to be larger the the epoch duration

% tauSparse = barWidth/abs(velocity); 
temp = rand(numVerticalBlock,T);
sparseMat=(temp<sparsity/2)-(temp>1-sparsity/2);

end