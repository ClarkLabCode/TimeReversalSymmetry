function [texStr,stimData] = CheckerboardRectanglesGridMask(Q)

    % Created 10/09/18 by RT
    
    %% Parameters %%
    %% Basics
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;

    if p.numDeg == 0
        sizeX = 1;
    else
        sizeX = round(360/p.numDeg);
    end
    numDegActual = 360/sizeX;
    
    % Here we are setting the pixel just in front of a fly to be numXDeg by
    % numYDeg (which is different from what RT usually do)
    if p.numDeg == 0
        sizeY = 1;
    else
        sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180)));
    end
    
    boxDims = [p.boxWidth/p.numDeg,p.boxHeight/p.numDeg];
    boxDims(isnan(boxDims)) = 1;

    mlum = p.lum;
    
    %% Spatiotemporal paramters
    c = p.contrast;
    
    gridDist = round(p.gridDist/p.numDeg);
    
    vel = p.velocity;
    
    checkerboardResolution = p.checkerboardResolution;
    assert(~rem(360,checkerboardResolution),'Checkerboard Resolution (%d) must be divisible by 360',checkerboardResolution);
    
    framesPerUp = p.framesPerUp;

    %% left eye
    
    bitMap(sizeY,sizeX,framesPerUp) = 0;

    if f == 1 
        % Calling an outside function (should be in stimfucntion folder)
        [mask] = MultiMaskMakerRegularRectangles([sizeY, sizeX],gridDist,boxDims);
        stimData.mask = mask; 
    else
        mask = stimData.mask;
    end
    
    if f == 1
        cylHeightDeg = Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(pi/180));
        numChecksLowRes = [ceil(cylHeightDeg/checkerboardResolution),360/checkerboardResolution];
        checkLowRes = c*(1-2*(rand(numChecksLowRes)>0.5));
        checkHighRes = imresize(checkLowRes,checkerboardResolution/numDegActual,'nearest');
        checkHighRes = checkHighRes(1:sizeY,1:sizeX);
        stimData.checkHighRes = checkHighRes;
    else
        checkHighRes = stimData.checkHighRes;
    end
    
    for cc = 1:framesPerUp
        t = f/60 + cc/(60*framesPerUp);
        shift = vel*t/numDegActual;
        bitMap(:,:,cc) = circshift(checkHighRes,round(shift),2).*mask;
    end

    bitMap = mlum*(1 + bitMap);

    %% right eye
    if p.twoEyes
        rightEye = fliplr(bitMap);
        
        bitMap = CombEyes(bitMap,rightEye,p,f);
    end

    %always include this line in a stim function to make the texture from the
    %bitmap
    texStr.tex = CreateTexture(bitMap,Q);
end