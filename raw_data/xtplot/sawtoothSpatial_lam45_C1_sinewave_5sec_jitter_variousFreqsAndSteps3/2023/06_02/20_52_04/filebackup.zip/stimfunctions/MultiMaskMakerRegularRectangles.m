function [mask] = MultiMaskMakerRegularRectangles(sizes, gridDist, boxDims)

    sizeY = sizes(:,1);
    sizeX = sizes(:,2);

    mask = zeros([sizeY, sizeX]);
    
    % generate grid 
    gridX = (-1:1:ceil(sizeX/gridDist))*gridDist +...
            (randi(gridDist)*2-gridDist); % phase scrambring
    gridY = (-1:1:ceil(sizeY/gridDist))*gridDist +...
            (randi(gridDist)*2-gridDist);

    [gridXmesh,gridYmesh] = meshgrid(gridX,gridY);
    boxDimsReped = repmat(boxDims,[length(gridXmesh(:)),1]);
    maskThree = insertShape(mask,'filledrectangle',[gridXmesh(:),gridYmesh(:),boxDimsReped],'Color',[1,1,1],'Opacity',1);
    mask = maskThree(:,:,1);
end