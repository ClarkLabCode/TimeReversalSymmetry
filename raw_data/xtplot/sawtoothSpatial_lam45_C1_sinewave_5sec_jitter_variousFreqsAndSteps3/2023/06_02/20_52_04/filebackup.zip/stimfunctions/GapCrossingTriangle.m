function [texStr,stimData] = GapCrossingTriangle(Q)
%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

duration = p.duration+1;    % This +1 makes the stimulus end as gap reached
fPU=p.framesPerUp;
BaseWidthTri = p.BaseWidthTri;
TriHeight = round((sizeY/2));
GapWidth = p.GapWidth;
YInitPosBotLine = TriHeight;
YInitPosTopLine = YInitPosBotLine - GapWidth;
Vel = (sizeY-YInitPosBotLine)/(duration*fPU);
% Vel=p.Vel/60;   % takes in vel as deg/sec
InitDist=p.InitDist;
LumOfBG = p.LumOfBG;
LumOfPlat = p.LumOfPlat;

%% Initializing BitMap

bitMap= LumOfBG*ones(sizeY,sizeX,fPU);

% bitMap(DistFromBot:(DistFromBot+InitTrapHeight),((sizeX-InitBotWidth)/2):((sizeX+InitBotWidth)/2),fPU) = 0;

% At a given y, we compute x_L and x_R
% If x >= x_L and x <= x_R, bitMap = 0;
for fr = 1:fPU
    
    t = (f-1)*fPU + fr; % index for all fPU
    
    t_top = mod(t,(InitDist/Vel*fPU)*(1-YInitPosTopLine/sizeY));
%     t_bot = mod(t,(InitDist/Vel*fPU)*(1-YInitPosBotLine/sizeY));
%     t_top = mod(t,(InitDist/Vel*fPU)*(1-YInitPosTopLine/sizeY));
%     end
    
    YPosTopLine = round(InitDist*(YInitPosTopLine)/(InitDist-(Vel/fPU)*(t_top-1)));
    YPosBotLine = round(InitDist*(YInitPosBotLine)/(InitDist-(Vel/fPU)*(t_top-1)));

    x2_L = sizeX/2;     % x position of top of triangle
    x2_R = x2_L;        % Since triangle meets at point
    x1_L = round(x2_L - BaseWidthTri/2);   % x position of bottom left point of tri
    x1_R = round(x2_L + BaseWidthTri/2);   % x position of bottom right point of tri
    
    y2_L = sizeY-TriHeight;   % y position of top of triangle
    y1_L = sizeY;             % y position of bot of triangle
    
    % Redundant but for clarity since y pos is same on left and right side
    y2_R = sizeY-TriHeight;   % y position of top of triangle
    y1_R = sizeY;             % y position of bot of triangle
    
    for y = 1:sizeY
        x_L = (x2_L-x1_L)/(y2_L-y1_L)*(y - y1_L) + x1_L;
        x_R = (x2_R-x1_R)/(y2_R-y1_R)*(y - y1_R) + x1_R;
        XPosTopLine_L=(x2_L-x1_L)/(y2_L-y1_L)*(YPosTopLine - y1_L) + x1_L;
        XPosTopLine_R = (x2_R-x1_R)/(y2_R-y1_R)*(YPosTopLine - y1_R) + x1_R;
      
        
     
        if (y>=YPosTopLine)&&(y<=YPosBotLine)
            bitMap(y,round(x_L):round(x_R),fr) = LumOfBG;
            bitMap(y,round( XPosTopLine_L):round( XPosTopLine_R),fr) = (LumOfBG+LumOfPlat)/2;
            
        elseif YPosTopLine>YPosBotLine
            if ((y>=YPosTopLine)&&(y<=sizeY))
                bitMap(y,round(x_L):round(x_R),fr) = LumOfBG;
                bitMap(y,round( XPosTopLine_L):round( XPosTopLine_R),fr) = (LumOfBG+LumOfPlat)/2;
            else
                bitMap(y,round(x_L):round(x_R),fr) = LumOfPlat;
            end
        else
            bitMap(y,round(x_L):round(x_R),fr) = LumOfPlat;
           
        end
    end
    


end
texStr.tex = CreateTexture(bitMap,Q);

end
