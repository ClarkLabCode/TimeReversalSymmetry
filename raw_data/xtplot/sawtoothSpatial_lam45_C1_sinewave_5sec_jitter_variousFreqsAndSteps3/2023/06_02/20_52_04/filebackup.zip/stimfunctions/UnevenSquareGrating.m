function [texStr,stimData] = UnevenSquareGrating(Q)

% this is to provide the general structure for the texture generating codes
% to be used with PTB in this framework. 

% NOTE: when you create a new stimulus function, you must update teh
% stimlookup table in the folder paramfiles. paramfiles will also hold the
% text file giving lists of parameters that comprise an experiment

p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
stimData = Q.stims.stimData;

texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2

% must also set up the scaling factors here for use in the texture
% rendering
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% basic parameters
duration = p.duration; %appears to be in frames
numDeg = p.numDeg; %number of degrees per pixel
framesPerUp = p.framesPerUp;
if p.numDeg == 0
        sizeX = 1;
        sizeY = 1;
    else
        sizeX = round(360/numDeg);
        sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(numDeg*pi/180)));
end

%Stimuli-specific parameters

velocity = p.velocity; %in degrees per second
if velocity >= 0
    barWidth1 = p.barWidth1; %barWidth1 is the leading bar
    barWidth2 = p.barWidth2;
else
    barWidth2 = p.barWidth1;
    barWidth1 = p.barWidth2;
end

%Create bitmap
if f == 1
    stimData.offset = randi([1, sizeX]);
end

bitmap = zeros(sizeY,sizeX,framesPerUp);

for ff = 1:framesPerUp
    %use modulus to deal with rolling
    t =(f-1)*(1/60) + ff*(1/60)*(1/framesPerUp);
    %t is the seconds that have passed.
    %startIndex = mod(round(stimData.offset + ((t*velocity)/numDeg)), sizeX) + 1;
    totalWidth = 2*(barWidth1 + barWidth2);
    
    rowValues = mod((1:sizeX) + round(stimData.offset - ((t*velocity)/numDeg)), totalWidth) + 1;
    bitmapRow = (rowValues <= barWidth1) |...
        (( rowValues > (barWidth1 + max([barWidth2 barWidth1]))) & (rowValues <= (barWidth1 + max([barWidth2 barWidth1]) +barWidth2)));
    bitmap(:,:,ff) = repmat(bitmapRow, [sizeY, 1]);
end

%always include this line in a stim function to make the texture from the
%bitmap
texStr.tex = CreateTexture(bitmap,Q);