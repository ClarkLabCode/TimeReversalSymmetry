function [texStr,stimData] = LightDarkEdgesAnyDir(Q)
    params = Q.stims.currParam;
    updateNum = Q.timing.framenumber - Q.timing.framelastchange + 1; %number of frame changes since start of epoch
    stimData = Q.stims.stimData;
    
    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.
    
    angleDeg = params.angleDeg;
    velocityDeg = params.velocityDeg; %All angles calculated to be the same size as the center of the image
    
    oneShot = params.oneShot; % Only present one edge per epoch
    
    % Convert negative velocities to opposite angles
    speedDeg = abs(velocityDeg);
    angleDeg = angleDeg+180*(velocityDeg < 0);
    
    backgroundLum = params.backgroundLum;
    edgeLum = params.edgeLum;

    if params.numDeg == 0
        sizeX = 1;
        sizeY = 1;
    else
        sizeX = round(360/params.numDeg);
        sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tand(params.numDeg)));
    end

    phaseXV = (0:(sizeX-1))*params.numDeg;
    phaseYV = (0:(sizeY-1))*params.numDeg;
    [phaseX,phaseY] = meshgrid(phaseXV,phaseYV);
    
    phaseMap = phaseX*cosd(angleDeg) + -phaseY*sind(angleDeg);
    
    if ~oneShot
        maxPhase = max(phaseMap(:));
    else
        maxPhase = realmax;
    end
    minPhase = min(phaseMap(:));
    phaseExtent = maxPhase - minPhase;
    
    framesPerUpdate = params.framesPerUp;
    bitmap = zeros(sizeY,sizeX,framesPerUpdate);

    for ff = 1:framesPerUpdate
        t =(updateNum-1)*(1/60) + ff*(1/60)*(1/framesPerUpdate);
        edgePhase = minPhase + mod(speedDeg*t,phaseExtent);
        thisFrame = ones(sizeY,sizeX)*backgroundLum;
        thisFrame(phaseMap < edgePhase) = edgeLum;
        bitmap(:,:,ff) = thisFrame;
    end
texStr.tex = CreateTexture(bitmap,Q);
        