function [texStr,stimData] = SawtoothSpatialFlicker(Q)
    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %when choosing noise values for the sine wave make sure that:
    %noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
    %this insures that 3 std of the noise keeps you below a luminence of 1

    sii = Q.stims.currStimNum;
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;
    floc = Q.flyloc; % could potentially use this to update the stimulus as well

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    numDeg = p.numDeg;
    
    if numDeg == 0
        sizeX = 1;
    else
        sizeX = round(360/numDeg);
    end

    lambda = p.lambda; % distance between new in radians
    framesPerUp = p.framesPerUp;
    contrast = p.contrast;
    mlum=p.mlum;
    
    flickerContrast = p.flickerContrast;
    flickerFrequency = p.flickerFrequency;
    flickerType = p.flickerType; % 0: Square Wave; 1: Sinusoidal
        
    halfCycle = 60*framesPerUp/flickerFrequency/2;
    
    % check if flickerFrequency is feasible
    if flickerType == 0 && (mod(halfCycle,1)~=0 || halfCycle < 1)
        disp('The designated square wave flicker frequency is not feasible!');
        return
    end
    
    %% left eye

    % create variable that represents one edge. repmat this to get the full
    % bitmap

    if f == 1
        stimData.windowLoc = rand*lambda;
        %stimData.polarity=sign(rand-0.5);
        stimData.polarity=p.polarity;
    end
    
    bitMap = zeros(1,sizeX,framesPerUp);
     
    polarity = stimData.polarity;
    
    x=linspace(1,360,sizeX)-stimData.windowLoc;
    
    % Fixed 10/04/2017 
    % framesPerUp 3 means 180 Hz
    switch flickerType
        case 0 % square wave
            luminanceLevels = contrast*polarity*(mod(x,lambda)*2/lambda-1);
            for cc = 1:framesPerUp
                cf = (f-1)*framesPerUp + cc;
                if mod(cf-1,2*halfCycle) < halfCycle
                    bitMap(:,:,cc) = luminanceLevels;
                else
                    bitMap(:,:,cc) = flickerContrast;
                end
            end
            
        case 1 % sinusoidal
            for cc = 1:framesPerUp
                cf = (f-1)*framesPerUp + cc;
                phase = mod(cf-1,2*halfCycle)/halfCycle*pi;
                weight = 0.5*(cos(phase+pi)+1); % start from interleave color, and the gradient builds up
                luminanceLevels = weight * contrast*polarity*(mod(x,lambda)*2/lambda-1) + (1-weight) * flickerContrast;
                bitMap(:,:,cc) = luminanceLevels;          
            end
    end
            
            
           
    bitMap=mlum*(1+bitMap); % contrast to luminance conversion
    
     %% right eye
    if p.twoEyes
        rightEye = fliplr(bitMap);
        
        bitMap = CombEyes(bitMap,rightEye,p,f);
    end
        
    %always include this line in a stim function to make the texture from the
    %bitmap

    texStr.tex = CreateTexture(bitMap,Q);
end
