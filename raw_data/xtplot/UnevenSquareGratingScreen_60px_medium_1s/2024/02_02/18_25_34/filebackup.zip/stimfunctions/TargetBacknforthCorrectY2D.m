function [texStr,stimData] = TargetBacknforthCorrectY2D(Q)

    % Targets that sinusoidally oscillates back and forth
    
    % Created Sep 10 2018 by RT

    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %when choosing noise values for the sine wave make sure that:
    %noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
    %this insures that 3 std of the noise keeps you below a luminence of 1

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;
    
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % 9/14 using numDeg = 1 - maybe go high reso?
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    
    %% Input parameters
    % basics
    fPU = p.framesPerUp;
    isMirrored = p.isMirrored; % 0 for non mirroring, 1 for mirroring
                              % shouldn't be used with interactive center
                              % shifting (will behave weirdly)
    tC = p.targetContrast; % -1 for Black, 1 for White
    
    %%% spatio temporal paramters of targets (all in deg) %%%
    %% size of the target
    targW = p.targetW; % deg 
    targH = p.targetH; % degRunM
    
    %% kinematics
    % Note: these values should be vectors - in paramfiles, input two
    % numbers separated by comma (e,g, 1,1)
    % angular velocities
    omega = p.angularVelocities; % in X direction, deg/s
    % amplitudes
    A = p.oscillationRadii; % in degrees (visual angle)
    % initial phases
    phi = p.initialPhases;
    
    % middle point (midR(1) = 0~360deg, midR(2) = -53~53 deg)
    midR = p.midR;
    
    % for online presentation 
    if ~isempty(Q.condstr)
        onlineloc = strsplit(Q.condstr,',');
        midR(1) = str2num(onlineloc{1});
        midR(2) = str2num(onlineloc{2});
    end
    
    stimData.mat(1) = midR(1);
    stimData.mat(2) = midR(2);

    % backgrounds
    bC = p.backgroundContrast; % 0 for mean gray, 1 for full contrast
    
    % durations and timings (all in frames = 1/60 sec)
    duration   = p.duration;
    untilMove  = p.untilMove; % these are timings - which is different 
                                 % from my several previous stimfunctions
    untilStop  = p.untilStop;
    
    % flicker
    if isfield(p,'flickerFrequency')
        fFreq = p.flickerFrequency;
    else
        fFreq = 0;
    end
    fPC = min(fPU*60/fFreq,duration*2); % updates per cycle
                                        % when frequency is 0, cycle is 
                                        % 2 durations long = target is 
                                        % always on
    
    % grids to make sure that targets are shown as intended
    % don't present in actual experiments!
    if isfield(p, 'testgrid')
        testgrid = p.testgrid;
    else
        testgrid = 0;
    end
    
    mLum = p.mLum;
    
    %% Draw the bitmap

    bitMap = zeros(sizeY,sizeX,fPU);

    
    for fr = 1:fPU
        targMask = zeros(sizeY,sizeX);
        preMap   = ones(sizeY,sizeX)*bC;
        
        % current time point in 1/60 unit
        f2 = f+fr/fPU; 
        isOn = mod(f2,fPC)<=fPC/2;
        
        if isOn==1 % calculate stimlus parameters only when flicker is On

            % calculate mid position
            elapsedMoving = min(max(0,f2-untilMove),untilStop-untilMove);
            currentR = midR + A.*sind(omega*elapsedMoving/60+phi);

            % calculate edge positions
            edgeL = currentR(1) - targW/2; % in degree
            edgeR = currentR(1) + targW/2;
            edgeU = max(currentR(2) - targH/2,-90);
            edgeD = min(currentR(2) + targH/2,90);

            % convert spatial variables into pixel
            VertFrom = max(round(edgeL/numDeg),1);
            VertTo   = min(round(edgeR/numDeg),sizeX);
            HoriFrom = max(round(...
                            sizeY/2*...
                            (2*Q.cylinder.cylinderRadius*tand(edgeU)/Q.cylinder.cylinderHeight+1)),1);
            HoriTo   = min(round(...
                            sizeY/2*...
                            (2*Q.cylinder.cylinderRadius*tand(edgeD)/Q.cylinder.cylinderHeight+1)),sizeY);

            % skip if the whole target is out of the bound
            if (VertFrom-VertTo)*(HoriFrom-HoriTo)~=0
                targMask(HoriFrom:1:HoriTo,VertFrom:1:VertTo) = 1;
            end
            
            if isMirrored == 1
                targMask = targMask|fliplr(targMask);
            end
        end
        preMap(targMask==1) = tC;
        bitMap(:,:,fr) = preMap;
    end
    
    if testgrid == 1
        bitMap(:,round(360/numDeg):round(-10/numDeg):1,:) = -0.5;
        bitMap(round(...
            sizeY/2*(...
            2*Q.cylinder.cylinderRadius*tand(-50:10:50)/Q.cylinder.cylinderHeight+1)),:,:) = -0.5;
    end    
    bitMap =  mLum * ( 1 + bitMap );
    texStr.tex = CreateTexture(bitMap,Q);
end
