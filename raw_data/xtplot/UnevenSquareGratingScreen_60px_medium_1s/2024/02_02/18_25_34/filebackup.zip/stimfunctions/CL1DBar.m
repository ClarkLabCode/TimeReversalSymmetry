function [texStr,stimData] = CL1DBar(Q)

    % Created Sep 19 2019

    % This function presents closed-loop virtual reality objects at
    % different distances
    
    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment


    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;
    
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % 9/14 using numDeg = 1 - maybe go high reso?
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    
    %% Input parameters
    %% closed loop stuff
    % Prepare fields to store the position and heading of flies
    if f==0 % first frame of epoch - initialize fly-state variable
        stimData.flyHeading = randi(360); % in deg
    end
    % Closed loop input
    [fTS,~,stimData] = GetFlyResponse(Q.timing.framenumber,Q.stims.duration,Q.flyTimeline.curFlyStates,stimData);
    leadFly = stimData.cl(1);
    fTS = fTS(leadFly); % turning
    
    %% things that concern the entire presentation
    fPU = p.framesPerUp;
    duration = p.duration; % frames
    mLum = p.mLum;
    
    if isfield(p, 'backgroundContrast')
        Cback = p.backgroundContrast;
        if isempty(Cback); Cback = 0; end
    else
        Cback = 0;
    end
    
    %% bar parameters
    bH = p.barHeight;
    bW = p.barWidth;
    nB = p.barNumber;
    bC = p.barContrast;
    
    %% things that concern CL stimuli
    % Gain of closed loop updates
    gainT = p.turningGain;
    
    %% Update of visual stimuli and drawing
    bitMap = zeros(sizeY,sizeX,fPU);
    fHead = stimData.flyHeading;
    
    for ff = 1:fPU
        % prepare the matrix to draw things into
        preMap = ones(sizeY,sizeX) * Cback;
        
        % Update heading
        fHead = fHead + fTS/60/fPU*gainT;

        % draw the objects
        for bb = 1:nB
            % position of the bar relative to fly head
            barPos = mod(360/nB*bb-fHead,360);
            % Draw the thing
            edgeB = min(sizeY,round(sizeY/2)+round(bH/2));
            edgeT = max(1,round(sizeY/2)-round(bH/2));
            edgeL = min(max(round(barPos-bW/2),1),sizeX);
            edgeR = min(max(round(barPos+bW/2),1),sizeX);

            preMap(edgeT:edgeB,edgeL:edgeR) = bC; 

        end
        bitMap(:,:,ff) = preMap;
        
        % save state variables
        stimData.mat(ff) = fHead;
    end
    % pass position and heading variables to the next loop
    stimData.flyHeading  = fHead;
    
    bitMap =  mLum * ( 1 + bitMap );
    
    texStr.tex = CreateTexture(bitMap,Q);
end
