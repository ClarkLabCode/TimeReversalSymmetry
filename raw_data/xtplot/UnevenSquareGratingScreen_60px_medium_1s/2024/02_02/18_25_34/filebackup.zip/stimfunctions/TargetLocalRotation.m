function [texStr,stimData] = TargetLocalRotation(Q)

    % created Aug 14 2018

    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %when choosing noise values for the sine wave make sure that:
    %noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
    %this insures that 3 std of the noise keeps you below a luminence of 1

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;
    
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % 9/14 using numDeg = 1 - maybe go high reso?
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    
    %% Input parameters

    fPU = p.framesPerUp;
    
    if isfield(p, 'backgroundContrast')
        bkgdContrast = p.backgroundContrast;
    else
        bkgdContrast = 0;
    end
    
    if isfield(p, 'testgrid')
        testgrid = p.testgrid;
    else
        testgrid = 0;
    end
    
    % spatio temporal paramters (all deg)
    tW = p.targetW; % deg 
    tH = p.targetH; % deg
    midX = p.midX;
    midY = p.midY;
    
    % for online analysis
    if ~isempty(Q.condstr)
        onlineloc = strsplit(Q.condstr,',');
        midX = str2num(onlineloc{1});
        midY = str2num(onlineloc{2});
    end
    stimData.mat(1) = midX;
    stimData.mat(2) = midX;

    % Surround spatial parameters
    radGy   = p.radiusofGyration; % deg
    angVel  = -p.angularVelocity; % deg/s (positive in paramfile = cw)
    initP    = p.initialPhase;    % deg (0=upright)
    
    totalDuration = p.duration; % frames
    moveWait = p.moveWait;
    disappearWait = p.disappearWait;
    
    mLum = p.mLum;
    tCont = p.targetContrast;
    if isfield(p,'surroundContrst')
        surroundContrast = p.surroundContrast;
    else
        surroundContrast = tCont;
    end
        
    %% Draw the bitmap

    bitMap = zeros(sizeY,sizeX,fPU);
    preMap = ones(size(bitMap,1),size(bitMap,2))*bkgdContrast;

       
    for fr = 1:fPU
        framesMoved = min(max(0,f+fr/fPU - moveWait),totalDuration-disappearWait-moveWait);
        targetX = midX - radGy * sin(pi*2*(initP + angVel*framesMoved/60)/360);
        targetY = midY - radGy * cos(pi*2*(initP + angVel*framesMoved/60)/360);
        
        edgeL = targetX - tW/2;
        edgeR = targetX + tW/2;
        edgeU = targetY - tH/2;
        edgeD = targetY + tH/2;

        VertFrom = max(round(edgeL/numDeg),1);
        VertTo   = min(round(edgeR/numDeg),sizeX);
        HoriFrom = max(round(...
                        sizeY/2*...
                        (2*Q.cylinder.cylinderRadius*tand(edgeU)/Q.cylinder.cylinderHeight+1)),1);
        HoriTo   = min(round(...
                        sizeY/2*...
                        (2*Q.cylinder.cylinderRadius*tand(edgeD)/Q.cylinder.cylinderHeight+1)),sizeY);

        if (VertFrom-VertTo)*(HoriFrom-HoriTo)~=0 
            preMap(HoriFrom:1:HoriTo,VertFrom:1:VertTo) = tCont;
        end

        bitMap(:,:,fr) = preMap;
    end
    
    if testgrid == 1
        bitMap(:,round(360/numDeg):round(-10/numDeg):1,:) = -0.5;
        bitMap(round(...
            sizeY/2*(...
            2*Q.cylinder.cylinderRadius*tand(-50:10:50)/Q.cylinder.cylinderHeight+1)),:,:) = -0.5;
    end    
    bitMap =  mLum * ( 1 + bitMap );
    
    texStr.tex = CreateTexture(bitMap,Q);
end
