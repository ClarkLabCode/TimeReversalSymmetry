
function [texStr,stimData] = WuHengPantleDot(Q)

%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
% input from user
CBShift = p.CBShift;    % Shift of displacement between checkerboard in degree, + for right,- for left
duration = p.duration;  % Duration of epoch in frames
tint = p.tint;  % Number of frames of white/black/gray covering 
t1 = p.t1;        % Number of frames of each CB
t2 = p.t2; 
CBContrast = p.CBContrast; % Constract of CB
coverColor = p.coverColor;  % -1 = black, 0 = gray, 1 = white
cor = p.cor;
fPU = p.framesPerUp;
mlum = p.mlum;
DotN = p.DotN;
DotSize = p.DotSize;

cycleDur = t1+tint+t2; 
N = round((DotN*duration)/cycleDur)+1;
if f == 1
    X_array = round(sizeX*(rand(1,N)))+1;
    Y_array = round(sizeY*(rand(1,N)))+1;
    Contrast_array = 2*(rand(1,N)>0.5)-1;
    InitialPhase_array = round(duration*(rand(1,N)))-t1;   
    
    stimData.X_array = X_array;
    stimData.Y_array = Y_array;
    stimData.Contrast_array = Contrast_array;
    stimData.InitialPhase_array = InitialPhase_array;
else
    X_array = stimData.X_array;
    Y_array = stimData.Y_array;
    Contrast_array = stimData.Contrast_array;
    InitialPhase_array = stimData.InitialPhase_array;
end

% x = round([1:sizeX]/CBWidth);
x = [1:sizeX];
% y = [1:sizeY];
% [X,Y] = meshgrid(x,y);
  % Duration in frames of CB and cover
bitMap = coverColor*ones(sizeY,sizeX,fPU);
for ii = 1:N
frameWithinCycle = mod((f-InitialPhase_array(ii)),duration);
if frameWithinCycle > 0 & frameWithinCycle <= t1+tint+t2
    
if frameWithinCycle < t1
    bitMap(Y_array(ii):Y_array(ii)+DotSize,X_array(ii):X_array(ii)+DotSize,:) = Contrast_array(ii); 
elseif frameWithinCycle < t1+tint
    bitMap(Y_array(ii):Y_array(ii)+DotSize,X_array(ii):X_array(ii)+DotSize,:) = cor*Contrast_array(ii);  
elseif frameWithinCycle < t1+tint+t2
    bitMap(Y_array(ii),X_array(ii)+CBShift:X_array(ii)+CBShift+DotSize,:) = Contrast_array(ii); 
end

end

end
bitMap = mlum*(1 + bitMap); % converts contrast to luminance

%always include this line in a stim function to make the texture from the
%bitmap

texStr.tex = CreateTexture(bitMap,Q);


