function [texStr,stimData] = CLvirtualBarsDistances(Q)

    % Created Mar 30 2019

    % This function presents closed-loop virtual reality objects at
    % different distances
    
    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment


    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;
    
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % 9/14 using numDeg = 1 - maybe go high reso?
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    
    %% Input parameters
    %% closed loop stuff
    % Prepare fields to store the position and heading of flies
    if f==0 % first frame of epoch - initialize fly-state variable
        stimData.flyPosition = [0,0]; % in mm (need to check this!!)
        stimData.flyHeading = 0; % in deg
    end
    % Closed loop input
    [fTS,fWS,stimData] = GetFlyResponse(Q.timing.framenumber,Q.stims.duration,Q.flyTimeline.curFlyStates,stimData);
    leadFly = stimData.cl(1);
    fTS = fTS(leadFly);
    fWS = fWS(leadFly);
    
    %% things that concern the entire presentation
    fPU = p.framesPerUp;
    duration = p.duration; % frames
    mLum = p.mLum;
    
    if isfield(p, 'backgroundContrast')
        Cback = p.backgroundContrast;
        if isempty(Cback); Cback = 0; end
    else
        Cback = 0;
    end

    if isfield(p, 'groundContrast')
        Cground = p.groundContrast;
    else
        Cground = Cback;
    end
    
    
    %% things that concern virtual reality
    
    % This function present 2 pairs of objects (bars) with two different
    % distances in each quadrant of the virtual world. The sizes (both
    % height and width) of the bars are updated realistically, while the
    % bottom of the objects are fixed at the horizon (this could be
    % simplified). The sizes of the bars are constrained such that those
    % look identical in the initial frame (actual bar sizes differ depending
    % on the distances).
    % Flies always start at the center of the world, and are free to
    % explore during each epoch. The world may or may not have an invisible
    % boundary beyond which flies cannot enter. One could conceivably
    % analyze time spent in each quadrant etc. as the index of distance
    % preference.
    
    Cbar = p.barContrast;
    distL = p.leftBarDistance;  % in mm
    distR = p.rightBarDistance; % in mm
    initW = p.barInitialWidth;  % in degree
    initH = p.barInitialHeight; % in degree
    
    % calculate absolute position and size of the bars in the virtual world
    barPos = [[sind(-45) cosd(-45)]*distL; % Left bar
              [sind(45) cosd(45)]*distR];  % right bar
    barPos = [barPos;-barPos]; % Make the thing point symmetric
    
    barW   = [2*distL*tand(initW/2);
              2*distR*tand(initW/2)];
    barW   = [barW;barW]; % a row for each bar
    
    barH   = [distL*tand(initH);
              distR*tand(initH)];
    barH   = [barH;barH];
    
    if isfield(p,'boundaryR')
        boundaryR = p.boundaryR;
    else
        boundaryR = [];
    end
    
    % Gain of closed loop updates
    gainW = p.walkingGain;
    gainT = p.turningGain;
    
    %% Update of visual stimuli and drawing
    bitMap = zeros(sizeY,sizeX,fPU);
    fPos  = stimData.flyPosition;
    fHead = stimData.flyHeading;
    
    for ff = 1:fPU
        % prepare the matrix to draw things into
        preMap = ones(sizeY,sizeX) * Cback;
        preMap(round(sizeY/2):sizeY,:) = Cground;
        
        if f ~= 0 % first update is stationary - every fly sees the same thing at least for once 
            % Update heading first
            fHead = fHead + fTS/60/fPU*gainT;
            % Move into that direction
            fPos = fPos + [sind(fHead) cosd(fHead)]/60/fPU*fWS*gainW;
        end
        
        % Apply boundary condition
        if ~isempty(boundaryR)
            if norm(fPos) > boundaryR
                fPos = fPos / norm(fPos) * boundaryR;
            end
        end

        % draw the objects
        for bb = 1:4
            % Calculate direction and distance of the bar from the
            % virtual location of the fly
            barRelLoc = barPos(bb,:) - fPos;
            thisTheta = mod(atan2(barRelLoc(1),barRelLoc(2))/2/pi*360 - fHead,360);
            thisDist  = norm(barRelLoc);
            % Calculate apparent size of the bar (in degree)
            thisHalfW = atand(barW(bb)/2/thisDist);
            thisH = atand(barH(bb)/thisDist);
            % Draw the thing
            edgeB = round(sizeY/2);
            edgeT = max(round(sizeY/2-thisH),1);
            edgeL = min(max(round(thisTheta-thisHalfW),1),sizeX);
            edgeR = min(max(round(thisTheta+thisHalfW),1),sizeX);

            preMap(edgeT:edgeB,edgeL:edgeR) = Cbar; 

        end
        bitMap(:,:,ff) = preMap;
        
        % save state variables
        stimData.mat(1+(ff-1)*3) = fPos(1);
        stimData.mat(2+(ff-1)*3) = fPos(2);
        stimData.mat(3+(ff-1)*3) = fHead;
        
    end
    % pass position and heading variables to the next loop
    stimData.flyPosition = fPos;
    stimData.flyHeading  = fHead;
    
    bitMap =  mLum * ( 1 + bitMap );
    
    texStr.tex = CreateTexture(bitMap,Q);
end
