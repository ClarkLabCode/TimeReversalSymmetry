function [texStr,stimData] = BarMovingSineWaveBackground(Q)

% Created by Natalia 11/08/2023

% It's a merge of two functions: SineWaveMirrored and
% BarMovingVelOffsetCentalized

% It allows you to have a sinewave background and a bar moving either full
% (across the whole field of view), or a bar snippet (just for a portion of
% the screen).

p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
stimData = Q.stims.stimData;

sizeX = round(360/p.numDeg);

if ~isfield(p,'temporalFrequency')
    
    vel = p.velocity*pi/180;
    
else
    vel = p.temporalFrequency*p.lambda*pi/180;
    
end
lambda = p.lambda*pi/180; %wavelength in radians
framesPerUp = p.framesPerUp;
fPU =  p.framesPerUp;

mlum = p.mlum;
c = p.SineWavecontrast;

%%

targVel = p.targVel;
bar_offset = p.barOffset;
bar_width = p.barWidth;
contrast = p.barContrast;
duration = p.duration; % Important! the duration will determine the amplitude, until where the bar will move
laterality = p.BarLaterality; % -1, the bar moves to the left, +1 the bar moves to the right
FullBar = p.FullBar; % 1 for yes, 0 for no. If it's a full bar (1) it won't take into consideration the bar offset, 
%it will start from the start

% Duration =  if the vel is 180 deg/60f, you use this info to calculate how many
% seconds you want for that amplitude.
% x(duration) = 60*amplitude / vel

%% Initializing BitMap

if FullBar == 1
    if laterality == -1
        bar_pos = [sizeX:-1:sizeX-bar_width];
    elseif laterality == 1
        bar_pos = [1:bar_width];
    end
elseif FullBar == 0
    bar_pos = [];
    
    bar_pos = [bar_pos, bar_offset - [0:(bar_width-1)/2]];
    a = [bar_offset + [1:(bar_width-1)/2]];
    b = fliplr(a);
    bar_pos = [b, bar_pos];
end


deg_per_fpu = (1 /(60*fPU)*(targVel)); % degrees moved per fPU in deg

incrementPerFpu = (1:deg_per_fpu:duration*fPU);


%% left eye
%stimData.mat(1) is used as the wave phase. stimData.mat(2) is the velocity which
%is constant unless noise is added

if f == 1
stimData.sinPhase = 0;
end


theta = (0:sizeX-1)/sizeX*2*pi; %theta in radians
bitMap(1,sizeX,framesPerUp) = 0;

idx = (f-1)*fPU + [1:fPU]; % index for all fPU

for cc = 1:framesPerUp
    idx = (f-1)*fPU + [1:fPU]; % index for all fPU
    
    stimData.sinPhase = stimData.sinPhase + vel/(60*framesPerUp);
    
    bitMap = bitMap(:,1:360,:);
    
    bitMap(1,:,cc) = c*sin(2*pi*(theta-stimData.sinPhase)/lambda);
    
    stimData.mat(cc) = stimData.sinPhase;
    stimData.mat(6) = Q.timing.framenumber;
    stimData.mat(5) = p.temporalFrequency;
%     % stimData.mat(5) = p.velocity;
     stimData.mat(4) = c;
     stimData.mat(7) = lambda;
%     
    
    if laterality == -1
        vector_pos = bar_pos - round(incrementPerFpu(idx(cc)));
    else
        vector_pos = bar_pos + round(incrementPerFpu(idx(cc)));
    end
    
    vector_pos = vector_pos(vector_pos > 0);
    
    if p.MovingBar == 1
    bitMap(:, vector_pos, cc) = contrast;
    end
end
 
bitMap = mlum*(1 + bitMap);


texStr.tex = CreateTexture(bitMap,Q);

end

