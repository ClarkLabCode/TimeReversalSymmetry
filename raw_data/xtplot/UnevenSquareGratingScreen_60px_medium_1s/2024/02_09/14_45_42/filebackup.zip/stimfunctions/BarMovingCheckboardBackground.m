function [texStr,stimData] = BarMovingCheckboardBackground(Q)

% Created by Natalia 12/01/2023


p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
stimData = Q.stims.stimData;

numDeg = p.numDeg;
sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
sizeX = round(360/p.numDeg);

framesPerUp = p.framesPerUp;
fPU =  p.framesPerUp;

mlum = p.mlum;


%% Bar properties

targVel = p.targVel;
bar_offset = p.barOffset;
bar_width = p.barWidth;
contrast = p.barContrast;
duration = p.duration; % Important! the duration will determine the amplitude, until where the bar will move
laterality = p.BarLaterality; % -1, the bar moves to the left, +1 the bar moves to the right
FullBar = p.FullBar; % 1 for yes, 0 for no. If it's a full bar (1) it won't take into consideration the bar offset, 
%it will start from the start

% Duration =  if the vel is 180 deg/60f, you use this info to calculate how many
% seconds you want for that amplitude.
% x(duration) = 60*amplitude / vel

%% Checkboard properties


tResoDeg = p.tResoDeg;  % in degrees, should be integer multiplication of numDeg
tResoPx = round(tResoDeg/1);
tSize = ceil([sizeY,sizeX]/tResoPx); % the size of random matrices to be generated
    
    
    % intensity related
bgcont = p.bgcont;   % 0~1 - can be 2D if you want different contrasts for fore/backgorunds
cS   = p.cS; % beaware of the bit depth
    
    % temporal
bgfF   = p.bgfF; % flickering frequency of foreground
bgfPC  = min(60/bgfF*fPU,60*2*fPU);
    
bgMatOrig = ((randi(cS,tSize)-1)/(cS-1)*2-1)*bgcont;
bgMatExpanded = imresize(bgMatOrig,tResoPx,'box');
  
bg = bgMatExpanded(1:sizeY,1:sizeX); % trimming

%% Initializing BitMap

if FullBar == 1
    if laterality == -1
        bar_pos = [sizeX:-1:sizeX-bar_width];
    elseif laterality == 1
        bar_pos = [1:bar_width];
    end
elseif FullBar == 0
    bar_pos = [];
    
    bar_pos = [bar_pos, bar_offset - [0:(bar_width-1)/2]];
    a = [bar_offset + [1:(bar_width-1)/2]];
    b = fliplr(a);
    bar_pos = [b, bar_pos];
end


deg_per_fpu = (1 /(60*fPU)*(targVel)); % degrees moved per fPU in deg

incrementPerFpu = (1:deg_per_fpu:duration*fPU);


%% Drawing the bitmap

bitMap = repmat(bg,1,1,3); %checkboard as background


idx = (f-1)*fPU + [1:fPU]; % index for all fPU

for cc = 1:framesPerUp
    idx = (f-1)*fPU + [1:fPU]; % index for all fPU
   
    bitMap = bitMap(:,1:360,:);
    
    if laterality == -1
        vector_pos = bar_pos - round(incrementPerFpu(idx(cc)));
    else
        vector_pos = bar_pos + round(incrementPerFpu(idx(cc)));
    end
    
    vector_pos = vector_pos(vector_pos > 0);
    
    if p.MovingBar == 1
    bitMap(:, vector_pos, cc) = contrast;
    end
end
 
bitMap = mlum*(1 + bitMap);


texStr.tex = CreateTexture(bitMap,Q);

end

