function [texStr,stimData] = WidthHeightObjectMoving(Q)

% NOTE: when you create a new stimulus function, you must update the
% stimlookup table in the folder paramfiles. paramfiles will also hold the
% text file giving lists of parameters that comprise an experiment

%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam; 

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1; 

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

% Reading everything from the paramfile
mlum        = p.mlum;
vel         = p.direction * p.vel; %velocity in deg/s
width       = p.width;             %width of square or bar in deg
squareH     = p.squareHeight;
framesPerUp = p.framesPerUp; % how many frames you have / update (usually 3)
barPolarity = p.barPolarity;
squareCentered = p.squareCentered; % 1 for yes, 0 for no
squareYpos = p.squareYpos ;
direction = p.direction;
duration = p.duration;
% You are going to store the X-position of the object in stimData.currPos
% field. This will be communicated to subsequent calls of this function
if f == 1 % if this is the first frame of epoch... 
    switch p.direction
        case 1
            stimData.currPos = 1;
        case -1
            stimData.currPos = 360;
    end
end

% Displacement per frame 
deg_per_fpu = (1 /(60*framesPerUp)*(abs(vel))); % degrees moved per fPU in deg

incrementPerFpu = (1:deg_per_fpu:duration*framesPerUp);

if direction == -1
    obj_pos = [sizeX:-1:sizeX-width];
elseif direction == 1
    obj_pos = [1:width];
end



if squareCentered == 1
    squareYpos = round((sizeY)/2);
end
    
idx = (f-1)*framesPerUp + [1:framesPerUp]; % index for all fPU

bitMap = zeros(sizeY,sizeX,framesPerUp);

for cc = 1:framesPerUp
    
    upey = round(squareYpos+squareH/2);
    downey = round(squareYpos-squareH/2);
    
    if direction == -1
        vector_pos = obj_pos - round(incrementPerFpu(idx(cc)));
    else
        vector_pos = obj_pos + round(incrementPerFpu(idx(cc)));
    end
    
    vector_pos = vector_pos(vector_pos>0);
    
    bitMap(downey:upey,vector_pos,cc) = barPolarity;

    bitMap = bitMap(:,1:360,:);
end

bitMap = mlum*(1 + bitMap);

%always include this line in a stim function to make the texture from the
%bitmap

texStr.tex = CreateTexture(bitMap,Q);
end