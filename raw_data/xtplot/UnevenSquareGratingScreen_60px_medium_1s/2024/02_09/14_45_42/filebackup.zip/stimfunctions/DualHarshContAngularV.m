function [texStr,stimData] = DualHarshContAngularV(Q)
%This function creates looming circle at a position on the screen.
%first the circle remains stationaty for some time then it starts to increase in size on
%the frame specified in param file. The circle increases to a final size
%specified by the user in the param file. The rate of increase of size is
%calculated based on the duration of the epoch.



%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
%User inputs
%User inputs

numDeg = p.numDeg;
fPU = p.framesPerUp; % framesPerUp
contrast = p.contrast;
bagContrast=p.bagContrast;
mlum=p.mlum;

if isfield(p, 'randContra')
    randContra=p.randContra;
else
    randContra=0;
end

%Loom size
iR= p.initialRadius;
fR=p.finalRadius;

% %LVratio
% LV=p.LV;


%calculate velocity and initial distance
L=p.L;

% Looming velocity
v=(p.velocity/60);
 

% looming duration
 LSF = p.loomStartFrame;%loom start frame
 
 dur=(fR-iR)/v;
 LEF=LSF+dur;

   

%position on the screen
rX1=p.xPosition;
rY1=round(sizeY/2);

%position on the screen
if p.xPosition==90
    rX2=p.xPosition+180;
elseif p.xPosition==270
    rX2=p.xPosition-180;
end

rY2=rY1;

%% Initializing BitMap
bitMap= zeros(sizeY,sizeX,fPU);
bitMap(:,:,:) =bagContrast;

for fr = 1:fPU
    
    if f>=LSF &&f<LEF
        t = (f-1)*fPU + fr; % index for all fPU
%         d=dInitial-(v/3)*(t-((LSF-1)*fPU));
%         radius=atand(L/d);
          radius1=round(iR+(v/3)*(t-((LSF-1)*fPU)));
          radius2=round(fR-(v/3)*(t-((LSF-1)*fPU)));
     %        
    elseif f<LSF
        radius1=iR;
        radius2=fR;
    elseif f>= LEF
        radius1=fR;
        radius2=iR;
    end
    if radius1>0
        preMap = ones(sizeY,sizeX)*bagContrast;
        [XX,YY] = meshgrid(1:sizeX,(1:sizeY));
        mask1 = sqrt((XX-rX1).^2 + (YY-rY1).^2)<radius1;
        mask2 = sqrt((XX-rX2).^2 + (YY-rY2).^2)<radius2;
        
        mask=mask1+mask2;
        preMap(mask==1) = contrast;
         
        bitMap(:,:,fr) = preMap;
    end
       

end
bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);
end