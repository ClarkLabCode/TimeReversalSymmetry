function [texStr,stimData] = NathanMovingEdgesXTRandomization(Q)
%Idea - first, make store xt plots in some data structure outside of this
%function, then pull frome that.
%Create database of XT plots that I can pull from?
%symedges(100110s90p30)
%Run stimuli with each flip
%Use repmat to ignore y values
%Param file - 
%Have python save bitmap as either png or .mat file
%https://stackoverflow.com/questions/4814569/what-is-the-fastest-way-to-load-data-in-matlab
%imread is useful
%matlab also lets you call python scripts?
%Persistent variables? Get all of these bitmaps the first time I run the
%stimfunction
%Randomize time phase and x phase
%also need a reliable way to present flipped versions?
% this is to provide the general structure for the texture generating codes
% to be used with PTB in this framework. 

% NOTE: when you create a new stimulus function, you must update teh
% stimlookup table in the folder paramfiles. paramfiles will also hold the
% text file giving lists of parameters that comprise an experiment


p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
stimData = Q.stims.stimData;

texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 1; % or 2

% must also set up the scaling factors here for use in the texture
% rendering
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% basic parameters
duration = p.duration; %appears to be in frames
framesPerUp = p.framesPerUp; 
%mlum = p.lum; - I don't think I need this
if p.numDeg == 0
        sizeX = 1;
        sizeY = 1;
    else
        sizeX = round(360/p.numDeg);
        sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180)));
end

%Other stimulus-specific parameters
stimulus = p.stimulus; %cell array
shape = p.shape; %cell array
xtess = p.xtess;
ttess = p.ttess;
xflip = p.xflip;
tflip = p.tflip;
cflip = p.cflip;

%Various numbers: xcells = sizeX/shape(1)
%tcells = duration/shape(0)
%Figure out how many cells to make black depending on various factors

%persistent stimData.full_bitmap

%load bitmap if f == 1
if f == 1
    sysConfig = GetSystemConfiguration();
                
    bitmapFolder = sysConfig.NathanBitmapFilePath;

    %calculations to determine desired t dimension
    sizeT = duration*framesPerUp;

    %Load in full bitmap
    %Bitmap named as x + "x" + t + ", xtess=" + xtess + 
    %", ttess=" + ttess + ", shape=" + shape + ", " + 
    %stimulusAsInteger

    binaryStim = double(eq(stimulus, ones(1, length(stimulus))));

    %Convert binaryStim to an integer
    z=2.^(length(binaryStim)-1:-1:0);
    stimulusAsInt=sum(binaryStim.*z);

    filename = strcat(num2str(sizeX), 'x', num2str(sizeT), ',xtess=',  ...
        num2str(xtess), ',ttess=', num2str(ttess), ',shape=(', ...
        num2str(shape(1)), ',', num2str(shape(2)), '),', ...
        num2str(stimulusAsInt), '.png');

    imageFile = fullfile(bitmapFolder, filename);

    if ~(isfile(imageFile))
        pe = pyenv;
        pe.Version;
        if isempty(pe.Version)
            disp("file does not exist, and file cannot be created with python.")
            disp("Looking for file " + imageFile +".")
            disp("To create this file, run moving_edges.bitmap_as_png(["...
                + regexprep(num2str(stimulus),'\s+',',') + "], (" + regexprep(num2str(shape), '\s+',',') + "), "...
                + num2str(xtess ) + ", " + num2str(ttess) + ", " + num2str(sizeX) + ", " + num2str(sizeT) + ").");
            return;
        else
            pythonPath = sysConfig.pythonPath;
            if count(py.sys.path, pythonPath) ==0
                insert(py.sys.path, int32(0), pythonPath);
            end
            %py.moving_edges.bitmap_as_png(stimulus, shape, xtess, ttess, sizeX, sizeT, edge_speed = -1, priority = "xtess", path= (os.path.dirname(__file__) + "/me_stimuli_images"));
            system("python -c ""import sys; sys.path.append(r'" + pythonPath +"'); import moving_edges; moving_edges.bitmap_as_png(["...
                + regexprep(num2str(stimulus),'\s+',',') + "], (" + regexprep(num2str(shape), '\s+',',') + "), "...
                + num2str(xtess ) + ", " + num2str(ttess) + ", " + num2str(sizeX) + ", " + num2str(sizeT) + ", path = r'" ...
                + bitmapFolder + "')""")
        end
        
    end
    temp_bitmap = imread(imageFile);
    temp_bitmap = cast(temp_bitmap, 'double');
    temp_bitmap = temp_bitmap/255;
    if tflip
        temp_bitmap = flip(temp_bitmap, 1);
    end
    if xflip
        temp_bitmap = flip(temp_bitmap, 2);
    end
    if cflip
        temp_bitmap = 1 - (temp_bitmap);
    end
    stimData.full_bitmap = circshift(temp_bitmap, [randi([0, sizeT]) randi([0, sizeX])]);
end


bitmap = zeros(sizeY,sizeX,framesPerUp);
%First dimension is rows, 2nd dimension is columns.
%
for ff = 1:framesPerUp
    subframe = (f - 1) * framesPerUp + ff;
    bitmap(:,:,ff) = repmat(stimData.full_bitmap(subframe, :), sizeY, 1);
end

%{
%Weird time looping
for ff = 1:framesPerUp
        t =(f-1)*(1/60) + ff*(1/60)*(1/framesPerUp);
        %leadingEdgePhase = minPhase + mod(speedDeg*t,phaseExtent);
        %trailingEdgePhase = leadingEdgePhase - barWidthDeg;
        %thisFrame = ones(sizeY,sizeX)*backgroundLum;
        %thisFrame(trailingEdgePhase < phaseMap & phaseMap < leadingEdgePhase) = barLum;
        bitmap(:,:,ff) = thisFrame;
end
%}

%always include this line in a stim function to make the texture from the
%bitmap
texStr.tex = CreateTexture(bitmap,Q);