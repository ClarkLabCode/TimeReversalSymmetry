
function [texStr,stimData] = WuHengSinInverted(Q)

%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
% input from user
sinShift = p.sinShift;  % Shift of displacement between sin waves, unit of sinLambda, + for right,- for left
duration = p.duration;  % Duration of epoch in frames
coverDur = p.coverDur;  % Number of frames of white/black/gray covering sin
sinDur = p.sinDur;      % Number of frames of each sin wave
sinLambda = p.sinLambda*pi/180;    % Spatial wavelength of sin waves
sinContrast = p.sinContrast; % Constract of sin waves
coverCor = p.coverCor;  % -1 = black, 0 = gray, 1 = white
fPU = p.framesPerUp;
mlum = p.mlum;


 x = 0:2*pi/(sizeX-1):2*pi;
% x = [1:sizeX];
% y = [1:sizeY];
% [X,Y] = meshgrid(x,y);

cycleDur = coverDur + sinDur;   % Duration in frames of sin and cover
frameWithinCycle = mod(f-1,cycleDur)+1;
if frameWithinCycle > sinDur
    bitMap = coverCor*repmat((sinContrast*sin(2*pi*x/sinLambda - 2*pi*sinShift*floor((f-1)/cycleDur))),sizeY,1,fPU); 
else
    bitMap = repmat((sinContrast*sin(2*pi*x/sinLambda - 2*pi*sinShift*floor((f-1)/cycleDur))),sizeY,1,fPU); 
end

bitMap = mlum*(1 + bitMap); % converts contrast to luminance

%always include this line in a stim function to make the texture from the
%bitmap

texStr.tex = CreateTexture(bitMap,Q);


