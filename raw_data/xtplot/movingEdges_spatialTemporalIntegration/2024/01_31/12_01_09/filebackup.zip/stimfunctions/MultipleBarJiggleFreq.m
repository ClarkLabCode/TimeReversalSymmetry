function [texStr,stimData] = MultipleBarJiggleFreq(Q)

%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
% input from user
frequency = p.frequency; % HZ, Cycles per second
amplitude = p.amplitude; % degrees, how far away will the bar go
numDeg = p.numDeg;
bar_offset = p.barOffset; % where the bar will start
bar_width = p.barWidth;
num_cycles = p.numCycles; % how many cycles we will have
contrast = p.contrast;
fPU = p.framesPerUp; % framesPerUp
mlum = p.mlum;
duration = p.duration;

zerodir = p.zerodir; % direction the bar will move, only for offset = 180, 1 = right, -1 = left
% stuff
%frm_rate = 60 * fPU;

% DURATION MUST BE = ( NUM_CYCLES/ FREQUENCY ) * 60
if abs( p.duration - (num_cycles/frequency)*60 ) < 2
    % we're all good
else
    % the user gave me a duration that doesn't make sense
    error('ERROR: user gave me a duration that does not make sense')
end


vector_pos = [];
time = linspace( 0, duration/60, duration*fPU ); % seconds
idx = (f-1)*fPU + [1:fPU];

for i = 1 : length(bar_offset)
    bar_pos = [];
    bar_pos = [bar_pos, bar_offset(i) + [0:(bar_width-1)]-floor(bar_width/2)]; % actaully a vector of positions!
    if bar_offset(i) < 180
        a =  amplitude*sin(frequency*time(idx)*2*pi);
    elseif bar_offset(i) > 180
        a = - ( amplitude*sin(frequency*time(idx)*2*pi));
    elseif bar_offset(i) == 180
        if zerodir == 1
            a =  amplitude*sin(frequency*time(idx)*2*pi);
        elseif zerodir == -1
            a = - ( amplitude*sin(frequency*time(idx)*2*pi));
        end
    end
    
    vector_pos = [vector_pos,round(a' + bar_pos)];
end



%a =  amplitude*sin(frequency*time(idx)*2*pi);
%vector_pos = round(a' + bar_pos);



%% old code

%duration = frequency*num_cycles*60; % in ms, or in frames
%total_disp = amplitude*4; % total distance of bar in deg
%velocity = total_disp*frequency; %velocity of bar to complete cycle in freq, deg/s SPEED!!!!!!

% 
% 
% % making a vector of time
% dt = 1 / frm_rate; % seconds per frame
% %tf = amplitude / velocity; % seconds
% tf = 1/frequency; % time for 1 cycle
% t_discrete = [0 : dt : (tf/4)]; % time for 1/4 of a cycle

%disp_per_subframe = velocity/60/fPU; % this is how many degrees are displaced by subframe, or 1/180 sec when fPU = 1.
% It's the same as the difference between adjacent bar positions in the
% vector below. So that the bar is drawn in every new position.

% making bar_offset as a function of time
%bar_pos = velocity .* t_discrete + bar_offset;
%bar_pos = frequency .* t_discrete + bar_offset;
% bar_pos = linspace( bar_offset, bar_offset+amplitude, length(t_discrete) );
% bar_pos = [bar_pos, flip(bar_pos), flip(bar_pos) - amplitude, bar_pos - amplitude]; % one complete cycle
% bar_pos = repmat(bar_pos, 1, num_cycles); % 483
%
% % for i = 1 : (bar_width - 1)
% %     bar_pos = [bar_pos; bar_pos(end,:)+1];
% % end
%
% bar_pos = repmat(bar_pos, bar_width, 1) + [0:(bar_width-1)]';
%
% bar_pos = round(bar_pos);

%% Initializing BitMap


%stimData.ind = 1;
bitMap= zeros(sizeY,sizeX,fPU);


for i = 1 : fPU
    bitMap(:, vector_pos(i,:), i) = contrast;
    stimData.mat(i) = vector_pos(i,1);
end


% 
% for i = 1:length(bar_offsets)
%     bar_offset = bar_offsets(i)
%     bar_pos = linspace( bar_offset, bar_offset+amplitude, length(t_discrete) );
%     bar_pos = [bar_pos, flip(bar_pos), flip(bar_pos) - amplitude, bar_pos - amplitude]; % one complete cycle
%       bar_pos = repmat(bar_pos, 1, num_cycles); % 483
% 
%     % for i = 1 : (bar_width - 1)
%     %     bar_pos = [bar_pos; bar_pos(end,:)+1];
%     % end
%     
%     if bar_offset >= 180
%         bar_pos = repmat(bar_pos, bar_width, 1) - [0:(bar_width-1)]'; % Moving towards the center, so going to the left
%     elseif bar_offset < 180
%         bar_pos = repmat(bar_pos, bar_width, 1) + [0:(bar_width-1)]'; % Moving towards the center, so going to the right
%     end
% 
%    
%     bar_pos = round(bar_pos);
%    
%     for fr = 1:fPU
%        ind = (f-1)*3 + fr;
%        bitMap(:, bar_pos(:,ind) ,fr)= contrast;
%     end
%    
% end


bitMap = mlum*(1 + bitMap);

%always include this line in a stim function to make the texture from the
%bitmap

texStr.tex = CreateTexture(bitMap,Q);

% BarPosPerFrame = Q.vector_pos; % Modification here, trying to save bar pos at each frame
%Q.paths.data = vector_pos;
end