function [texStr,stimData] = CLVirtualObjectShadowing(Q)

    % Created Mar 23 2021
   
    % Present a rectangular object with physical dimensions, whose position
    % is synced to the fly's walking (turning is ignored)
    % More specifically, if we define the position of the fly at time t as
    % r(t) = [0, y(t)], the position of the object is determined as
    % s(t) = [X0 + ay(t), Y0 + by(t), Z0]
    % Gain in z is disabled because it makes things too complicated and I
    % probably would not use it anyways
    
    % Object is assumed to be a circular column (changed 3/29/21)
    
    % This function assumes there is only one fly being run per experiment
    % at position 1 unless explicitly provided with the number of the flies
    % through the comment section ('condstr'). If condstr is set to some
    % number larger than 1, this function assumes there are flies loaded on
    % position 1 thorugh N, and randomly decide one of them to be the lead
    % fly in each epoch.
    
    % Not sure if this works when the plane is strongly oriented and the
    % side of the obejct is reveresed
    
    %% Parameters
    p = Q.stims.currParam;                               % Struct with current epoch stimulus parameters
    f = Q.timing.framenumber - Q.timing.framelastchange; % Relative frame number
    stimData = Q.stims.stimData;                         % Struct to communicate between multiple calls of this function
    
    % degree per pixel (usually fixed at 1)
    numDeg = p.numDeg;
    % define output bitmap dimensions
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    cH = Q.cylinder.cylinderHeight;
    cR = Q.cylinder.cylinderRadius;
    
    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.
    
    %% Beginnig of epoch initialization
    if f==0 
        % Reset the current position of the fly
        stimData.flypos = 0;
        % Read how many flies are being run (if not specified, 1)
        nFly = max(1,str2double(Q.condstr));
        % Decide which fly to use as the lead fly randomly
        stimData.leadFly = randi(nFly);
    end
    
    %% Closed loop read-outs
    % Get flies' walking response
    [~,walkingSpeed,stimData] = GetFlyResponse(Q.timing.framenumber,Q.stims.duration,Q.flyTimeline.curFlyStates,stimData);
    % rewrite stimData.cl(1) (GetFlyResponse assign lead fly but we ignore that 
    % -- stmData.cl is saved in stimData.mat -- see WriteStimData())
    stimData.cl(1) = stimData.leadFly;
    % We only care lead fly walking speed
    walkingSpeed = walkingSpeed(stimData.leadFly); % this is in mm/s unit (see FlyTimeline)
    flypos = stimData.flypos;
    
    %% Stimulus parameters
    fPU   = p.framesPerUp;  % frames per 60Hz update
    mLum  = p.mLum;         % mean luminance
    bgC   = p.backgroundContrast; % maybe I should do cluttered background in future?
    obC   = p.objectContrast; 
    
    % object initial position (in mm)
    X0 = p.initialX;
    Y0 = p.initialY;
    Z0 = p.initialZ;
    
    % object movement gain (in mm)
    gX = p.xGain;
    gY = p.yGain;
    
    % object size (in mm)
    obW = p.objectWidth; % diameter
    obH = p.objectHeight;
    
    %% Update of visual stimuli and drawing
    bitMap = zeros(sizeY,sizeX,fPU);
    for ff = 1:fPU
        % Prepare the matrix to draw things into
        objectMask = zeros(sizeY,sizeX);
        % Update fly position (in mm)
        flypos = flypos + walkingSpeed/60/fPU;
 
        % Calculate the object position in fly centered coordinate (in XY)
        objpos = [X0+gX*flypos, Y0+(gY-1)*flypos];

        % Covnert position to visual angle
        centerang = atan2d(objpos(2),objpos(1));
        
        % Calculate the coordinates of the edges of the objects
        edge1pos = objpos + obW*[cosd(centerang+90), sind(centerang+90)]/2;
        edge2pos = objpos + obW*[cosd(centerang-90), sind(centerang-90)]/2;
        
        % Convert to degree
        % Subtract from 270 because cylinder wrapping starts behind
        edge1ang = 270-atan2d(edge1pos(2),edge1pos(1));
        edge2ang = 270-atan2d(edge2pos(2),edge2pos(1));
        
        % Cut off at the edge
        edge1ind = min(max(round(mod(edge1ang,360)/numDeg),1),sizeX);
        edge2ind = min(max(round(mod(edge2ang,360)/numDeg),1),sizeX);
        
        % Calculate vertical edges
        centerDist = sqrt(sum(objpos.^2));
        topang = atan2d(Z0-obH/2,centerDist);
        botang = atan2d(Z0+obH/2,centerDist);
        
        % convert angles to index
        topind = max(round(sizeY/2*(2*cR*tand(topang)/cH + 1)),1);
        botind = min(round(sizeY/2*(2*cR*tand(botang)/cH + 1)),sizeY);
        
        
        % object mask
        objectMask(topind:botind,edge1ind:edge2ind) = 1;        
        
        % fill in
        bitMap(:,:,ff) = objectMask*obC + (1-objectMask)*bgC;
        
        % Save fly position (object position can be easily recovered within
        % the analysis function so I'm not saving it)
        stimData.mat(ff) = flypos;
    end
    
    % pass the position variable to the next loop
    stimData.flypos  = flypos;
    
    % convert contrast to luminance
    bitMap =  mLum * ( 1 + bitMap );
    
    % convert bitmap to a PTB texture
    texStr.tex = CreateTexture(bitMap,Q);
end
