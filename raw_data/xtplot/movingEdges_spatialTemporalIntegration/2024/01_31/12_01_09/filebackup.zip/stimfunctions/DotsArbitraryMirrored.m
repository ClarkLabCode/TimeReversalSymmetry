function [texStr,stimData] = DotsArbitraryMirrored(Q)

sii = Q.stims.currStimNum;
p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number

stimData = Q.stims.stimData;

update = round((60*p.framesPerUp)/p.updateRateA);

if mod((60*p.framesPerUp)/p.updateRateA,1)~=0
    error('update rate requested is not a factor of projector dispaly rate. Rounding and continuing');
end
    
dtA = p.dtA;
dxA = p.dxA; %direction and amplitude of the motion
dyA = p.dyA;

if ~isfield(p,'densityA')
    densityA = 1;
else
    densityA = p.densityA;
end

if ~(p.cB==0)
    densityA = 1-(1-densityA).^(1/2);
end

if length(dxA)~=length(dtA) || length(dyA)~=length(dtA)
    error('dt/dx/dy vectors must be same size');
end

%%%%%%%%%%%%%% Positive Dt is defined as going forward in time
%%%%%%%%%%%%%% positive x is to the right, positive y is up

% add in the implicit 0 point
fullDt = [dtA 0];
fullDx = [dxA 0];
fullDy = [dyA 0];

fullDt = fullDt - max(fullDt);

% find dt's which equal 0
dtMinLoc = fullDt==0;

% find the new zero point which is the largest dx value which is also dt=0
% find dx's which equal max dx
dxMaxLoc = fullDx==max(fullDx(dtMinLoc));

newReferencePoint = dxMaxLoc & dtMinLoc;

dyMaxLoc = fullDy==max(fullDy(newReferencePoint));

newReferencePoint = newReferencePoint & dyMaxLoc;

% subtract off dx and dy's so that the dx and dy at the reference point is 0
fullDx = fullDx - fullDx(newReferencePoint);
fullDy = fullDy - fullDy(newReferencePoint);

dtA = fullDt(~newReferencePoint);
dxA = fullDx(~newReferencePoint);
dyA = fullDy(~newReferencePoint);

cA = p.cA;
framesPerUp = p.framesPerUp;

parity = p.parityA;

texStr.opts = 'full'; % see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

if p.numDegXA == 0
    sizeXA = 1;
else
    sizeXA = round(360/p.numDegXA);
end

if p.numDegYA == 0
    sizeYA = 1;
else
    sizeYA = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDegYA*pi/180)));
end


maxDelay = 0;

%%%%% note this stimulus is designed so that the first correlation occurs
%%%%% on the first timepoint of a new epoch, but this does NOT work if
%%%%% there is an update difference between the two epochs
if ~isfield(stimData,'lastContrast')
    stimData.lastContrast = 0;
end

lastContrast = stimData.lastContrast;

if f == 1
    if ~isfield(stimData,'glidMemA') || (sizeYA ~= size(stimData.glidMemA,1)) || (sizeXA ~= size(stimData.glidMemA,2)) || (lastContrast==0)
        for ii = 1:size(Q.stims.params,2)
            thisEpochMaxDelay = max([Q.stims.params(ii).dtA 0]-min([Q.stims.params(ii).dtA 0]));
            
            if thisEpochMaxDelay > maxDelay
                maxDelay = thisEpochMaxDelay;
            end
        end
        denseMat = rand(sizeYA,sizeXA,maxDelay+1) < densityA;
        randInit = 2*(round(rand(sizeYA,sizeXA,maxDelay+1)))-1;
        stimData.glidMemA =  randInit.* denseMat;
    end
end

% left buffer is the absolute value of the minimum of dx so long as that
% minimum is negative
leftBuffer = abs(min(fullDx));
rightBuffer = max(fullDx);

topBuffer = abs(min(fullDy));
bottomBuffer = max(fullDy);

bitMap = zeros(sizeYA,sizeXA,framesPerUp);

hzFrame = f*framesPerUp-(framesPerUp-1):f*framesPerUp;
updateFrame = mod(hzFrame-1,update) == 0;

for cc = 1:framesPerUp
    c = p.cA;
    
    if c~=0
        if updateFrame(cc)
            stimData.glidMemA = cat(3,ones(sizeYA,sizeXA),stimData.glidMemA(:,:,1:end-1));

            % generate the left right top and bottom buffers where we can't
            % define the gliders
            stimData.glidMemA((1:topBuffer),:,1) = (2*round(rand(topBuffer,sizeXA))-1).* (rand(topBuffer,sizeXA) < densityA);
            stimData.glidMemA((end-bottomBuffer+1):end,:,1) = (2*round(rand(bottomBuffer,sizeXA))-1).*(rand(bottomBuffer,sizeXA) < densityA);
            stimData.glidMemA(:,1:leftBuffer,1) = (2*round(rand(sizeYA,leftBuffer))-1).*(rand(sizeYA,leftBuffer) < densityA);
            stimData.glidMemA(:,(end-rightBuffer+1):end,1) = (2*round(rand(sizeYA,rightBuffer))-1).*(rand(sizeYA,rightBuffer) < densityA);

            if ~isempty(dtA)
                for yy = (topBuffer+1):(sizeYA-bottomBuffer)
                    for xx = (leftBuffer+1):(sizeXA-rightBuffer)
                        for ct = 1:length(dtA)
                            stimData.glidMemA(yy,xx,1) = stimData.glidMemA(yy,xx,1).*stimData.glidMemA(yy+dyA(ct),xx+dxA(ct),-dtA(ct)+1);
                        end

                        % since parity is 1 or -1 and all the values in our glider are
                        % 1 or -1 this division could be a multiplication. However, in
                        % principle if you used a non binary image you would divide
                        % instead of multiply so I'll keep it here
                        stimData.glidMemA(yy,xx,1) = parity.*stimData.glidMemA(yy,xx,1);
                    end
                end
            else
                stimData.glidMemA(:,:,1) = (2*round(rand(sizeYA,sizeXA))-1).*(rand(sizeYA,sizeXA) < densityA);
            end
        end
    else
        if framesPerUp >= 12
            stimData.glidMemA(:,:,1) = (-ones(sizeYA,sizeXA)).^hzFrame(cc);
            c = 1;
        end
    end
    
    bitMapA(:,:,cc) = c*stimData.glidMemA(:,:,1);
end


%%
update = round((60*p.framesPerUp)/p.updateRateA);

if mod((60*p.framesPerUp)/p.updateRateA,1)~=0
    error('update rate requested is not a factor of projector dispaly rate. Rounding and continuing');
end
    
dtB = p.dtB;
dxB = p.dxB; %direction and amplitude of the motion
dyB = p.dyB;

if ~isfield(p,'densityB')
    densityB = 1;
else
    densityB = p.densityB;
end

if ~(p.cB==0)
    densityB = 1-(1-densityB).^(1/2);
end

if length(dxB)~=length(dtB) || length(dyB)~=length(dtB)
    error('dt/dx/dy vectors must be same size');
end

%%%%%%%%%%%%%% Positive Dt is defined as going forward in time
%%%%%%%%%%%%%% positive x is to the right, positive y is up

% add in the implicit 0 point
fullDt = [dtB 0];
fullDx = [dxB 0];
fullDy = [dyB 0];

fullDt = fullDt - max(fullDt);

% find dt's which equal 0
dtMinLoc = fullDt==0;

% find the new zero point which is the largest dx value which is also dt=0
% find dx's which equal max dx
dxMaxLoc = fullDx==max(fullDx(dtMinLoc));

newReferencePoint = dxMaxLoc & dtMinLoc;

dyMaxLoc = fullDy==max(fullDy(newReferencePoint));

newReferencePoint = newReferencePoint & dyMaxLoc;

% subtract off dx and dy's so that the dx and dy at the reference point is 0
fullDx = fullDx - fullDx(newReferencePoint);
fullDy = fullDy - fullDy(newReferencePoint);

dtB = fullDt(~newReferencePoint);
dxB = fullDx(~newReferencePoint);
dyB = fullDy(~newReferencePoint);

cB = p.cB;
framesPerUp = p.framesPerUp;

parity = p.parityB;

texStr.opts = 'full'; % see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

if p.numDegXB == 0
    sizeXB = 1;
else
    sizeXB = round(360/p.numDegXB);
end

if p.numDegYB == 0
    sizeYB = 1;
else
    sizeYB = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDegYB*pi/180)));
end


maxDelay = 0;

%%%%% note this stimulus is designed so that the first correlation occurs
%%%%% on the first timepoint of a new epoch, but this does NOT work if
%%%%% there is an update difference between the two epochs
if ~isfield(stimData,'lastContrast')
    stimData.lastContrast = 0;
end

lastContrast = stimData.lastContrast;

if f == 1
    if ~isfield(stimData,'glidMemB') || (sizeYB ~= size(stimData.glidMemB,1)) || (sizeXB ~= size(stimData.glidMemB,2)) || (lastContrast==0)
        for ii = 1:size(Q.stims.params,2)
            thisEpochMaxDelay = max([Q.stims.params(ii).dtB 0]-min([Q.stims.params(ii).dtB 0]));
            
            if thisEpochMaxDelay > maxDelay
                maxDelay = thisEpochMaxDelay;
            end
        end
        denseMat = rand(sizeYB,sizeXB,maxDelay+1) < densityB;
        randInit = 2*(round(rand(sizeYB,sizeXB,maxDelay+1)))-1;
        stimData.glidMemB =  randInit.* denseMat;
    end
end

% left buffer is the absolute value of the minimum of dx so long as that
% minimum is negative
leftBuffer = abs(min(fullDx));
rightBuffer = max(fullDx);

topBuffer = abs(min(fullDy));
bottomBuffer = max(fullDy);

bitMap = zeros(sizeYB,sizeXB,framesPerUp);

hzFrame = f*framesPerUp-(framesPerUp-1):f*framesPerUp;
updateFrame = mod(hzFrame-1,update) == 0;

for cc = 1:framesPerUp
    c = p.cB;
    
    if c~=0
        if updateFrame(cc)
            stimData.glidMemB = cat(3,ones(sizeYB,sizeXB),stimData.glidMemB(:,:,1:end-1));

            % generate the left right top and bottom buffers where we can't
            % define the gliders
            stimData.glidMemB((1:topBuffer),:,1) = (2*round(rand(topBuffer,sizeXB))-1).* (rand(topBuffer,sizeXB) < densityB);
            stimData.glidMemB((end-bottomBuffer+1):end,:,1) = (2*round(rand(bottomBuffer,sizeXB))-1).*(rand(bottomBuffer,sizeXB) < densityB);
            stimData.glidMemB(:,1:leftBuffer,1) = (2*round(rand(sizeYB,leftBuffer))-1).*(rand(sizeYB,leftBuffer) < densityB);
            stimData.glidMemB(:,(end-rightBuffer+1):end,1) = (2*round(rand(sizeYB,rightBuffer))-1).*(rand(sizeYB,rightBuffer) < densityB);

            if ~isempty(dtB)
                for yy = (topBuffer+1):(sizeYB-bottomBuffer)
                    for xx = (leftBuffer+1):(sizeXB-rightBuffer)
                        for ct = 1:length(dtB)
                            stimData.glidMemB(yy,xx,1) = stimData.glidMemB(yy,xx,1).*stimData.glidMemB(yy+dyB(ct),xx+dxB(ct),-dtB(ct)+1);
                        end

                        % since parity is 1 or -1 and all the values in our glider are
                        % 1 or -1 this division could be a multiplication. However, in
                        % principle if you used a non binary image you would divide
                        % instead of multiply so I'll keep it here
                        stimData.glidMemB(yy,xx,1) = parity.*stimData.glidMemB(yy,xx,1);
                    end
                end
            else
                stimData.glidMemB(:,:,1) = (2*round(rand(sizeYB,sizeXB))-1).*(rand(sizeYB,sizeXB) < densityB);
            end
        end
    else
        if framesPerUp >= 12
            stimData.glidMemB(:,:,1) = (-ones(sizeYB,sizeXB)).^hzFrame(cc);
            c = 1;
        end
    end
    
    bitMapB(:,:,cc) = c*stimData.glidMemB(:,:,1);
end

%%
bitMap = bitMapB+bitMapA;
bitMap(abs(bitMap) > 1) = bitMap(abs(bitMap) > 1)./abs(bitMap(abs(bitMap) > 1));

bitMap = 0.5*(bitMap+1);

if p.twoEyes
    rightEye = fliplr(bitMap);

    bitMap = CombEyes(bitMap,rightEye,p,f);
end

if f == p.duration
    stimData.lastContrast = max([p.cA p.cB]);
end

%always include this line in a stim function to make the texture from the
%bitmap
texStr.tex = CreateTexture(bitMap,Q);
