function [texStr,stimData] = motionMosaicAsynch(Q)

    % Created Mar 25 23 by RT
    % based on motionMosaicRandomUpdateExact
    
    % A reviewer suggested we should look at fast dynamics of the OMR suppression
    % which is fair because in a naturalistic environment never encounter yaw
    % that is sustained for more than a second -- rather, OMR should be functioning
    % at a subsecond timescale.
    
    % In the main result of the counterevidence project, it appears that it takes
    % about 1/2 to 1 second before turning in response to the "uniform" and "stationary" 
    % conditions diverge, making it qustionable if the OMR suppression by stationary
    % patterns relevant at a faster timescale. I think what is wrong with this
    % experiment is that the stationary pattern shows up at the same time as 
    % moving background after a uniform gray interleave, which is very unnatural.
    % In a sense, something that appears suddenly out of nowhere is not stationary.
    
    % One way to solve this is to first present foregrounds (either uniform, stationary,
    % or flickering), wait >1s, and then turn on motion (this can be now short). 
    % This is a more natural approximation of an animal suddenly expecting involuntary
    % yaw course deviation in a stationary scene, and also this will give some time
    % for stationary pattern detectors to figure out that the foreground is stationary.
    
    %% Stimulus Parameters %%  
    %% System stuffs
    p = Q.stims.currParam; % the structure containing all parameters
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number, counted from 0
    stimData = Q.stims.stimData; % used for communication between frames

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    %% basics
    duration = p.duration;
    numDeg = p.numDeg;
    sizeX = round(360/numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    fPU = p.framesPerUp;
    mlum=p.mLum;

    %% Texture related
    % spatial
    tResoDeg = p.textureResolution;  % in degrees, should be integer multiplication of numDeg
    mResoDeg = p.mosaicResolution;   % in degrees, should be integer multiplication of numDeg
    tResoPx = round(tResoDeg/numDeg);
    mResoPx = round(mResoDeg/numDeg);
    tSize = ceil([sizeY,sizeX]/tResoPx); % the size of random matrices to be generated
    mSize = ceil([sizeY,sizeX]/mResoPx); 
    
    fBG   = p.fractionBackground; % 0~1, 1 = all background (moving), 0 = all foreground
                                  % this is now exact rather than
                                  % on-average
    
    % intensity related
    cont = p.maxContrast;   % 0~1 - can be 2D if you want different contrasts for fore/backgorunds
    cS   = p.contrastSteps; % beaware of the bit depth
    
    % temporal
    dR   = p.velocities; % deg/s, 2D matrix
    fF   = p.flickerFrequency; % of foreground
    fPC  = min(60/fF*fPU,duration*2*fPU);
    onW = p.onsetWait; % wait this much before starting background motion after foreground onset (in 60Hz frame unit)
    mD = p.motionDuration; % duration of yaw rotation. If onW + mD < duration, background remain stationary before the epoch ends.
    
    % added feature
    
    if isfield(p,'contrastOffset')
        cOS = p.contrastOffset;
    else
        cOS = [0,0];
    end
    
    % If this is the first frame of the epoch,
    % create the mosaic pattern, fore/background textures
    % make matrices that are slightly larger than sizeX, sizeY and
    % crop them properly
    if f == 0
        % Background matrix (random binary checker)
        bgMatOrig = cont(end)*((randi(cS,tSize)-1)/(cS-1)*2-1);
        % Foreground matrix (random binary checker with different
        % contrasts)
        fgMatOrig = ((randi(cS,tSize)-1)/(cS-1)*2-1)*cont(1);
        
        % Window matrix (random, but the fraction exact)
        mMatOrig = reshape(randperm(mSize(1)*mSize(2)),mSize) < mSize(1)*mSize(2)*fBG;
        
        % Expand matrices
        bgMatExpanded = imresize(bgMatOrig,tResoPx,'box');
        fgMatExpanded = imresize(fgMatOrig,tResoPx,'box');
        mMatExpanded  = imresize(mMatOrig,mResoPx,'box');
        
        bgPos = [0,0]; % position of background
        
        % Trim the window matrix because it is fixed
        % Other matrices move, so they get trimmed later
        mMat = mMatExpanded(1:sizeY,1:sizeX);

        % Save to the output structure so they get communicated b/w calls
        stimData.bgMatExpanded = bgMatExpanded;
        stimData.fgMatExpanded = fgMatExpanded;
        stimData.mMat = mMat;
        stimData.bgPos = bgPos;
    else % if this is not the first call, load patterns from the memory
        bgMatExpanded = stimData.bgMatExpanded;
        fgMatExpanded = stimData.fgMatExpanded;
        mMat = stimData.mMat;
        bgPos = stimData.bgPos;
    end
      
    bitMap = zeros(sizeY,sizeX,fPU);   
    % iterate over 3 frames
    for cc = 0:1:fPU-1
        % move the background, only if it is time to do so
        % Fixed 3/31/23. onW and mD are in the unit of 60Hz frames, so
        % it should be compared with f (+ decimal counts of sub-frames)
        moving = (f+cc/fPU >= onW) && (f+cc/fPU < onW + mD);
        bgPos = bgPos + dR/60/fPU*moving;
        temp1 = circshift(bgMatExpanded,round([bgPos(2),bgPos(1)]/numDeg));
        bg = temp1(1:sizeY,1:sizeX); % trimming
        
        % update the foreground
        % the modulo calculation is done at the real 180Hz frame rate
        % because I want these things to be integer
        % fPC = 60/flickerFrequency*fPU, for 15Hz fPC shoule be 12
        % second condition is there to prevent it from recalculating
        % foreground at the first frame which is redundant
        if mod(f*fPU+cc,fPC)==0 && f+cc/fPU>0
            fgMatOrig = cont(1)*((randi(cS,tSize)-1)/(cS-1)*2-1);
            fgMatExpanded = imresize(fgMatOrig,tResoPx,'box');
            stimData.fgMatExpanded = fgMatExpanded;
        end
        fg = fgMatExpanded(1:sizeY,1:sizeX); % trimming
       
        % apply contrast offset 
        fg = fg + cOS(1);
        bg = bg + cOS(2);
        
        % Mix the two matrices
        bitMap(:,:,cc+1) = bg.*mMat+fg.*(1-mMat);
    end
    
    stimData.bgPos = bgPos;
    bitMap=mlum*(1+bitMap); % contrast to luminance conversion
    texStr.tex = CreateTexture(bitMap,Q);
end
