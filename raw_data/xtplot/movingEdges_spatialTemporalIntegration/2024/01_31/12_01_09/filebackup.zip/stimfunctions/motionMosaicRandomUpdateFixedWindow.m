function [texStr,stimData] = motionMosaicRandomUpdateFixedWindow(Q)

    % Created Feb 05 2020 by RT
    % for imaging experiments for the surround suppression / vetoing
    % project
    % fix the location of "center" (so it's no longer really a mosaic)
    % 'Background' is what I meant to be directionally moving
    % Sorry for confusing naming
    
    %% Stimulus Parameters %%  
    %% System stuffs
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    %% basics
    duration = p.duration;
    numDeg = p.numDeg;
    sizeX = round(360/numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    fPU = p.framesPerUp;
    mlum=p.mLum;
    flipWindow = p.flipWindow;

    %% Texture related
    % spatial
    tResoDeg = p.textureResolution;  % in degrees, should be integer multiplication of numDeg
    
    windowSize = p.windowSize; % in degrees
    windowX = p.windowX+sizeX/2; % in degrees
    windowY = p.windowY+sizeY/2; % in degrees
    
    
    tResoPx = round(tResoDeg/numDeg);
    tSize = ceil([sizeY,sizeX]/tResoPx); % the size of random matrices to be generated
        
    % intensity related
    cont = p.maxContrast;   % 0~1 - can be 2D if you want different contrasts for fore/backgorunds
    cS   = p.contrastSteps; % beaware of the bit depth
    
    % temporal
    dR   = p.velocities; % deg/s, 2D matrix
    fF   = p.flickerFrequency; % of foreground
    fPC  = min(60/fF*fPU,duration*2*fPU);
    
    % create the mosaic pattern, fore/background textures
    % make matrices that are slightly larger than sizeX, sizeY and
    % crop them properly
    if f == 0
        % make background matrix with checkerboard resolution
        bgMatOrig = cont(end)*((randi(cS,tSize)-1)/(cS-1)*2-1);
        % Expand it
        bgMatExpanded = imresize(bgMatOrig,tResoPx,'box');
        bgPos = [0,0]; % position of background
        % make foreground matrix with checkerboard resolution 
        fgMatOrig = ((randi(cS,tSize)-1)/(cS-1)*2-1)*cont(1);
        % expand it
        fgMatExpanded = imresize(fgMatOrig,tResoPx,'box');

        % prepare window mask
        mask = zeros(sizeY,sizeX);
        edgeL = max(round((windowX-windowSize/2)/numDeg),1);
        edgeR = min(round((windowX+windowSize/2)/numDeg),sizeX);
        edgeT = max(round((windowY-windowSize/2)/numDeg),1);
        edgeB = min(round((windowY+windowSize/2)/numDeg),sizeY);
        mask(edgeT:edgeB,edgeL:edgeR) = 1;
        if flipWindow
            mask = 1-mask;
        end
        
        % don't trim tMat here because it should be trimmed after moving it
        % save the matrix into the structure
        stimData.bgMatExpanded = bgMatExpanded;
        stimData.fgMatExpanded = fgMatExpanded;
        stimData.bgPos = bgPos;
        stimData.mask = mask;
    else
        % load matrices from the previous frame
        bgMatExpanded = stimData.bgMatExpanded;
        fgMatExpanded = stimData.fgMatExpanded;
        bgPos = stimData.bgPos;
        mask = stimData.mask;
    end
      
    bitMap = zeros(sizeY,sizeX,fPU);     
    for cc = 0:1:fPU-1
        % move the background
        bgPos = bgPos + dR/60/fPU;
        temp1 = circshift(bgMatExpanded,round([bgPos(2),bgPos(1)]/numDeg));
        bg = temp1(1:sizeY,1:sizeX); % trimming
        % update the foreground (when it is supposed to be flickerly)
        if mod(f*fPU+cc,fPC)==0 && f+cc/fPU>0
            fgMatOrig = cont(1)*((randi(cS,tSize)-1)/(cS-1)*2-1);
            fgMatExpanded = imresize(fgMatOrig,tResoPx,'box');
            stimData.fgMatExpanded = fgMatExpanded;
        end
        fg = fgMatExpanded(1:sizeY,1:sizeX); % trimming
        bitMap(:,:,cc+1) = bg.*mask+fg.*(1-mask);
    end
    stimData.bgPos = bgPos;
    bitMap=mlum*(1+bitMap); % contrast to luminance conversion
    texStr.tex = CreateTexture(bitMap,Q);
end
