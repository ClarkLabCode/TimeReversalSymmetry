function [texStr,stimData] = HarshDart(Q)
%This function creates looming circle at a position on the screen.
%first the circle remains stationaty for some time then it starts to increase in size on
%the frame specified in param file. The circle increases to a final size
%specified by the user in the param file. The rate of increase of size is
%calculated based on the duration of the epoch.



%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
%User inputs
%User inputs

numDeg = p.numDeg;
fPU = p.framesPerUp; % framesPerUp
contrast = p.contrast;
bagContrast=p.bagContrast;
mlum=p.mlum;
conincr=p.Coninc;

inicon=p.iniContrast;
fincon=p.finContrast;
delcon=fincon-inicon;


%Loom size
iR= p.initialRadius;
fR=p.finalRadius;

% %LVratio
% LV=p.LV;


%calculate velocity and initial distance
L=p.L;

% Looming velocity
v=(p.velocity/60);
 

% looming duration
 LSF = p.loomStartFrame;%loom start frame
 
 dur=(fR-iR)/v;
 LEF=LSF+dur;

 vcon=abs(delcon/dur);
  

%position on the screen
rX=p.xPosition;
rY=round(sizeY/2);


%

A=pi/20; % there are twenty wedges
 xa = linspace(-1,1,sizeX);
 ya = linspace(-1,1,sizeY);
 [X,Y] = meshgrid(xa,ya);

%--creating 20 wedges with values alternating 1's and 0's------------------
wedge1=((atan2(Y,X)<=A)+(-A<=atan2(Y,X)))-1;
wedge2=((atan2(Y,X)<=5*A)+(3*A<=atan2(Y,X)))-1;
wedge3=((atan2(Y,X)<=9*A)+(7*A<=atan2(Y,X)))-1;
wedge4=((atan2(Y,X)<=13*A)+(11*A<=atan2(Y,X)))-1;
wedge5=((atan2(Y,X)<=17*A)+(15*A<=atan2(Y,X)))-1;
wedge6=flipud(wedge1);
wedge7=rot90(wedge2,2);
wedge8=rot90(wedge3,2);
wedge9=rot90(wedge4,2);
wedge10=rot90(wedge5,2);

% summing up all the wedges to get wedge matrix
wedge=wedge1+wedge2+wedge3+wedge4+wedge5+wedge6+wedge7+wedge8+wedge9+wedge10;
wedge_2=(wedge.*-1)+1;




wedge_w=zeros(sizeY,sizeX);
wedge_b=zeros(sizeY,sizeX);
  
  
  
  
if rX==90
  wedge_w(:,1:sizeX-rX)=wedge(:,rX:sizeX-1);
  wedge_b(:,1:sizeX-rX)=wedge_2(:,rX:sizeX-1);

elseif rX==270
  wedge_w(:,rX-90:sizeX)=wedge(:,90:rX);
  wedge_b(:,rX-90:sizeX)=wedge_2(:,90:rX);
  
  elseif rX==180
  wedge_w=wedge;
  wedge_b=wedge_2;
  
end








%%
[XX,YY] = meshgrid(1:sizeX,(1:sizeY));
R=0:10:sizeX/2;

D=zeros(sizeY,sizeX,length(R));

%Circles

for i=1:length(R)
D(:,:,i) = sqrt((XX-rX).^2 + (YY-rY).^2)<=R(i);
end


%
 initstim1=(D(:,:,12)-D(:,:,11)).*logical(wedge_w)+(D(:,:,10)-D(:,:,9)).*logical(wedge_w)+(D(:,:,8)-D(:,:,7)).*logical(wedge_w)+(D(:,:,6)-D(:,:,5)).*logical(wedge_w)+...
(D(:,:,4)-D(:,:,3)).*logical(wedge_w)+(D(:,:,2)-D(:,:,1)).*logical(wedge_w) ;

 initstim2=(D(:,:,11)-D(:,:,10)).*logical(wedge_b)+(D(:,:,9)-D(:,:,8)).*logical(wedge_b)+(D(:,:,7)-D(:,:,6)).*logical(wedge_b)+(D(:,:,5)-D(:,:,4)).*logical(wedge_b)+...
(D(:,:,3)-D(:,:,2)).*logical(wedge_b) ;
 
StimData.initstim = ones(sizeY,sizeX)*bagContrast;
sumStim=(initstim1+initstim2);
sumStim(sumStim<=0)=-1;
StimData.initstim=sumStim;

%% Initializing BitMap
bitMap= zeros(sizeY,sizeX,fPU);
bitMap(:,:,:) =bagContrast;

for fr = 1:fPU
    
    if f>=LSF &&f<LEF
        t = (f-1)*fPU + fr; % index for all fPU
          radius=round(iR+(v/3)*(t-((LSF-1)*fPU)));        
          if conincr==1
              bagContrast=(inicon+(vcon/3)*(t-((LSF-1)*fPU)));
          else
              bagContrast=(inicon-(vcon/3)*(t-((LSF-1)*fPU)));
          end
              
          
          
    elseif f<LSF
        radius=iR;
         bagContrast=inicon;
    elseif f>= LEF
        radius=fR;
         bagContrast=fincon;
    end
    if radius>0
        preMap = StimData.initstim;
        [XX,YY] = meshgrid(1:sizeX,(1:sizeY));
        mask2 = sqrt((XX-rX).^2 + (YY-rY).^2)>radius;
        preMap(mask2==1) =  bagContrast;
        bitMap(:,:,fr) = preMap;
    end
       

end
bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);
end