function [texStr,stimData] = movingBar_sparse_noRandomSeed(Q)
    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework.

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %when choosing noise values for the sine wave make sure that:
    %noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
    %this insures that 3 std of the noise keeps you below a luminence of 1

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;
    stimData.flash = false;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    sizeX = round(360/p.numDeg);
    sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180)));
    

    mlum = p.lum;
    framesPerUp = p.framesPerUp;
    %stdv is a reserved parameter for future contrast controlling
    stdv = p.stdv;

    vel = p.vel/p.numDeg;% convert degree to pixel
    width = p.width/p.numDeg;
    sparsity=p.sparsity;
    
    if isfield(p, 'flashRate') %In Hz
        flashRate = p.flashRate;
    else
        flashRate = 60;
    end
    
    
    stimData.mat(1)=stdv;
    
    if f == 1
        
        % in the first frame of this epoch, initialize the sequence
        stimData.sSparse = sSparseGenerator_noRandomSeed(sparsity);

    end
    % expand the sequence to improve the moving resolution to 1 pixel
    tempMat=repmat(stimData.sSparse,width,1);
    sSparseExpanded=reshape(tempMat,[1,numel(tempMat)]);
    
    
    
    bitMap = zeros(1,sizeX,framesPerUp);
    patternTosave=zeros(1,sizeX/width+1);
%     bitMapVal = stdv*(sSparseExpanded(f*(abs(vel)/flashRate):f*(abs(vel)/flashRate)+sizeX-1));
    for cc = 1:framesPerUp
        position=ceil(abs(vel)*1/(60*framesPerUp)*(framesPerUp*(f-1)+cc));%code's refresh rate is 60Hz
        bitMapVal = stdv*(sSparseExpanded(position:position+sizeX-1));
        %Compress the stimulus pattern by merging identical digits
        if mod(position-1,width)~=0
            shift_L=mod(position-1,width);
            patternTosave(1)=bitMapVal(1);
            patternTosave(2:end-1)=bitMapVal(width-shift_L+1:width:end-shift_L);
            patternTosave(end)=bitMapVal(end);
        else
            shift_L=0;
            patternTosave(1)=0;
            patternTosave(2:end)=bitMapVal(1:width:end);
        end        
        
        if vel<0 %vel<0, left
            bitMap(1,:,cc) = bitMapVal;
            shift_L=width-shift_L;
        else %vel>0, right
            bitMap(1,end:-1:1,cc) = bitMapVal;
            %always write down the shift in the left side(0 degree), the shift
            %in the right side can be calculated by: shift_R=width-shift_L
            if shift_L~=0
                patternTosave=patternTosave(end:-1:1);
            else
                patternTosave(1)=0;
                patternTosave(2:end)=patternTosave(end:-1:2);
            end
        end        
    end

    
    %Further compress the stimulus pattern by converting it into
    %its decimal representation (because the original data is in 'ternary'->-1 0 1)
    %Since the largest number that matlab can support is only 2^53,
    %we need to split the pattern into smaller parts.
    patternTosaveTer=patternTosave+1;%convert -1 0 1 to 0 1 2(ternary)
    pattern_p1=ter2dec(patternTosaveTer(1:ceil(end/3)));
    pattern_p2=ter2dec(patternTosaveTer(ceil(end/3)+1:ceil(2*end/3)));
    pattern_p3=ter2dec(patternTosaveTer(ceil(2*end/3)+1:end));
    %Store the pattern directly
    %The stimData.mat has 34 columns: First corresponding to time stamp, second to the total frame 
    %count, third to the current epoch number, and 4th through 13th to Q.stims.stimData.cl, 14th through 
    %33rd to Q.stims.stimData.mat, and then flash state.
    stimData.mat(2)=pattern_p1;
    stimData.mat(3)=pattern_p2;
    stimData.mat(4)=pattern_p3;
    stimData.mat(5)=shift_L;
    
    %bitmap values should range from 0 to 1
    bitMap = mlum*(1 + bitMap);
    bitMap = repmat(bitMap,[sizeY,1]);
    

    
    

    %always include this line in a stim function to make the texture from the
    %bitmap 
    texStr.tex = CreateTexture(bitMap,Q);
end