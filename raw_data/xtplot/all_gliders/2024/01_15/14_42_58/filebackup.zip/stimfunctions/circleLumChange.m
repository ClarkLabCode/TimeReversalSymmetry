
function [texStr,stimData] = circleLumChange(Q)
%This function creates looming circle at a position on the screen.
%first the circle remains stationaty for some time then it starts to increase in size on
%the frame specified in param file. The circle increases to a final size
%specified by the user in the param file. The rate of increase of size is
%calculated based on the duration of the epoch.



%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
numDeg = p.numDeg;
fPU = p.framesPerUp; % framesPerUp
bagC=p.bagC;
inc=p.increase;

%
mlum=p.mlum;



%Loom size
radius= p.Radius;

%Loom C
iC= p.circC;

% looming duration

dur=p.changeDur;
v=1/dur;

LEF=dur;


%position on the screen
rX=p.xPosition;

if isfield(p, 'yPosition')
    rY=p.yPosition;
else
    rY=round(sizeY/2);
end

%% Initializing BitMap
bitMap= zeros(sizeY,sizeX,fPU);
bitMap(:,:,:) =bagC;

for fr = 1:fPU
    
    if f<LEF
        t = (f-1)*fPU + fr; % index for all fPU
        if inc==0
            L=iC-(v/3)*(t-fPU);
        else
                   L=iC+(v/3)*(t-fPU);
        end
    elseif f>= LEF
       if inc==1
           L=1;
       else
              L=-1;
       end
    end
        preMap = ones(sizeY,sizeX)*bagC;
        [XX,YY] = meshgrid(1:sizeX,(1:sizeY));
        mask = sqrt((XX-rX).^2 + (YY-rY).^2)<radius;
        preMap(mask==1) = L;
%         preMap = reshape(M,size(preMap));
        bitMap(:,:,fr) = preMap;
    end
       
bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);
end
