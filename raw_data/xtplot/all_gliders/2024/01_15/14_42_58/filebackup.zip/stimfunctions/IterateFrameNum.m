function [texStr,stimData] = IterateFrameNum(Q)
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    stimData = Q.stims.stimData;
    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    framesPerUp = p.framesPerUp;
    bitMap(4,12,framesPerUp) = 0;
    smallMap(4,6,framesPerUp) = 0;
    for ff = 1:framesPerUp
        [ii,jj] = ind2sub([4,6],ff);
        smallMap(ii,jj,ff) = 1;
    end
    bitMap(:,7:12,:) = smallMap;
    texStr.tex = CreateTexture(bitMap,Q);
end