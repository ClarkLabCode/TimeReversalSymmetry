function [texStr,stimData] = Gapcrossing(Q)
%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
% input from user

fPU = p.framesPerUp; % framesPerUp
mlum = p.mlum;


InitDistFromBot = p.InitDistFromBot;
InitTrapHeight = p.InitTrapHeight;

InitTopWidth = p.InitTopWidth;
InitBotWidth = p.InitBotWidth;

FinalBotWidth = p.FinalBotWidth;

contrast = p.contrast;
duration = p.duration;

Vel = InitDistFromBot/duration;


%% Initializing BitMap
bitMap= 0.5*ones(sizeY,sizeX,fPU);

% bitMap(DistFromBot:(DistFromBot+InitTrapHeight),((sizeX-InitBotWidth)/2):((sizeX+InitBotWidth)/2),fPU) = 0;

% At a given y, we compute x_L and x_R
% If x >= x_L and x <= x_R, bitMap = 0;
for fr = 1:fPU
    t = (f-1)*fPU + fr; % index for all fPU
    
    BotWidth = InitBotWidth + ((FinalBotWidth-InitBotWidth)/2)*((t-1)/duration);
    TopWidth = InitTopWidth + ((FinalBotWidth-InitBotWidth)/2)*((t-1)/duration);
    TrapHeight = (InitTrapHeight/(InitBotWidth-InitTopWidth))*(BotWidth-TopWidth);
    DistFromBot = InitDistFromBot - Vel*(t-1);

    % y_L - y1_L = (y2_L-y1_L)/(x2_L-x1_L) * (x_L - x1_L)
    y1_L = sizeY-DistFromBot;
    x1_L = (sizeX-BotWidth)/2;
    y2_L = sizeY-(DistFromBot+TrapHeight);
    x2_L = (sizeX-TopWidth)/2;

    % y_R - y1_R = (y2_R-y1_R)/(x2_R-x1_R) * (x_R - x1)
    y1_R = sizeY-DistFromBot;
    x1_R = (sizeX+InitBotWidth)/2;
    y2_R = sizeY-(DistFromBot+InitTrapHeight);
    x2_R = (sizeX+InitTopWidth)/2;

    for y = 1:sizeY
        x_L = (x2_L-x1_L)/(y2_L-y1_L)*(y - y1_L) + x1_L;
        x_R = (x2_R-x1_R)/(y2_R-y1_R)*(y - y1_R) + x1_R;
        if (y>=y2_L)&&(y<=y1_L)
            bitMap(y,round(x_L):round(x_R),fr) = 0;
        else
            bitMap(y,round(x_L):round(x_R),fr) = 1;
        end
    end
end
    

bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);

end

