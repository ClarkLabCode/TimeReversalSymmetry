function [texStr,stimData] = ScintillatorTernaryMirroredMovingWindows(Q)
    %There are a couple things that should be noted about your choice for flick
    %and mot. The ratio of mot to flick can never be greater than 1:2. The
    %final contrast of the stimulus is = sqrt(flicker)
    %so try to keep the contrast below 0.5 so that 2 standard deviations of the
    %mean are between max and min. put it at 0.33 for 3 standard deviations
    
    % f counts through the end of the epoch
    
    sii = Q.stims.currStimNum;
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;
    mot = p.motion;
    flick = p.flicker;
    
    % This allows for either an updateRate approach (in Hz) or an update
    % field (in frames)--the updateRate field takes precedence!
    if isfield(p, 'updateRate')
        update = (60*p.framesPerUp)/p.updateRate;
    elseif isfield(p, 'update')
        update = p.update;
    end
    
    if rem(update,1) ~= 0
        error('update is less than 1, check requrested update rate and framesPerUp');
    end
    
    delay = p.delay;
    dirX = p.dirX; %direction and amplitude of the motion
    dirY = p.dirY;
    framesPerUp = p.framesPerUp;
    if p.numDegX == 0
        sizeX = 1;
    else
        sizeX = round(360/p.numDegX);
    end
    
    if p.numDegY == 0
        sizeY = 1;
    else
        sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDegY*pi/180)));
    end
    
    phi = p.phi;
    mlum = p.lum;
    
    stimSegLength = p.stimSegLength; %size of STM window in degrees
    randSegLength = p.randSegLength; %size of rand noise window
    
    vel = p.velocity; % velocity of moving windows in degrees/s
    
    texStr.opts = 'full'; % see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % I don't really understand why these work. I get that they're serving
    % as a substitute for c, but why? I'm confused.
    A = sqrt(mot);
    B = sqrt(flick-2*mot);
    
    density = p.density;
    
    if flick-2*mot<0
        error('B is imaginary');
    end
    
    maxDelay = 0;
    checkForTwoEyes = 0;

    if f==1
        % create a matrix as large as sizeX where 1's represent STM windows and
        % 0's in places where rand windows will be
        %if Q.stims.currStimNum == 1;
            stimSize = stimSegLength/p.numDegX;
            randSize = randSegLength/p.numDegX;
            repSeg = horzcat(repmat(1,[1 stimSize]),repmat(0,[1 randSize]));
            fullSeg = repmat(repSeg,[1 ceil(sizeX/length(repSeg))]);
            stimData.permutedSeg = circshift(fullSeg,[0 floor(rand*length(repSeg))]);
            
            
        %end
    end


    
    
    if f == 1
        % in the first frame of this epoch see whether the sin wave subfields
        % exist. if they don't initialize them. If they already exist they will
        % be used in the normal loop below to be continuous between epochs
        if ~isfield(stimData,'I1') || sizeY ~= size(stimData.I1, 1) || sizeX ~= size(stimData.I1, 2)
            for ii = 1:size(Q.stims.params,2)
                
                % add 1 to max delay because to correlate at the max delay you need
                % stimData.mat(maxDelay+1)
                
                if Q.stims.params(ii).delay >= maxDelay
                    maxDelay = Q.stims.params(ii).delay + 1;
                end

        
                checkForTwoEyes = checkForTwoEyes + Q.stims.params(ii).twoEyes;
            end
            
            % creates a matrix that's all 1's or -1's
            stimData.noiseMat = 2*round(rand(sizeY,sizeX))-1;
            % creates a matrix that's 1's wherever the rand<density
            maskNoise = rand(sizeY,sizeX)<density;
            % multiplies the two, so you have noise values in some entries
            % and others just zeros
            stimData.noiseMat = stimData.noiseMat.*maskNoise;
            
            stimData.I1 = 2*round(rand(sizeY,sizeX,maxDelay))-1;
            % create a matrix tht's 1's wherever the rand<density
            maskMat = rand(sizeY,sizeX,maxDelay)<density;

            
            stimData.I1 = stimData.I1.*maskMat;
            % creates a zeros matrix of same dimension
            stimData.corrMat = zeros(size(stimData.I1));
        end
    end

    %%%%% note this stimulus is designed so that the first correlation occurs
    %%%%% on the first timepoint of a new epoch, but this does NOT work if
    %%%%% there is an updateL difference between the two epochs

    bitMap = zeros(sizeY,sizeX,framesPerUp);
    hzFrame = f*framesPerUp-(framesPerUp-1):f*framesPerUp;
    % creates an array of (0 0 0 ... 1) where the one's tell you to update
    updateFrame = mod(hzFrame-1,update) == 0;

    if f == 1 && ~isfield(stimData,'offSetRaw');
        stimData.offSetRaw = 0;
    end
    
    % calculate the density of incoherent correlations: i.e. if dx=1,dt=1,
    % window size = 1, and vel=1, then every pair of pixels in the window
    % has a correlation, whereas when vel = -1, no pixels in the window can
    % have correlations
    
    if f == 1 && (dirX*vel)>0;
        stimSize = stimSegLength/p.numDegX;
        randSize = randSegLength/p.numDegX;
        stimData.densityOffSetRaw = 0;
        numUpdates = 0;
        stimData.densityOffSet = 0;
        % find how many updates it takes to move a pixel
        
        while stimData.densityOffSet == 0
            stimData.densityOffSetRaw = stimData.densityOffSetRaw + (-vel)*(1/60)*(1/framesPerUp)*update*(1/p.numDegX);
            stimData.densityOffSet = floor(stimData.densityOffSetRaw);
            numUpdates = numUpdates +1;
        end
        
        % to deal with rounding errors with floor
        % numUpdates = numUpdates - 1;
        
        stimData.densityOffSetRaw = stimData.densityOffSetRaw + (-vel)*(1/60)*(1/framesPerUp)*update*(1/p.numDegX);
        % number of pixels it does move when it finally moves
        sizeOfMove = floor(stimData.densityOffSetRaw);
        
        % reset everything
        stimData.densityOffSetRaw = 0;
        stimData.densityOffSet = 0;

        % create a (3*numUpdates, stimSegLength + 2*offset) matrix that contains
        % essentially three iterations of the window as it moves
        densityMapRow = horzcat(repmat(0,[1 2*abs(sizeOfMove)]),repmat(1,[1 stimSize]));
        densityMap = zeros(3*numUpdates,size(densityMapRow,2));
        
        for yy=1:(3*numUpdates)
            stimData.densityOffSetRaw = stimData.densityOffSetRaw + (-vel)*(1/60)*(1/framesPerUp)*update*(1/p.numDegX);
            stimData.densityOffSet = floor(stimData.densityOffSetRaw);
            densityMap(yy,:) = circshift(densityMapRow,[0 stimData.densityOffSet]);
        end
        
        shiftedDensityMap = densityMap;

        shiftedDensityMap((3*numUpdates-delay+1):(3*numUpdates),:) = 0;
        shiftedDensityMap(:,(size(densityMap,2)-dirX+1):size(densityMap,2)) = 0;
        
        shiftedDensityMap = circshift(shiftedDensityMap, [delay dirX]);
        corrsMatrix = densityMap.*shiftedDensityMap;
        
        corrs = sum(sum(corrsMatrix));
        totalPixels = sum(sum(densityMap))-stimSize;
        
        stimData.density = corrs/totalPixels;
        
    end
    

    stimData.replaceMat = zeros(sizeY,sizeX);

    
    
    for cc = 1:framesPerUp
        if updateFrame(cc)
            % create a new matrix at front and shift all the left eye
            % matricies back one. Keep all right eye matricies untouched.
            % Appened a new white noise left eye matrix to the end and keep
            % the white noise right eye matrix
            newMat = 2*round(rand(sizeY,sizeX))-1;
            maskMat = rand(sizeY,sizeX)<density;
            newMat = newMat.*maskMat;
            stimData.I1 = cat(3,newMat,stimData.I1(:,:,1:end-1));
            
            stimData.noiseMat = 2*round(rand(sizeY,sizeX))-1;
            maskNoise = rand(sizeY,sizeX)<density;
            stimData.noiseMat = stimData.noiseMat.*maskNoise;
            
            if delay == 0 && dirX == 0 && dirY == 0;
                stimData.corrMat = 2*round(rand(sizeY,sizeX))-1;
            else
                stimData.corrMat = phi*circshift(stimData.I1(:,:,delay+1),[dirY,dirX]);
            end
            
            for yy = 1:sizeY
                for xx = 1:sizeX
                    rand1 = datasample([-1 0 0 1],1);
                    stimData.randMat1(yy,xx) = rand1;
                    %stimData.randMat2(yy,xx) = rand2;
                end
            end
            
            

            % circshift windowMatrix to make the windows move with velocity v
            shiftedMatrices(1, size(stimData.permutedSeg,2)) = 0;

            % stimData.offSetRaw is an integrator that continually
            % increases, stimData.offset floors offSetRaw to get the number
            % of pixels the window needs to shift per bitMap update
            stimData.offSetRaw = stimData.offSetRaw + vel*(1/60)*(1/framesPerUp)*update*(1/p.numDegX);
            stimData.offSet = floor(stimData.offSetRaw);

            shiftedMatrices(:,:) = circshift(stimData.permutedSeg,[0 stimData.offSet]);
            stimData.windowMatrix = shiftedMatrices(:,1:sizeX,:);
            stimData.windowMatrix = repmat(stimData.windowMatrix,sizeY,1);
            
            % get corrWindows, which is STM pixels in the STM windows and 0
            % elsewhere, and randWindows, which is random ternary noise in
            % random windows and 0 elsewhere.
            stimData.corrWindows(:,:) = stimData.corrMat.*stimData.windowMatrix;
            stimData.rand1Windows(:,:) = stimData.randMat1.*(-stimData.windowMatrix+1);
%            stimData.rand2Windows(:,:) = stimData.randMat1.*(-stimData.windowMatrix+1);           
            

%            stimData.updateBitMap(:,:,cc) = A*stimData.I1(:,:,1)+A*(stimData.corrMat.*stimData.windowMatrix(:,:) + stimData.randMat.*abs(stimData.windowMatrix(:,:)-1))+B*stimData.noiseMat;
            stimData.updateBitMap(:,:,cc) = (A*stimData.I1(:,:,1)+A*stimData.corrMat+B*stimData.noiseMat).*stimData.windowMatrix + stimData.rand1Windows; %(A*stimData.rand1Windows+A*stimData.rand2Windows);


            % (dirX*vel)>0 is the coherent case, in which density needs to
            % be reduced to be equal to the density of the incoherent case
            % has to be within the update loop so that it won't create
            % updates at incorrect rates
            if (dirX*vel)>0
                stimData.maskMat = rand(sizeY,sizeX) < (stimData.density)^0.5;
                for yy = 1:sizeY
                    for xx = 1:sizeX
                        if stimData.maskMat(yy,xx) == 0
                            randReplace = datasample([-1 0 0 1],1);
                            stimData.replaceMat(yy,xx) = randReplace;
                        end
                    end
                end
            end
            
            
                        
        end
        


       
        % using sindowMatrix to alternate between normal STM and windows of
        % rand noise, which is achieved by making the central term 
        % it's basically a matrix of booleans where 1 = STM and 0 = rand,
        % so doint this should result in dealing with stimData.corrMat when
        % STM, and randMat when random noise
        % note: the abs thing: basically, when windowMatrix = 1, I want
        % corrMat = corrMat and randMat = 0. When windowMatrix = 0, I want
        % corrMat = 0 and randMat = randMat, so when windowMatrix = 0
        % abs(windowMatrix-1) = 1 but windowMatrix = 0
        % the outer product is for testing purposes only


%        bitMap(:,:,cc) = stimData.updateBitMap;
%        bitMap(:,:,cc) = (A*stimData.I1(:,:,1)+A*(stimData.corrMat.*stimData.windowMatrix(:,:) + stimData.randMat.*abs(stimData.windowMatrix(:,:)-1))+B*stimData.noiseMat).*(-stimData.windowMatrix+1);
%       bitMap(:,:,cc) = stimData.windowMatrix(:,:);

        

%        bitMap(:,:,cc) = A*stimData.I1(:,:,1)+A*(stimData.corrMat.*stimData.windowMatrix(:,:) + stimData.randMat.*abs(stimData.windowMatrix(:,:)-1))+B*stimData.noiseMat;
%        bitMapOld(:,:,cc) = A*stimData.I1(:,:,1)+A*(stimData.corrWindows + stimData.rand1Windows)+B*stimData.noiseMat;

%         bitMap(:,:,cc) = (A*stimData.I1(:,:,1)+A*stimData.corrMat+B*stimData.noiseMat).*stimData.windowMatrix + stimData.rand1Windows; %(A*stimData.rand1Windows+A*stimData.rand2Windows);
        
        % OLD RUN LINE, WITH DENSITY CORRECTION
         %bitMap(:,:,cc) = stimData.updateBitMap(:,:,1);
         
        % in incoherent case, make sure maskMat is all 1's 
        if (dirX*vel)<= 0 
            stimData.maskMat = ones(sizeY,sizeX);
        end
        
        bitMap(:,:,cc) = ( (A*stimData.I1(:,:,1)+A*stimData.corrMat+B*stimData.noiseMat).*stimData.windowMatrix + stimData.rand1Windows ).*stimData.maskMat + stimData.replaceMat;
        
%         if updateFrame(cc)
%             % (dirX*vel)>0 is the coherent case, in which density needs to
%             % be reduced to be equal to the density of the incoherent case
%             % has to be within the update loop so that it won't create
%             % updates at incorrect rates
%             if (dirX*vel)>0
%                 maskMat = rand(sizeY,sizeX) < (stimData.density)^0.5;
%                 for yy = 1:sizeY
%                     for xx = 1:sizeX
%                         if maskMat(yy,xx) == 0
%                             randReplace = datasample([-1 0 0 1],1);
%                             updatebitMap(yy,xx,cc) = randReplace;
%                         end
%                     end
%                 end
%             end
%         end
%         
%         bitMap = updatebitMap

        
    end
    
    bitMap = mlum*(bitMap+1);

    if p.twoEyes
        rightEye = fliplr(bitMap);
        
        bitMap = CombEyes(bitMap,rightEye,p,f);
    end

    %always include this line in a stim function to make the texture from the
    %bitmap
    texStr.tex = CreateTexture(bitMap,Q);
end