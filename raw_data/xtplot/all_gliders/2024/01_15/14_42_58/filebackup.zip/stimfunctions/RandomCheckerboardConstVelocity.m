function [texStr,stimData] = RandomCheckerboardConstVelocity(Q)
    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %when choosing noise values for the sine wave make sure that:
    %noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
    %this insures that 3 std of the noise keeps you below a luminence of 1

    
% 1 = 180
% 2 = 90
% 3 = 60

% (or change frames per up, multiples of 3)
% 
% if frames per up = 6
%     (360 / update rate)

    sii = Q.stims.currStimNum;
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;
    %floc = Q.flyloc; % could potentially use this to update the stimulus as well
    
    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    sizeX = round(360/p.numDeg);
    sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180)));
    
    framesPerUp = p.framesPerUp;
    
    if f==1 %initialize the mosaic pattern
        % the color in 5*5 square should be the same, but the moving
        % resolution is 1 degree
        % contract = 2*lumi-1

        rng(1); %let the random number keep the same each time!

        init_stim = randi([0,1],round(sizeY/5),round(sizeX/5)); %2D
        init_stim = init_stim*p.contrast+0.5*(1-p.contrast);
        
        init_stim = imresize(init_stim,5,"nearest");
        bitMap = repmat(init_stim,[1,1,framesPerUp]); %3D
        
        stimData.init_stim = init_stim;
        stimData.theta = 0; %record continuous value of turning angle (unit:n_pixel)
        
    else
        bitMap = repmat(stimData.init_stim,[1,1,framesPerUp]); %allocate the storage space first to speed up!
        
        %In each frame, the velocity is constant
        %v=E(|x|)=sqrt(2/pi)*p.sigma, x~Gauss(0,sigma)
        
        %New version v: eliminate high frequency noise
        v=sqrt(2/pi)*p.sigma;
        
        %change unit
        v_pixel=v/(p.numDeg*60);%unit:n_pixel/frame

        stimData.mat(1)=v;
        
        for kk=1:3 % loop through RGB to allow small movement in each subframe
            stimData.theta = stimData.theta + v_pixel*1/3;% each subframe here is 1/3 of the duration of the full frame
            stimData.mat(kk+1)=stimData.theta;
            bitMap(:,:,kk)=circshift(stimData.init_stim,round(stimData.theta),2);
        end
    end

    %always include this line in a stim function to make the texture from the bitmap
    texStr.tex = CreateTexture(bitMap,Q);
end