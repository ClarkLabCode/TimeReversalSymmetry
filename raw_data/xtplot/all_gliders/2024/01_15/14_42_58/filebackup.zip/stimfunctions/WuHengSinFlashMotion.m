
function [texStr,stimData] = WuHengSinFlashMotion(Q)

%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
% input from user
duration = p.duration;  % Duration of epoch in frames
t3 = p.t3;  % Number of frames of sin motion
t2 = p.t2;  % Number of frames of white/black/gray covering sin
t1 = p.t1; 	% Number of frames of each sin wave
c1 = p.c1; % Constract of sin waves
c2 = p.c2;  % -1 = black, 0 = gray, 1 = white
c3 = p.c3;
fPU = p.framesPerUp;
mlum = p.mlum;
sinLambda = p.sinLambda*pi/180;  
velocity = p.velocity*pi/180;
x = 0:2*pi/(sizeX-1):2*pi;
 
if f >= duration-t3+1
    bitMap = c3*repmat((sin(2*pi*(x-velocity*(f-(duration-t3)+1)/60)/sinLambda)),sizeY,1,fPU);
elseif f >= duration-(t2 + t3)+1
    bitMap = c2*ones(sizeY,sizeX,fPU);
elseif f >= duration-(t1 + t2 + t3)+1
    bitMap = c1*repmat((sin(2*pi*x/sinLambda)),sizeY,1,fPU);
else
    bitMap = 0*ones(sizeY,sizeX,fPU); 
end

bitMap = mlum*(1 + bitMap); % converts contrast to luminance

%always include this line in a stim function to make the texture from the
%bitmap

texStr.tex = CreateTexture(bitMap,Q);


