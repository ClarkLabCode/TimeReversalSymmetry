function [texStr,stimData] = HowFastYouAreGoing(Q)

    % Created Mar 30 2019

    % This function tests flies' reading comprehension and their adherence
    % to traffic rules
    
    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment


    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;
    
    numDeg = p.numDeg;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    % 9/14 using numDeg = 1 - maybe go high reso?
    sizeX = round(360/p.numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    
    %% Input parameters
    
    %% closed loop stuff
    [flyTurningSpeed,flyWalkingSpeed,stimData] = GetFlyResponse(Q.timing.framenumber,Q.stims.duration,Q.flyTimeline.curFlyStates,stimData);
    leadFly = stimData.cl(1);
    
    %% things that concern the entire presentation
    
    fPU = p.framesPerUp;
    duration = p.duration; % frames
    mLum = p.mLum;
    
    %% Draw the bitmap

    RGB = insertText(zeros(sizeY,sizeX),[sizeX/2 sizeY/2],flyTurningSpeed(leadFly),'FontSize',24,'AnchorPoint','center');
    bitMap = repmat(RGB(:,:,1),[1,1,fPU]);
      
    bitMap =  mLum * ( 1 + bitMap );
    
    texStr.tex = CreateTexture(bitMap,Q);
end
