function [texStr,stimData] = HabituationConstantLoom(Q)
%This function creates looming circle at a position on the screen.
%first the circle remains stationaty for some time then it starts to increase in size on
%the frame specified in param file. The circle increases to a final size
%specified by the user in the param file. The rate of increase of size is
%calculated based on the duration of the epoch.



%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
%User inputs
%User inputs

numDeg = p.numDeg;
fPU = p.framesPerUp; % framesPerUp
contrast = p.contrast;
bagContrast=p.bagContrast;
duration = p.duration; % change to include the repetitions
mlum=p.mlum;
rep = p.repetitions; % how many times we want to show the loom

randContra=0;
IntervalStatic = p.IntervalStatic; ; % period where the loom stays
IntervalGray = p.IntervalGray; % period where the screen is gray



v=(p.velocity/60);

%Loom size
iR= p.initialRadius;
fR=p.finalRadius;


Ldur=(fR-iR)/v;

TotalInterval = IntervalStatic*2 + IntervalGray;


% looming duration
LSF = (TotalInterval + 1) -IntervalStatic ; %loom start frame
LEF = LSF + Ldur; % loom end frame

All_LSF = [LSF]; % all the starting frames

for rept = 1:rep
    if rept >1
        All_LSF = [All_LSF, LSF+Ldur+TotalInterval];
        LSF = LSF+Ldur+TotalInterval;
    end
end

All_LEF = All_LSF + Ldur;



%position on the screen
rX=p.xPosition;
rY=round(sizeY/2);




%% Initializing BitMap
bitMap= zeros(sizeY,sizeX,fPU);
bitMap(:,:,:) =bagContrast;
if f == 1
    stimData.which_rep = 1; % which repetition are we're in
end
for fr = 1:fPU
    
    if f >= All_LEF(stimData.which_rep) + IntervalStatic
        stimData.which_rep = stimData.which_rep + 1;
    end
    
    LSF = All_LSF(stimData.which_rep);
    LEF = All_LEF(stimData.which_rep);
    
    if  f < LSF -IntervalStatic
        radius=0; % Gray screen again
        bitMap(:,:,:) =bagContrast;
    elseif f>= (LSF -IntervalStatic)  && f<LSF
        radius=iR; % Loom stays in the screen (small)
    elseif f>=LSF &&f<LEF
        t = (f-1)*fPU + fr; % index for all fPU
        %         d=dInitial-(v/3)*(t-((LSF-1)*fPU));
        %         radius=atand(L/d);
        radius=round(iR+(v/3)*(t-((LSF-1)*fPU)));
        %
    elseif f>= LEF &&f<LEF + IntervalStatic
        radius=fR; % Loom stays in the screen (big)
    end
    if radius>0
        preMap = ones(sizeY,sizeX)*bagContrast;
        [XX,YY] = meshgrid(1:sizeX,(1:sizeY));
        mask = sqrt((XX-rX).^2 + (YY-rY).^2)<radius; % where in the screen to draw the circle
        if randContra==0
            preMap(mask==1) = contrast;
        else
            M = ones(sizeY,sizeX)*bagContrast;
            B = reshape(mask,[numel(mask),1]);
            for i=1:length(B)
                if B(i)==1
                    M(i)= (rand(1)>0.5);
                end
            end
            %         [row,col]=size(preMap);
            preMap = reshape(M,size(preMap));
        end
        bitMap(:,:,fr) = preMap;
    end
end

bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);


end