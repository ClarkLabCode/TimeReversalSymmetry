function [texStr,stimData] = CheckerCirclesRegularSurroundFlash(Q)

    % Created 05/10/19 by RT
    % Present translating checkerboard with an arbitrary resolution within
    % circular apertures, while presenting full filed flashes outside
    
 
    %% Stimulus Parameters %%  
    %% System stuffs
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    %% basics
    duration = p.duration;
    numDeg = p.numDeg;
    sizeX = round(360/numDeg);
    sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(numDeg*pi/180))); % tile 1 deg pixel at 0 elevation
    fPU = p.framesPerUp;
    mlum=p.mLum;

    %% Texture related
    % checker
    resoDeg = p.textureResolution;  % reso of the checker in degrees, should be integer multiplication of numDeg
    resoPx = round(resoDeg/numDeg); % in px
    tSize = ceil([sizeY,sizeX]/resoPx); % the size of random matrices to be generated
    tCont = p.textureContrast;   % contrast of the checker
    vel = p.velocity; % velocity of checker in deg/s
    
    % aperture (hard-edged)
    aRad = p.apertureRadius;
    aSpa = p.apertureSpacing;
    if aSpa*2 < aRad
        error('Aperture spacing must be larger than the diameter of the aperture');
    end
    
    % full field flash
    fCont  = p.flashContrast;  % -1 ~ 1
    fFreq  = p.flashFrequency; % in Hz
    fPhase = p.flashPhase;     % in degree (0~360)
    % transform frequency into cycle (in 60Hz frame unit)
    fPC = 60/fFreq;
    fPhase = fPC*fPhase/360;
    
    
    % Initialize checker and aperture
    % make matrices that are slightly larger than sizeX, sizeY and
    % crop them properly
    if f == 0
        tMatOrig = tCont*(randi(2,tSize)-1.5)*2;
        tMatExpanded = imresize(tMatOrig,resoPx,'box');
        bgPos = 0; % position of background
        
        % don't trim tMat here because it should be trimmed after moving it
        stimData.tMatExpanded = tMatExpanded;
        stimData.bgPos = bgPos;
        
        % make a small, single aperture
        [X,Y] = meshgrid(1:round(aSpa/numDeg));
        R = sqrt((X - round(aSpa/numDeg)/2).^2 + (Y - round(aSpa/numDeg)/2).^2);
        aBlock = R<aRad;
        
        % stack it to cover the entire screen, randomize phase, trim, save
        aStack = repmat(aBlock,[ceil(sizeY/round(aSpa/numDeg)),ceil(sizeX/round(aSpa/numDeg))]);
        aStack = circshift(aStack,[randi(sizeY),randi(sizeX)]);
        aperture = aStack(1:sizeY,1:sizeX);
        stimData.aperture = aperture;
        
        
        
    else
        tMatExpanded = stimData.tMatExpanded;
        bgPos = stimData.bgPos;
        aperture = stimData.aperture;
    end
    
    bitMap = zeros(sizeY,sizeX,fPU);     
    
    for cc = 1:fPU
        % move the background
        bgPos = bgPos + vel/60/fPU;
        temp1 = circshift(tMatExpanded,round(bgPos/numDeg),2); % horizontal translation
        bg = temp1(1:sizeY,1:sizeX); % trimming
        
        % flicker the foreground
        isOn = mod(f+cc/fPU+fPhase,fPC)<=fPC/2;
        
        bitMap(:,:,cc) = bg.*aperture + (1-aperture)*isOn*fCont;
    end
    stimData.bgPos = bgPos;
    bitMap=mlum*(1+bitMap); % contrast to luminance conversion
    texStr.tex = CreateTexture(bitMap,Q);
end