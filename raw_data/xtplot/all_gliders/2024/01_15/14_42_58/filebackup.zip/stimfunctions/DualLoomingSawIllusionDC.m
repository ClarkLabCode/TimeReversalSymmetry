
function [texStr,stimData] = DualLoomingSawIllusionDC(Q)

%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
% input from user
numDeg = p.numDeg;
fPU = p.framesPerUp; % framesPerUp
mlum = p.mlum;
isincrease = p.isincrease;
background = p.background; % 0, gray, -1 black, 1 white
loomStartFrame = p.loomStartFrame;

%% Define parameters
P=p.period; %period in s
T=P*60; %Convertit to frames
del=1/T; %Offset Increament in each frame

%% Define Piecewise Linear Functions

    fun1 = @(x) (x == 0).*(-1)+(0 < x).*(-1+2*x);

    fun2 = @(x) (x == 0).*(1)+(0 < x).*(1-2*x);

%duration = p.duration;
r = p.radius;
sync= p.sync;
fPU = p.framesPerUp; % framesPerUp

if ~isfield(p,'GridSize')
    n=5;
else
    n = p.GridSize; % degree/s into rad/s
end

ledge=p.xcoordinate-n*r;
redge=p.xcoordinate+n*r;
upedge=-n*r;
doedge=+n*r;

a =[ledge+r:2*(r):redge-r];% p.xcoordinate;
b =[upedge+r:2*(r):doedge-r];%p.ycoordinate;

if p.xcoordinate==90
a1=a+180;
elseif p.xcoordinate==270
    a1=a-180;
end
    



[A1,B] = meshgrid(a,b);
[A2,B]=meshgrid(a1,b);

%
cR = Q.cylinder.cylinderRadius;
cH = Q.cylinder.cylinderHeight;

[X,YY] = meshgrid(1:sizeX,(1:sizeY)-sizeY/2);
Y =  atand(YY*cH/sizeY/cR); % positive angle is down


%% Create offsets
if f==1
offset = (randperm(numel(A1))-1)/(numel(A1)-1);
offset = offset + 1E-10*(~offset);
offset = offset - 1E-10*(offset == 1);
%% Create Maps
circ1 =zeros(sizeY, sizeX);
circ2=zeros(sizeY, sizeX);
for i_circ = 1:numel(A1)
    circ1 =    circ1 + offset(i_circ)*((X-A1(i_circ)).^2 /(r*r)+ ((Y-B(i_circ)).^2)/(r*r) < 1);
end

for i_circ = 1:numel(A2)
    circ2 =    circ2 + offset(i_circ)*((X-A2(i_circ)).^2 /(r*r)+ ((Y-B(i_circ)).^2)/(r*r) < 1);
end

stimData.circ_mask1 = (circ1 ~= 0);
stimData.circ_mask2 = (circ2 ~= 0);

% circ(~stimData.circ_mask)=background;
stimData.LinearMap1 =reshape(circ1,[sizeX*sizeY,1]);
stimData.LinearMap2 =reshape(circ2,[sizeX*sizeY,1]);

patt1=fun1(stimData.LinearMap1);
patt2=fun2(stimData.LinearMap2);

circ1=reshape(patt1,[sizeY,sizeX]);
circ1(~stimData.circ_mask1)=background;
circ2=reshape(patt2,[sizeY,sizeX]);
circ2(~stimData.circ_mask2)=background;

circ=circ1+circ2;

stimData.premap=circ;



end

bitMap= zeros(sizeY,sizeX,fPU);

for fr = 1:fPU
if f >= loomStartFrame
    stimData.LinearMap1=mod(stimData.LinearMap1+(del/fPU),1);
    patt1=fun1(stimData.LinearMap1);
    circ1=reshape(patt1,[sizeY,sizeX]);
    circ1(~(stimData.circ_mask1))=0;
   
     stimData.LinearMap2=mod(stimData.LinearMap2+(del/fPU),1);
    patt2=fun2(stimData.LinearMap2);
    circ2=reshape(patt2,[sizeY,sizeX]);
    circ2(~(stimData.circ_mask2))=0;
    
    circ=circ1+circ2;
    circ(~(stimData.circ_mask2+stimData.circ_mask1))=background;
    stimData.premap=circ;
    
end

bitMap(:,:,fr) = stimData.premap;

end
%always include this line in a stim function to make the texture from the
%bitmap
bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);


end