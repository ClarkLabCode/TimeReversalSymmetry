function [texStr,stimData] = LoomAndBar(Q)

%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
% input from user

numDeg = p.numDeg;
fPU = p.framesPerUp; % framesPerUp
mlum = p.mlum;
targVel = p.targVel;
bar_offset = p.barOffset;
bar_width = p.barWidth;
contrast = p.contrast;
duration = p.duration; % Important! the duration will determine the amplitude, until where the bar will move
laterality = p.laterality; % -1, the bar moves to the left, +1 the bar moves to the right
% so if the vel is 180 deg/60f, you use this info to calculate how many
% seconds you want for that amplitude.
% x(duration) = 60*amplitude / vel

%Loom size
iR= p.initialRadius;
fR=p.finalRadius;

% Looming velocity
v=(p.velocity/60);
% looming duration
 LSF = p.loomStartFrame;%loom start frame
 
 dur=(fR-iR)/v;
 LEF=LSF+dur;

%position on the screen
rX=p.xPosition;
rY=round(sizeY/2);

%% Initializing BitMap
bar_pos = [];

if laterality == -1
    bar_pos = [bar_pos, bar_offset - [0:(bar_width-1)]];
elseif laterality == 1
    bar_pos = [bar_pos, bar_offset + [0:(bar_width-1)]];
elseif laterality == 2
    bar_pos1 = [bar_pos, bar_offset - [0:(bar_width-1)]];
    bar_pos2 = [bar_pos, bar_offset+240 + [0:(bar_width-1)]];
    elseif laterality == -2
    bar_pos1 = [bar_pos, bar_offset - [0:(bar_width-1)]];
    bar_pos2 = [bar_pos, bar_offset+240 + [0:(bar_width-1)]];
end

deg_per_fpu = (1 /(60*fPU)*(targVel)); % degrees moved per fPU in deg

incrementPerFpu = (1:deg_per_fpu:(duration-(LEF+60)+1)*fPU);

bitMap= zeros(sizeY,sizeX,fPU);

for fr = 1:fPU
    
    if f>=LEF+60
        radius=0;
        idx = (f-(60+LEF))*fPU + [1:fPU]; % index for all fPU
        if laterality == -1
            vector_pos = bar_pos - round(incrementPerFpu(idx(fr)));
        elseif laterality == 1
            vector_pos = bar_pos + round(incrementPerFpu(idx(fr)));
        elseif laterality ==2
            vector_pos1 = bar_pos1 + round(incrementPerFpu(idx(fr)));
            vector_pos2=  bar_pos2 - round(incrementPerFpu(idx(fr)));
            vector_pos=[vector_pos1,vector_pos2];
        elseif laterality ==-2
            vector_pos1 = bar_pos1 + round(incrementPerFpu(idx(fr)));
            vector_pos2=  bar_pos2 - round(incrementPerFpu(idx(fr)));
            vector_pos=[vector_pos1,vector_pos2];
        end
        
        
        
        bitMap(:, vector_pos, fr) = contrast;
    end
    
    if f>=LSF &&f<LEF
        t = (f-1)*fPU + fr; % index for all fPU
        radius=round(iR+(v/3)*(t-((LSF-1)*fPU)));
    elseif f<LSF
        radius=iR;
    elseif f>= LEF&&f<LEF+60
        radius=0;
        
    end
    if radius>0
        preMap = zeros(sizeY,sizeX);
        [XX,YY] = meshgrid(1:sizeX,(1:sizeY));
        mask = sqrt((XX-rX).^2 + (YY-rY).^2)<radius;
        preMap(mask==1) = contrast;
        
        bitMap(:,:,fr) = preMap;
    end
    
end
bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);

end