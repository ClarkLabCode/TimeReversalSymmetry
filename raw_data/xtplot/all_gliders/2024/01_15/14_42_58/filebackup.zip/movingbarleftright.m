function [texStr,stimData] = movingbarleftright(Q)
%% Parameters

% p is the struct that stores all the stimulus parameters from paramfiles
% You can access Stimulus.XXX parameter in paramfiles as p.XXX
p = Q.stims.currParam;

% f indicates how manieth update this is in this epoch
f = Q.timing.framenumber - Q.timing.framelastchange + 1;

% Q.stim.stimData is used to communicate between multiple calls of this
% function
stimData = Q.stims.stimData;

% These determine how output of this function is interpreted
% (Usually you don't need to change this)
texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% Defining the size of the bitMap
% numDeg = degree / pixel
sizeX = round(360/p.numDeg); % in pix
sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDeg*pi/180))); % in pix

%%
% input from user

numDeg = p.numDeg;
fPU = p.framesPerUp; % framesPerUp
mlum = p.mlum;
targVel = p.targVel;
bar_offset = p.barOffset;
bar_width = p.barWidth;
contrast = p.contrast;
duration = p.duration; % Important! the duration will determine the amplitude, until where the bar will move
laterality = p.laterality; % -1, the bar moves to the left, +1 the bar moves to the right

% so if the vel is 180 deg/60f, you use this info to calculate how many
% seconds you want for that amplitude.
% x(duration) = 60*amplitude / vel

%% Initializing BitMap
bar_pos = [];

if laterality == -1
    bar_pos = [bar_pos, bar_offset - [0:(bar_width-1)]];
elseif laterality == 1
    bar_pos = [bar_pos, bar_offset + [0:(bar_width-1)]];
end

deg_per_fpu = ((1 /(60*fPU))*(targVel)); % degrees moved per fPU in deg

incrementPerFpu = (1:deg_per_fpu:duration*fPU);

bitMap= zeros(sizeY,sizeX,fPU);


for fr = 1:fPU

    idx = (f-1)*fPU + [1:fPU]; % index for all fPU
    if laterality == -1
    vector_pos = bar_pos - round(incrementPerFpu(idx(fr)));
    else
    vector_pos = bar_pos + round(incrementPerFpu(idx(fr)));
    end
    
    bitMap(:, vector_pos, fr) = contrast;
end
bitMap =  mlum * ( 1 + bitMap );
texStr.tex = CreateTexture(bitMap,Q);

end

