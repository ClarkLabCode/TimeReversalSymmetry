function [texStr,stimData] = scrambledSineWaveWPhase(Q)
    % basic sinewave stimulus. Can produce rotation and translation where
    % the opposite eye is the first eye's mirror image

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;

    if p.numDeg == 0
        sizeX = 1;
    else
        sizeX = round(360/p.numDeg);
    end

    mlum = p.lum;
    c = p.contrast;
    
    tf = p.temporalFrequency;
    barOrder = p.barOrder;
    framesPerUp = p.framesPerUp;
    
    barWidth = p.numDeg;
    phaseOffset = p.phaseOffset*pi/180;

    %% closed loop stuff
    if isfield(p,'CLType')
        [flyTurningSpeed,flyWalkingSpeed,stimData] = GetFlyResponse(Q.timing.framenumber,Q.stims.duration,Q.flyTimeline.curFlyStates,stimData);
        SineWaveClosedLoop;
    end
    
    %% left eye
    %stimData.mat(1) is used as the wave phase. stimData.mat(2) is the velocity which
    %is constant unless noise is added
    
    if isfield(Q.stims.params(end),'nextEpoch')
        interleaveEpoch = Q.stims.params(end).nextEpoch;
    else
        interleaveEpoch = 1;
    end
    
    if f == 1
        if ~isfield(stimData,'sinPhaseScramPhase')
            stimData.sinPhaseScramPhase = 0;
            
            phaseOptions = [0 pi phaseOffset pi+phaseOffset];
            if isempty(barOrder) % random
                stimData.startPhase = datasample(phaseOptions,sizeX);
            else
                numBars = length(barOrder);
                repeatedSegment = phaseOptions(barOrder);
                fullWidthSeg = repmat(repeatedSegment,[1 ceil(sizeX/numBars)]);
                permutedSeg = circshift(fullWidthSeg,[1 floor(numBars*rand)]);
                stimData.startPhase = permutedSeg(1:sizeX);
            end
        elseif Q.stims.currStimNum == interleaveEpoch
            % stimData.cutPhase = floor(2*(segmentSize+blankSize)*rand);
            
            phaseOptions = [0 pi phaseOffset pi+phaseOffset];
            if isempty(barOrder) % random
                stimData.startPhase = datasample(phaseOptions,sizeX);
            else
                numBars = length(barOrder);
                repeatedSegment = phaseOptions(barOrder);
                fullWidthSeg = repmat(repeatedSegment,[1 ceil(sizeX/numBars)]);
                permutedSeg = circshift(fullWidthSeg,[1 floor(numBars*rand)]);
                stimData.startPhase = permutedSeg(1:sizeX);
            end
        end
        % make a matrix which describes the randomly alloted beginning phase of
        % each bar: each bar can begin either at 0, pi, or phaseOffset
        %% option 1: datasample
        %% option 2: randperm
%         phaseOptions = [0 pi phaseOffset pi+phaseOffset];
%         phaseMatrix = [repmat(phaseOptions,1,floor(sizeX/4)) phaseOptions(1,1:(sizeX-4*floor(sizeX/4)))];
%         stimData.startPhase = phaseMatrix(1,randperm(size(phaseMatrix,2)));
    end

    %theta = (0:sizeX-1)/sizeX*2*pi; %theta in radians
    bitMap = zeros(1,sizeX,framesPerUp);
    
    for cc = 1:framesPerUp
        stimData.sinPhaseScramPhase = stimData.sinPhaseScramPhase + 2*pi*tf/(60*framesPerUp);

        bitMap(1,:,cc) = c*sin(-stimData.startPhase-stimData.sinPhaseScramPhase);

        stimData.mat(cc) = stimData.sinPhaseScramPhase;
    end

    bitMap = mlum*(1 + bitMap);

    %% right eye
    if p.twoEyes
        rightEye = fliplr(bitMap);
        
        bitMap = CombEyes(bitMap,rightEye,p,f);
    end
    
    stopoint = 5;
    
    % update lastStimNum
    Q.stims.lastStimNum = Q.stims.currStimNum;
    
    %always include this line in a stim function to make the texture from the
    %bitmap

    texStr.tex = CreateTexture(bitMap,Q);
end