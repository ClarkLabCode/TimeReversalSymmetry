function [texStr,stimData] = scrambledSineWaveArbPhase(Q)
    % creates bars that oscillate at a fixed temporal frequency, whose
    % phases can be offset by any desired value. Entering a phase value of
    % 999 will result in an unchanging grey bar
    % NOTE: unlike scrambledSineWaveWPhase, here a phase offset shifts a
    % bar FORWARD in time, as now bitMap(1,xx,cc) =
    % c*sin(-stimData.startPhase(1,xx) . . . whereas before 
    % bitMap(1,:,cc) = c*sin(stimData.startPhase . . . 

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;

    if p.numDeg == 0
        sizeX = 1;
    else
        sizeX = round(360/p.numDeg);
    end

    mlum = p.lum;
    c = p.contrast;
    
    tf = p.temporalFrequency;

    framesPerUp = p.framesPerUp;
    
    barWidth = p.numDeg;
    
    randOrder = p.randOrder;
    
    barPhases = p.barPhases*pi/180;

    %% closed loop stuff
    if isfield(p,'CLType')
        [flyTurningSpeed,flyWalkingSpeed,stimData] = GetFlyResponse(Q.timing.framenumber,Q.stims.duration,Q.flyTimeline.curFlyStates,stimData);
        SineWaveClosedLoop;
    end
    
    %% left eye
    %stimData.mat(1) is used as the wave phase. stimData.mat(2) is the velocity which
    %is constant unless noise is added
    
    if isfield(Q.stims.params(end),'nextEpoch')
        interleaveEpoch = Q.stims.params(end).nextEpoch;
    else
        interleaveEpoch = 1;
    end
    
    if f == 1
        if ~isfield(stimData,'sinPhaseScramPhase')
            stimData.sinPhaseScramPhase = 0;         
            if randOrder % random
                % make a matrix which describes the beginning phase of
                % each bar: randomly allot phases from the input matrix
                % barPhases
                stimData.startPhase = datasample(barPhases,sizeX);
            else
                % otherwise, tile barPhases accross the x-axis until the
                % screen is full
                numBars = length(barPhases);
                repeatedSegment = barPhases;
                fullWidthSeg = repmat(repeatedSegment,[1 ceil(sizeX/numBars)]);
                permutedSeg = circshift(fullWidthSeg,[1 floor(numBars*rand)]);
                stimData.startPhase = permutedSeg(1:sizeX);
            end
        elseif Q.stims.currStimNum == interleaveEpoch
            if randOrder % random
                stimData.startPhase = datasample(barPhases,sizeX);
            else
                numBars = length(barPhases);
                repeatedSegment = barPhases;
                fullWidthSeg = repmat(repeatedSegment,[1 ceil(sizeX/numBars)]);
                permutedSeg = circshift(fullWidthSeg,[1 floor(numBars*rand)]);
                stimData.startPhase = permutedSeg(1:sizeX);                
                
%                 numBars = length(barPhases);
%                 stimData.circShiftPhase = floor(numBars*rand);
%                 permutedSeg = circshift(fullWidthSeg,[1 stimData.circShiftPhase]);
%                 stimData.startPhase = permutedSeg(1:sizeX);
            end
        end
    end
    
%     numBars = length(barPhases);
%     repeatedSegment = barPhases;
%     fullWidthSeg = repmat(repeatedSegment,[1 ceil(sizeX/numBars)]);
%     permutedSeg = circshift(fullWidthSeg,[1 stimData.circShiftPhase]);
%     stimData.startPhase = permutedSeg(1:sizeX);
                
    bitMap = zeros(1,sizeX,framesPerUp);
    
    for cc = 1:framesPerUp
        stimData.sinPhaseScramPhase = stimData.sinPhaseScramPhase + 2*pi*tf/(60*framesPerUp);
        for xx = 1:sizeX
            if stimData.startPhase(1,xx) == 999*pi/180
                bitMap(1,xx,cc) = 0;
            else
                bitMap(1,xx,cc) = c*sin(-stimData.startPhase(1,xx)-stimData.sinPhaseScramPhase);
            end
        end
            
        stimData.mat(cc) = stimData.sinPhaseScramPhase;
    end

    bitMap = mlum*(1 + bitMap);

    %% right eye
    if p.twoEyes
        rightEye = fliplr(bitMap);
        
        bitMap = CombEyes(bitMap,rightEye,p,f);
    end

    %always include this line in a stim function to make the texture from the
    %bitmap

    texStr.tex = CreateTexture(bitMap,Q);
end