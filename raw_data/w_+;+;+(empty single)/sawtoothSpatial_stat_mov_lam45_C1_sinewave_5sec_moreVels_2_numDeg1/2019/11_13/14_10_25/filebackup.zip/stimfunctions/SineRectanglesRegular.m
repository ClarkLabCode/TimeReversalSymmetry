function [texStr,stimData] = SineRectanglesRegular(Q)

    % Created 10/09/18 by RT
    
    %% Parameters %%
    %% Basics
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;

    if p.numXDeg == 0
        sizeX = 1;
    else
        sizeX = round(360/p.numXDeg);
    end
    
    % Here we are setting the pixel just in front of a fly to be numXDeg by
    % numYDeg (which is different from what RT usually do)
    if p.numYDeg == 0
        sizeY = 1;
    else
        sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numYDeg*pi/180)));
    end
    
    boxDims = [p.boxWidth/p.numXDeg,p.boxHeight/p.numYDeg];
    boxDims(isnan(boxDims)) = 1;

    mlum = p.lum;
    
    %% Spatiotemporal paramters
    cA = p.contrastA;
    cB = p.contrastB;
    
    gridDist = round(p.gridDist/p.numXDeg);
    
    if ~isfield(p,'temporalFrequencyA')
        velA = p.velocityA*pi/180; % degree/s into rad/s
        velB = p.velocityB*pi/180; % degree/s into rad/s
    else
        velA = p.temporalFrequencyA*p.lambdaA*pi/180;
        velB = p.temporalFrequencyB*p.lambdaB*pi/180;
    end
    
    
    if ~isfield(p,'changeEveryEpoch')
        changeEveryEpoch = 0;
    else
        changeEveryEpoch = p.changeEveryEpoch;
    end  
        
    if ~isfield(p,'twoInFrame')
        twoInFrame = 0;
    else
        twoInFrame = p.twoInFrame;
    end 
            
    lambdaA = p.lambdaA*pi/180; %wavelength in radians
    lambdaB = p.lambdaB*pi/180;
    framesPerUp = p.framesPerUp;
    
    psiA = p.psiA*pi/180; % vertical angle to rad/s
    psiB = p.psiB*pi/180;

    %% left eye
    %stimData.mat(1) is used as the wave phase. stimData.mat(2) is the velocity which
    %is constant unless noise is added

    if f == 1 && ~isfield(stimData,'sinPhaseA')
        stimData.sinPhaseA = rand*2*pi;
        stimData.sinPhaseB = rand*2*pi;
    end
    
    thetaX = (0:sizeX-1)/sizeX*2*pi; %thetaX in radians
    % fraction of cylinder height to cylinder circumference
    circToHeight = Q.cylinder.cylinderHeight/(2*Q.cylinder.cylinderRadius*pi);
    
    % Note: the way this is written currently can cause up to 25? distortion
    %       in thetaY (the vis. angle of actual upper limit of the screen =
    %       53?, while sizeY/2 = 76?).
    %       This shouldn't matter too much since this stimulus is for
    %       behavior and we are not looking at individual cell responses
    thetaY = (0:sizeY-1)/sizeY*2*pi*circToHeight; %thetaY in radians
    [thetaXMat,thetaYMat] = meshgrid(thetaX,thetaY);
    
    thetaCombA = cos(-psiA)*thetaXMat+sin(-psiA)*thetaYMat;
    thetaCombB = cos(-psiB)*thetaXMat+sin(-psiB)*thetaYMat;
    
    bitMap(sizeY,sizeX,framesPerUp) = 0;

    if (~isfield(stimData,'stimWeights')||(changeEveryEpoch&&f==1)) 
        % Calling an outside function (should be in stimfucntion folder)
        [mask] = MultiMaskMakerRegularRectangles([sizeY, sizeX],gridDist,boxDims);
        mask = repmat(mask,[1, 1, framesPerUp]);
        stimData.stimWeights = mask; 
    else
        mask = stimData.stimWeights;
    end
    % Masks made with MultiMaskMaker have very small but nonzero values at
    % background, which result in non-zero backgorund motion
    mask(mask<0.01) = 0;
    
    for cc = 1:framesPerUp
            stimData.sinPhaseA = stimData.sinPhaseA + velA/(60*framesPerUp);
            stimData.sinPhaseB = stimData.sinPhaseB + velB/(60*framesPerUp);

            bitMapA(:,:,cc) = cA*sin(2*pi*(thetaCombA-stimData.sinPhaseA)/lambdaA);
            bitMapB(:,:,cc) = cB*sin(2*pi*(thetaCombB-stimData.sinPhaseB)/lambdaB);

            stimData.mat(cc) = stimData.sinPhaseA;
            stimData.mat(cc+framesPerUp) = stimData.sinPhaseB;
    end


    if ~isnan(bitMapA+bitMapB)
        if ~twoInFrame
            bitMap = bitMapA.*mask + bitMapB.*(1-mask);    
        else
            bitMap = bitMapA.*mask + (bitMapB+bitMapA).*(1-mask);  
        end
    end
    bitMap = mlum*(1 + bitMap);

    %% right eye
    if p.twoEyes
        rightEye = fliplr(bitMap);
        
        bitMap = CombEyes(bitMap,rightEye,p,f);
    end

    %always include this line in a stim function to make the texture from the
    %bitmap
    texStr.tex = CreateTexture(bitMap,Q);
end