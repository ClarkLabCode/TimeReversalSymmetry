function [texStr,stimData] = VisOptSineWaveMirroredKineticsMeasurement(Q)
% basic sinewave stimulus. Can produce rotation and translation where
% the opposite eye is the first eye's mirror image

p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
stimData = Q.stims.stimData;

if p.numDeg == 0
    sizeX = 1;
else
    sizeX = round(360/p.numDeg);
end

mlum = p.lum;
c = p.contrast;

vel = p.temporalFrequency*p.lambda*pi/180;
lambda = p.lambda*pi/180; %wavelength in radians


framesPerUp = p.framesPerUp;


epochDuration       = p.duration;
interleaveDuration = p.interleaveDuration;
stimulusDuration    = p.stimulusDuration;
subepochDuration    = interleaveDuration + stimulusDuration;

subepochNumber = ceil(f/subepochDuration); % starts from 1
isStimulus     = (f - (subepochNumber-1)*subepochDuration) > interleaveDuration;

%% left eye
%stimData.mat(1) is used as the wave phase. stimData.mat(2) is the velocity which
%is constant unless noise is added

if f == 1
    stimData.sinPhase = 0;
end

if mod(f,subepochDuration) == 1
    polarity = 3 - 2*randi(2);
    stimData.polarity = polarity;
else
    polarity = stimData.polarity;
end

theta = (0:sizeX-1)/sizeX*2*pi; %theta in radians
bitMap(1,sizeX,framesPerUp) = 0;

if isStimulus
    for cc = 1:framesPerUp

        stimData.sinPhase = stimData.sinPhase + vel*polarity/(60*framesPerUp);

        bitMap(1,:,cc) = c*sin(2*pi*(theta-stimData.sinPhase)/lambda);

        stimData.mat(cc) = stimData.sinPhase;
        stimData.mat(6) = Q.timing.framenumber;
        stimData.mat(5) = p.temporalFrequency;
        stimData.mat(4) = c;
        stimData.mat(7) = lambda;
    end
end
stimData.mat(8)  = subepochNumber;
stimData.mat(9)  = isStimulus;
stimData.mat(10) = polarity;
stimData.mat(11) = p.optoIntensity;


bitMap = mlum*(1 + bitMap);

%% right eye
if p.twoEyes
    rightEye = fliplr(bitMap);
    
    bitMap = CombEyes(bitMap,rightEye,p,f);
end

%% Optogenetics
backSize = ceil(45/p.numDeg);
bitMap(1,1:backSize,:) = p.optoIntensity;
bitMap(1,sizeX-backSize+1:sizeX,:) = p.optoIntensity;

%always include this line in a stim function to make the texture from the
%bitmap

texStr.tex = CreateTexture(bitMap,Q);
end