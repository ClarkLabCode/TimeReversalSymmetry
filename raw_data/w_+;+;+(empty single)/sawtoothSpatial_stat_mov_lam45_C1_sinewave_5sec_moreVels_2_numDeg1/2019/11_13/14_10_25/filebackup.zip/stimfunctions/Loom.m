function [texStr,stimData] = Loom(Q)
    params = Q.stims.currParam;
    updateNum = Q.timing.framenumber - Q.timing.framelastchange + 1; %number of frame changes since start of epoch
    stimData = Q.stims.stimData;
    
    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.
    
    centerPosXDeg = params.centerPosXDeg;
    centerPosYDeg = params.centerPosYDeg;
    initPosRDeg = params.initPosRDeg;
    velMsPerRadius = params.velMsPerRadius;
    bilateral = params.bilateral;
    
    groundLum = params.groundLum;
    figureLum = params.figureLum;
    
    % Object will be a circle of radius 1
    % Calculate object size and speed in "world" coordinates
    velZ = 1000/velMsPerRadius;
    initPosZ = 1/tand(initPosRDeg);
    
    if params.numDeg == 0
        sizeX = 1;
        sizeY = 1;
    else
        sizeX = round(360/params.numDeg);
        sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tand(params.numDeg)));
    end
    
    totalYDeg = sizeY*params.numDeg;
    
    framesPerUpdate = params.framesPerUp;
    thetaX = repmat(360*(0:sizeX-1)/sizeX,[sizeY 1]); %theta in degrees
    thetaY = repmat(linspace(-totalYDeg/2,totalYDeg/2,sizeY)',[1 sizeX]);
    distMap = sqrt((thetaX-centerPosXDeg).^2 + (thetaY - centerPosYDeg).^2);
    bitmap = zeros(sizeY,sizeX,framesPerUpdate);
    
    
    for f = 1:framesPerUpdate
        t =(updateNum-1)*(1/60) + f*(1/60)*(1/framesPerUpdate);
        % Loop between init and end z locations
        zPos = mod(initPosZ - velZ*t,initPosZ);
        rDeg = atand(1/zPos);
        bitmap(:,:,f) = groundLum + (figureLum-groundLum)*(distMap < rDeg);
    end
    
    if bilateral % Copy the left hand image to the right hand side (mirrored) 
        leftEnd = floor(sizeX/2);
        bitmap(:,(end+1-leftEnd):end,:) = fliplr(bitmap(:,1:leftEnd,:));
    end
    texStr.tex = CreateTexture(bitmap,Q);
end