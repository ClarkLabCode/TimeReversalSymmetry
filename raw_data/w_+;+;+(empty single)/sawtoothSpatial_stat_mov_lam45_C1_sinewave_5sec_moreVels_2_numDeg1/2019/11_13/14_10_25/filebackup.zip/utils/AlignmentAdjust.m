function viewLocs = AlignmentAdjust(viewLocs, viewLocsPath)

% to be called each loop, checks for keyboard inputs appropriately to move
% view locations around appropriately

%% this top line works on mac, bottom on PC
% [pressBOOL,dum,keyList]=PsychHID('KbCheck'); % check this once
[~,~,keyArray]=KbCheck; % check this once
keyList = KbName(keyArray);

numKeys = {'1!','2@','3#','4$','5%'};
arrowKeys = {'LeftArrow','RightArrow','UpArrow','DownArrow'};
selectorKeys = {'q','w'};

viewLocs = Q.OGL.viewLocs;

if any(strcmp(keyList,'s'))
    % cd somewhere, then save this
    dlmwrite(viewLocsPath,viewLocs,',');
    disp('Saving viewlocs file! Strong work.');
    return
end

if isempty(keyList) || ...
   isempty(intersect(keyList,numKeys)) || ...
   isempty(intersect(keyList,arrowKeys)) || ...
   isempty(intersect(keyList,selectorKeys)) % not all required keys selected
    return;
end


% which window?
[~,~,viewChoose] = intersect(keyList,numKeys);

% move how?
moveDirMat = [-1  0;...
               1  0;...
               0  1;...
               0 -1;];
           
[~,~,dirIdxs] = intersect(keyList,arrowKeys);
moveHow = sum(moveDirMat(dirIdxs,:),1);

% do the damn move
if any(strcmp(keyList,'q'))
    viewLocs(viewChoose,[1 2]) = viewLocs(viewChoose,[1 2]) + moveHow;
else
    viewLocs(viewChoose,[3 4]) = viewLocs(viewChoose,[3 4]) + moveHow;
end

