leadFly = stimData.cl(1);

switch p.CLType
    case 0
        % do nothing
    case 1
        % sine wave velocity is closed loop with turning speed
        vel = -ClosedLoopLinearGain(flyTurningSpeed(leadFly),p.gain,p.offset)*pi/180;

        stimData.cl(2) = vel;
    case 2
        % sine wave velocity is closed loop with walking speed
        vel = -ClosedLoopLinearGain(flyWalkingSpeed(leadFly),p.gain,p.offset)*pi/180;

        stimData.cl(2) = vel;
    otherwise
        % do nothing
end