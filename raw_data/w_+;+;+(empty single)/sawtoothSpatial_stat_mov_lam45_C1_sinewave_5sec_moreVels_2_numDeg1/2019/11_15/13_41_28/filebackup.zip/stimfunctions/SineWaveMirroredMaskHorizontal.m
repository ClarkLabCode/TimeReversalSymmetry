function [texStr,stimData] = SineWaveMirroredMaskHorizontal(Q)
    % basic sinewave stimulus. Can produce rotation and translation where
    % the opposite eye is the first eye's mirror image

    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
    stimData = Q.stims.stimData;
    
    if p.numDegX == 0
        sizeX = 1;
    else
        sizeX = round(360/p.numDegX);
    end
    
    if p.numDegY == 0
        sizeY = 1;
    else
        sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tan(p.numDegY*pi/180)));
    end

    mlum = p.lum;
    c = p.contrast;
    
    if ~isfield(p,'temporalFrequency')
        vel = p.velocity*pi/180; % degree/s into rad/s
    else
        vel = p.temporalFrequency*p.lambda*pi/180;
    end
    
    lambda = p.lambda*pi/180; %wavelength in radians
    framesPerUp = p.framesPerUp;
    % convert stimSize from degrees to indicies
    
    % CHANGE SEGMENT SIZE TO Y DIMENSION
    segmentSize = round(p.segmentSize/p.numDegY);
    % DITTO FOR BLANK
    blankSize = (p.blankSize/p.numDegY);
    reverseSeg = p.reverseSeg;
    balance = p.balance;
    randWindowPhase = p.randWindowPhase;
    windowPhase = p.windowPhase;

    %% left eye
    %stimData.mat(1) is used as the wave phase. stimData.mat(2) is the velocity which
    %is constant unless noise is added
    
    if isfield(Q.stims.params(end),'nextEpoch')
        interleaveEpoch = Q.stims.params(end).nextEpoch;
    else
        interleaveEpoch = 1;
    end
    
    if f == 1
        % if no recorded sinPhase (i.e. beginning epoch w/this file) create
        % a random phase
        if ~isfield(stimData,'sinPhase')
            stimData.sinPhase = 2*pi*rand;
            % gives you a number between 0 and size(repeatedSegment)
            % the number used to randomly shift windows between epochs
            stimData.cutPhase = floor(2*(segmentSize+blankSize)*rand);
        elseif Q.stims.currStimNum == interleaveEpoch
            stimData.cutPhase = floor(2*(segmentSize+blankSize)*rand);
        end
    end
    
    % thetax should wrap around the whole circumference--done
    thetaX = (0:sizeX)/sizeX*2*pi; %thetaX in radians
    % fraction of cylinder height to cylinder circumference
    circToHeight = Q.cylinder.cylinderHeight/(2*Q.cylinder.cylinderRadius*pi);
    % thetaY = (0:sizeY-1)/sizeY*2*pi*circToHeight; %thetaY in radians
    
    blankSeg = zeros(1,blankSize);
    % DIMENSION SHOULD BE CHANGED FROM 1 TO SIZEY
    bitMap(sizeY,sizeX,framesPerUp) = 0;

    for cc = 1:framesPerUp
        stimData.sinPhase = stimData.sinPhase + vel/(60*framesPerUp);
        
        stimSegSingle = c*sin(2*pi*(thetaX-stimData.sinPhase)/lambda);
        stimSeg = repmat(stimSegSingle,segmentSize,1);
        
        reverseStimSeg = stimSeg;
        
        % to reverse direction
        if reverseSeg
            reverseStimSeg = fliplr(reverseStimSeg);
        end
            
        % to invert contrast
        if balance
            reverseStimSeg = -reverseStimSeg;
        end
        
        % full sequence of stim/blank pattern MUST BE CHANGED TO SOMEHOW BE
        % VERTICAL?-transpose in place
        repeatedSegment = vertcat(stimSeg,blankSeg,reverseStimSeg,blankSeg);
        
        % randomly shift the whole sequence, to guarantee that
        % windows appear in different positions every eopch
        % MUST BE CHANGED TO SHIFT IN DIFFERENT
        % DIMENSION--done
        if randWindowPhase
            shiftedRepeatedSegment = circshift(repeatedSegment,[stimData.cutPhase 1]);
        else
            shiftedRepeatedSegment = circshift(repeatedSegment,[windowPhase 1]);
        end
        
        % number of times the pattern will fit on the screen MUST BE
        % CHANGED TO REPRESENT NUM TIMES FITS ON Y DIMENSION--done
        numRepeats = ceil(sizeY/(2*(segmentSize+blankSize)));
        
        % tile the sequence accross the x dimension YOU'LL HAVE TO DO THIS
        % ACCROSS Y--done
        initialBitMap = repmat(shiftedRepeatedSegment,[numRepeats 1]);

        % grab all the elements that will fit in sizeX YOU'LL HAVE TO
        % CHANGE TO GRABBING IN SIZE Y--no: change to match the number of Y
        % divisions
        sizeYsizedChunk = (size(initialBitMap,1)/2-floor(0.5*sizeY)):(size(initialBitMap,1)/2+ceil(0.5*sizeY)-1);
        bitMap(:,:,cc) = initialBitMap(sizeYsizedChunk,1:sizeX);
        
        % write to output
        stimData.mat(cc) = stimData.sinPhase;
    end

    bitMap = mlum*(1 + bitMap);

    %% right eye
    if p.twoEyes
        rightEye = fliplr(bitMap);
        
        bitMap = CombEyes(bitMap,rightEye,p,f);
    end

    %always include this line in a stim function to make the texture from the
    %bitmap

    texStr.tex = CreateTexture(bitMap,Q);
end