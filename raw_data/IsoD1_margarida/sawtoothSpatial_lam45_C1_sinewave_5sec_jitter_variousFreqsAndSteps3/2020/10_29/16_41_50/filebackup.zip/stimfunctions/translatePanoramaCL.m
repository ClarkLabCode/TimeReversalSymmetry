function [texStr,stimData] = translatePanoramaCL(Q)

    params = Q.stims.currParam;
    updateNum = Q.timing.framenumber - Q.timing.framelastchange + 1; %number of frame changes since start of epoch
    stimData = Q.stims.stimData;
    
    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.
    
    setLuminance = 0;
    if isfield(params,'newMeanLuminance')
        newMeanLuminance = params.newMeanLuminance;
        setLuminance = 1;
    else
        if isfield(params,'meanLuminanceAdjust')
            meanLuminanceAdjust = params.meanLuminanceAdjust;
        else
            meanLuminanceAdjust = 0;
        end
    end
            
    
    contrastAdjust = params.contrastAdjust;
    
    folderPath = params.folderPath;
    imgNum = params.imgNum;
    
    framesPerUpdate = params.framesPerUp;
    
    if ~isfield(stimData,'pos')
        stimData.pos = 0;
    end
    
    if isfield(params,'resetPos') && params.resetPos && updateNum == 1
        stimData.pos = 0;
    end
    
    if isfield(params,'leadFly') && params.leadFly ~= 0
        leadFly = params.leadFly;
    else
        leadFly =  mod(floor(Q.timing.framenumber/(Q.stims.duration/5)),5)+1;
    end
    
    if isfield(params,'gain')
        gain = params.gain;
    else
        gain = 1;
    end
    velocity = -Q.flyTimeline.curFlyStates.vtheta(leadFly)*gain;
    if isnan(velocity)
        velocity = 0;
    end
    
    
    if ~isfield(stimData,['img' num2str(imgNum)])
        files = dir(folderPath);
        fileNames = {files.name};
        numStr = num2str(imgNum,'%04i');
        fileNum = find(strncmp(numStr,fileNames,4));
        load(fullfile(folderPath,fileNames{fileNum}))
        stimData.(['img' num2str(imgNum)]) = projection/max(projection(:));
    end
    
    projection = stimData.(['img' num2str(imgNum)]);
    
    imgMean = mean(projection(:));
    imgContrasts = (projection-imgMean)/imgMean;
    
    if setLuminance
        newMean = newMeanLuminance;
    else
        newMean = imgMean + meanLuminanceAdjust;
    end
    
    img = uint8(255*(imgContrasts*contrastAdjust + 1)*newMean);

    [sizeY,sizeX] = size(img);
    bitmap(sizeY,sizeX,framesPerUpdate) = uint8(0);
    
    dt = (1/60)*(1/framesPerUpdate);
    for f = 1:framesPerUpdate
        stimData.pos = stimData.pos + velocity*dt*(sizeX/360);
        shift = round(mod(stimData.pos,sizeX));
        bitmap(:,:,f) = circshift(img,shift,2);
    end
    stimData.mat(1) = stimData.pos;
    stimData.mat(2) = velocity;
    stimData.mat(3) = leadFly;
    stimData.cl(1) = leadFly;
    stimData.cl(2) = stimData.pos;
    stimData.cl(3) = velocity;
    
    texStr.tex = CreateTexture(bitmap,Q);
end