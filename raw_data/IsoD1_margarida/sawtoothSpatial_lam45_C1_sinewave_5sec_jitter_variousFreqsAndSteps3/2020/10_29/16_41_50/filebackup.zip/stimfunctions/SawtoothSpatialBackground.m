function [texStr,stimData] = SawtoothSpatialBackground(Q)
% Created 26 Jul 2019 by RT
% Show a horizontal strip of stationary sawtooth contrast gradient over a
% background with various contrast. Designed to probe the background
% dependence of peripheral drift like illusion in flies. See Faubert &
% Herbert (1991) for the corresponding human illusion.

% this is to provide the general structure for the texture generating codes
% to be used with PTB in this framework.

% NOTE: when you create a new stimulus function, you must update the
% stimlookup table in the folder paramfiles. paramfiles will also hold the
% text file giving lists of parameters that comprise an experiment

%% PREPARE PARAMETERS

p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
stimData = Q.stims.stimData;

texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

% basic parameters
numDeg = p.numDeg;
sizeX = round(360/p.numDeg);
sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
fPU = p.framesPerUp; 
mlum = p.mlum;

% define sawtooth gradients
lambda   = p.lambda;   % distance between ramps in degrees
contrast = p.contrast; % contrast of sawtooth
sH       = p.stripHeight; % height of the sawtooth strip in degrees
                          % The strip is vertically centered
bC = p.backgroundContrast; % from -1 to 1


%% Draw Stimulus

% initialize phase of the stimulus
if f == 1
  stimData.windowLoc = rand*lambda;
end

bitMap = ones(sizeY,sizeX,fPU)*bC;
x = linspace(1,360,sizeX)+stimData.windowLoc;
sawtooth = contrast*(mod(x,lambda)*2/lambda-1);

topEdge = max(round(sizeY/2-sH/2),1);
botEdge = min(round(sizeY/2+sH/2),sizeY);

bitMap(topEdge:botEdge,:,:) = repmat(sawtooth,[botEdge-topEdge+1,1,fPU]);

bitMap=mlum*(1+bitMap); % contrast to luminance conversion

%always include this line in a stim function to make the texture from the
%bitmap

texStr.tex = CreateTexture(bitMap,Q);
end
