function [flyTurningSpeed,flyWalkingSpeed,stimData] = GetFlyResponse(framenumber,duration,curFlyStates,stimData)
    % this line chooses which fly is in control of the other flies. 1/5 of
    % the way through it switches from fly 1 to fly 2 and so on
    stimData.cl(1) = mod(floor(framenumber/(duration/5)),5)+1;
    
    flyTurningSpeed = curFlyStates.vtheta.*(~isnan(curFlyStates.vtheta));
    flyWalkingSpeed = curFlyStates.vforward.*(~isnan(curFlyStates.vforward));
    
    flyTurningSpeed(isnan(flyTurningSpeed)) = 0;
    flyWalkingSpeed(isnan(flyWalkingSpeed)) = 0;
end