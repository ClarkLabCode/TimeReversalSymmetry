function [texStr,stimData] = VisOptSineWaveMirroredInterleaveIncluded(Q)
% Interleaves are now included in each epoch so that ON/OFF of optogenetic
% stimulation during the interleave can be manipulated in trial-by-trial
% fashion

% basic sinewave stimulus. Can produce rotation and translation where
% the opposite eye is the first eye's mirror image

p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
stimData = Q.stims.stimData;

if p.numDeg == 0
    sizeX = 1;
else
    sizeX = round(360/p.numDeg);
end

mlum = p.lum;
c = p.contrast;

vel = p.temporalFrequency*p.lambda*pi/180;
lambda = p.lambda*pi/180; %wavelength in radians
ILduration = p.interleaveDuration; % in 1/60s unit
framesPerUp = p.framesPerUp;


%% left eye
%stimData.mat(1) is used as the wave phase. stimData.mat(2) is the velocity which
%is constant unless noise is added

if f == 1
    stimData.sinPhase = 0;
end


theta = (0:sizeX-1)/sizeX*2*pi; %theta in radians
bitMap(1,sizeX,framesPerUp) = 0;

for cc = 1:framesPerUp
    
    stimData.sinPhase = stimData.sinPhase + vel/(60*framesPerUp);

    if (cc/framesPerUp + f) < ILduration
        bitMap(1,:,cc) = 0;
    else
        bitMap(1,:,cc) = c*sin(2*pi*(theta-stimData.sinPhase)/lambda);
    end
    
    
    stimData.mat(cc) = stimData.sinPhase;
    stimData.mat(6) = Q.timing.framenumber;
    stimData.mat(5) = p.temporalFrequency;
    stimData.mat(4) = c;
    stimData.mat(7) = lambda;
end

bitMap = mlum*(1 + bitMap);

%% right eye
if p.twoEyes
    rightEye = fliplr(bitMap);
    bitMap = CombEyes(bitMap,rightEye,p,f);
end

%% Optogenetics
backSize = ceil(45/p.numDeg);
bitMap(1,1:backSize,:) = p.optoIntensity;
bitMap(1,sizeX-backSize+1:sizeX,:) = p.optoIntensity;

%always include this line in a stim function to make the texture from the
%bitmap

texStr.tex = CreateTexture(bitMap,Q);
end