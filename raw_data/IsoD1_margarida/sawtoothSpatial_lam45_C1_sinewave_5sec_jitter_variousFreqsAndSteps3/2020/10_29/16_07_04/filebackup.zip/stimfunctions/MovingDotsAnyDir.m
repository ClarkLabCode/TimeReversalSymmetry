function [texStr,stimData] = MovingDotsAnyDir(Q)
    params = Q.stims.currParam;
    updateNum = Q.timing.framenumber - Q.timing.framelastchange + 1; %number of frame changes since start of epoch
    stimData = Q.stims.stimData;
    
    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.
    
    angleDeg = params.angleDeg;
    velocityDeg = params.velocityDeg; %All angles calculated to be the same size as the center of the image
    
    backgroundLum = params.backgroundLum;
    dotLum = params.dotLum;
    
    dotRadius = params.dotWidthDeg/2;
    dotDensity = params.dotDensity;
    dotLifetimeMs = params.dotLifetimeMs; % negative means infinite

    numDeg = params.numDeg;
    
    if numDeg == 0
        sizeX = 1;
        sizeY = 1;
    else
        sizeX = round(360/numDeg);
        sizeY = round(Q.cylinder.cylinderHeight/(Q.cylinder.cylinderRadius*tand(numDeg)));
    end
    
    densityPerDot = pi*((dotRadius/numDeg)^2)/(sizeX*sizeY);
    numDots = round(dotDensity/densityPerDot);
    
    % dotLocs is a matrix of size numDots x 3 with the columns being
    % centerPixelX, centerPixelY, lifetimeSeconds
    
    if updateNum == 1
        dotLocs = [sizeX*rand(numDots,1),sizeY*rand(numDots,1),zeros(numDots,1)];
    else
        dotLocs = stimData.dotLocs;
    end
    
    framesPerUpdate = params.framesPerUp;
    timePerFrame = (1/60)/framesPerUpdate;
    
    bitmap(sizeY,sizeX,framesPerUpdate) = 0;
    
    for ff = 1:framesPerUpdate
        % Regenerate dots as necessary
        dotsPastLifetime = (dotLocs(:,3) > dotLifetimeMs/1000) & (dotLifetimeMs >= 0); % Only count if dotLifetime ~= -1
        numDotsPastLifetime = sum(dotsPastLifetime);
        dotLocs(dotsPastLifetime,:) = [sizeX*rand(numDotsPastLifetime,1),sizeY*rand(numDotsPastLifetime,1),zeros(numDotsPastLifetime,1)];
        
        thisFrame = backgroundLum*ones(sizeY,sizeX,framesPerUpdate);
        rgb = insertShape(thisFrame,'FilledCircle',[dotLocs(:,1:2),(dotRadius/numDeg)*ones(numDots,1)],'color',[dotLum,0,0],'SmoothEdges',true);
        bitmap(:,:,ff) = rgb(:,:,1);
        
        addVec = [velocityDeg*cosd(angleDeg)/numDeg,-velocityDeg*sind(angleDeg)/numDeg,1]*timePerFrame;
        dotLocs = dotLocs + repmat(addVec,[numDots,1]);
        dotLocs(:,1:2) = [mod(dotLocs(:,1),sizeX),mod(dotLocs(:,2),sizeY)]; 
    end
    stimData.dotLocs = dotLocs;
texStr.tex = CreateTexture(bitmap,Q);
        