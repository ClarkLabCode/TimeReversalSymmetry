function [texStr,stimData] = motionMosaicRandomUpdateMovingWindow(Q)

    % Created Mr 13 2018 by RT
    % for behavioral experiments for the surround suppression / divisive
    % normalization project
    % In this function, the window into the background moves along the
    % checkerboard, allowing  the true impression of self-motion
    
    % Added mirroring feature Mar 2 2020 by RT
    % shouldn't affect previously created stimulus
    
    % this is to provide the general structure for the texture generating codes
    % to be used with PTB in this framework. 

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %% Stimulus Parameters %%  
    %% System stuffs
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    %% basics
    duration = p.duration;
    numDeg = p.numDeg;
    sizeX = round(360/numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    fPU = p.framesPerUp;
    mlum=p.mLum;

    %% Texture related
    % spatial
    tResoDeg = p.textureResolution;  % in degrees, should be integer multiplication of numDeg
    mResoDeg = p.mosaicResolution;   % in degrees, should be integer multiplication of numDeg
    tResoPx = round(tResoDeg/numDeg);
    mResoPx = round(mResoDeg/numDeg);
    tSize = ceil([sizeY,sizeX]/tResoPx); % the size of random matrices to be generated
    mSize = ceil([sizeY,sizeX]/mResoPx); 
    
    fBG   = p.fractionBackground; % 0~1, 1 = all background (moving), 0 = all foreground
    
    % intensity related
    cont = p.maxContrast;   % 0~1 - can be 2D if you want different contrasts for fore/backgorunds
    cS   = p.contrastSteps; % beaware of the bit depth
    
    % temporal
    dR   = p.velocities; % deg/s, 2D matrix
    fF   = p.flickerFrequency; % of foreground
    fPC  = min(60/fF*fPU,duration*2*fPU);
    
    % added feature
    if isfield(p,'isMirrored')
        isMirrored = p.isMirrored;
        if isempty(isMirrored); isMirrored = 1; end % in case another stimfunciton had a field with the same name
    else
        isMirrored = 0;
    end
    
    % create the mosaic pattern, fore/background textures
    % make matrices that are slightly larger than sizeX, sizeY and
    % crop them properly
    if f == 0
        bgMatOrig = cont(end)*((randi(cS,tSize)-1)/(cS-1)*2-1);
        mMatOrig = rand(mSize)<=fBG;
        bgMatExpanded = imresize(bgMatOrig,tResoPx,'box');
        mMatExpanded = imresize(mMatOrig,mResoPx,'box');
        bgPos = [0,0]; % position of background
        
        fgMatOrig = ((randi(cS,tSize)-1)/(cS-1)*2-1)*cont(1);
        fgMatExpanded = imresize(fgMatOrig,tResoPx,'box');
        
        mMat = mMatExpanded(1:sizeY,1:sizeX);
        % don't trim tMat here because it should be trimmed after moving it
        stimData.bgMatExpanded = bgMatExpanded;
        stimData.fgMatExpanded = fgMatExpanded;
        stimData.mMat = mMat;
        stimData.bgPos = bgPos;
    else
        bgMatExpanded = stimData.bgMatExpanded;
        fgMatExpanded = stimData.fgMatExpanded;
        mMat = stimData.mMat;
        bgPos = stimData.bgPos;
    end
      
    bitMap = zeros(sizeY,sizeX,fPU);     
    for cc = 0:1:fPU-1
        % move the background
        bgPos = bgPos + dR/60/fPU;
        temp1 = circshift(bgMatExpanded,round([bgPos(2),bgPos(1)]/numDeg));
        bg = temp1(1:sizeY,1:sizeX); % trimming
        % update the foreground
        if mod(f*fPU+cc,fPC)==0 && f+cc/fPU>0
            fgMatOrig = cont(1)*((randi(cS,tSize)-1)/(cS-1)*2-1);
            fgMatExpanded = imresize(fgMatOrig,tResoPx,'box');
            stimData.fgMatExpanded = fgMatExpanded;
        end
        fg = fgMatExpanded(1:sizeY,1:sizeX); % trimming
        % added feature
        if isMirrored == 1
            bg(:,(sizeX/2+1):end) = bg(:,(sizeX/2):-1:1);
        end
        % move mozaic matrix as well!
        shiftmMat = circshift(mMat,round([bgPos(2),bgPos(1)]/numDeg));
        
        bitMap(:,:,cc+1) = bg.*shiftmMat+fg.*(1-shiftmMat);
    end
    stimData.bgPos = bgPos;
    bitMap=mlum*(1+bitMap); % contrast to luminance conversion
    texStr.tex = CreateTexture(bitMap,Q);
end
