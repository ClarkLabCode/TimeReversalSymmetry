function [texStr,stimData] = MotionMosaicRandomUpdateInterocular(Q)

    % Created Aug 5 2020 by RT
    % (Wait... Two years have past since I made the original MMRU function?
    % Scarly how time flies!!)
    
    % Present combinations of stationary / flickering / translating checkers 
    % to each eye to test whether optomotor suppression is happening
    % locally within each hemisphere or it is coming through more central
    % mechanism

    % NOTE: when you create a new stimulus function, you must update the
    % stimlookup table in the folder paramfiles. paramfiles will also hold the
    % text file giving lists of parameters that comprise an experiment

    %% Stimulus Parameters %%  
    %% System stuffs
    p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
    f = Q.timing.framenumber - Q.timing.framelastchange; % relative frame number
    stimData = Q.stims.stimData;

    texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
    texStr.dim = 2; % or 2
    texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

    %% basics
    duration = p.duration;
    numDeg = p.numDeg;
    sizeX = round(360/numDeg);
    sizeY = round(2*atand(Q.cylinder.cylinderHeight/2/Q.cylinder.cylinderRadius)/numDeg);
    fPU = p.framesPerUp;
    mlum=p.mLum;

    %% Texture related
    % texture resolution is fixed to be the same across eyes 
    % because I am lazy
    % spatial
    tResoDeg = p.textureResolution;  % in degrees, should be integer multiplication of numDeg
    tResoPx = round(tResoDeg/numDeg);
    tSize = ceil([sizeY,sizeX]/tResoPx); % the size of random matrices to be generated
    
    % intensity related
    contR = p.maxContrastR;   % 0~1 - can be 2D if you want different contrasts for R/L
    cSR   = p.contrastStepsR; % beaware of the bit depth
    contL = p.maxContrastL;   % 0~1 - can be 2D if you want different contrasts for R/L
    cSL   = p.contrastStepsL; % beaware of the bit depth
    
    % temporal
    dRR   = p.velocitiesR; % deg/s, 2D matrix
    fFR   = p.flickerFrequencyR; % of foreground
    fPCR  = min(60/fFR*fPU,duration*2*fPU);
    
    dRL   = p.velocitiesL; % deg/s, 2D matrix
    fFL   = p.flickerFrequencyL; % of foreground
    fPCL  = min(60/fFL*fPU,duration*2*fPU);
    
    bufferW = p.bufferWidth; % in degrees
    
    % create two checkerboards
    if f == 0
        bgMatOrigR = contR(end)*((randi(cSR,tSize)-1)/(cSR-1)*2-1);
        bgMatOrigL = contL(end)*((randi(cSL,tSize)-1)/(cSL-1)*2-1);
        
        bgMatExpandedR = imresize(bgMatOrigR,tResoPx,'box');
        bgMatExpandedL = imresize(bgMatOrigL,tResoPx,'box');
        
        bgPos = [0,0; 0,0]; % position of Right/left patterns (in XY)
        
        % don't trim tMat here because it should be trimmed after moving it
        stimData.bgMatExpandedR = bgMatExpandedR;
        stimData.bgMatExpandedL = bgMatExpandedL;
        stimData.bgPos = bgPos;
    else
        bgMatExpandedR = stimData.bgMatExpandedR;
        bgMatExpandedL = stimData.bgMatExpandedL;
        bgPos = stimData.bgPos;
    end
      
    bitMap = zeros(sizeY,sizeX,fPU);  
    maskX = meshgrid(1:sizeX,1:sizeY)*numDeg;
    isL = maskX < 180-bufferW/2;
    isR = maskX > 180+bufferW/2;
    for cc = 0:1:fPU-1
        % move the position
        bgPos(1,:) = bgPos(1,:) + dRR/60/fPU; % R eye
        bgPos(2,:) = bgPos(2,:) + dRL/60/fPU; % L eye
        
        % update the patterns 
        if mod(f*fPU+cc,fPCR)==0 && f+cc/fPU>0 % R
            bgMatOrigR = contR(end)*((randi(cSR,tSize)-1)/(cSR-1)*2-1);
            bgMatExpandedR = imresize(bgMatOrigR,tResoPx,'box');
            stimData.bgMatExpandedR = bgMatExpandedR;
        end
        if mod(f*fPU+cc,fPCL)==0 && f+cc/fPU>0 % L
            bgMatOrigL = contL(end)*((randi(cSL,tSize)-1)/(cSL-1)*2-1);
            bgMatExpandedL = imresize(bgMatOrigL,tResoPx,'box');
            stimData.bgMatExpandedL = bgMatExpandedL;
        end
        
        % apply shift 
        bgR = circshift(bgMatExpandedR,round([bgPos(1,2),bgPos(1,1)]/numDeg));
        bgR = bgR(1:sizeY,1:sizeX); % trimming
        bgL = circshift(bgMatExpandedL,round([bgPos(2,2),bgPos(2,1)]/numDeg));
        bgL = bgL(1:sizeY,1:sizeX); % trimming
        
        % combine two patterns
        bitMap(:,:,cc+1) = isR.*bgR + isL.*bgL;
        
    end
    stimData.bgPos = bgPos;
    bitMap=mlum*(1+bitMap); % contrast to luminance conversion
    texStr.tex = CreateTexture(bitMap,Q);
end
