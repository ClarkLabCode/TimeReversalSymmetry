function [texStr,stimData] = SquareWave2SawtoothSpatialJitter(Q)
% this is to provide the general structure for the texture generating codes
% to be used with PTB in this framework.

% NOTE: when you create a new stimulus function, you must update the
% stimlookup table in the folder paramfiles. paramfiles will also hold the
% text file giving lists of parameters that comprise an experiment

%when choosing noise values for the sine wave make sure that:
%noiseContrast <= (1-mlum*(contrast+1))/(3*mlum)
%this insures that 3 std of the noise keeps you below a luminence of 1

sii = Q.stims.currStimNum;
p = Q.stims.currParam; % this is what we've got to work with in terms of parameters for this stimulus
f = Q.timing.framenumber - Q.timing.framelastchange + 1; % relative frame number
stimData = Q.stims.stimData;
floc = Q.flyloc; % could potentially use this to update the stimulus as well

texStr.opts = 'full'; % or 'rightleft','rightleftfront', etc. see drawTexture for deets
texStr.dim = 2; % or 2
texStr.scale = [1 1 1]; % using the different lengthscales appropriately.

numDeg = p.numDeg;

if numDeg == 0
    sizeX = 1;
else
    sizeX = round(360/numDeg);
end

lambda = p.lambda; % distance between new in radians
framesPerUp = p.framesPerUp;
contrast = p.contrast;
mlum=p.mlum;
jitterFreq=p.jitterFreqHz;
jitterStep=p.jitterStepDeg;

%% left eye

% create variable that represents one edge. repmat this to get the full
% bitmap
divisors=10.^[-2:.1:0.05];

if f == 1
    stimData.windowLoc = rand*lambda;
    stimData.polarity=p.polarity;
    stimData.idx=randi(length(divisors),1);
end

%bitMap = zeros(1,sizeX,framesPerUp);

polarity = stimData.polarity;
x=linspace(-90,90,360);
x=tanh(x*pi/90/divisors(stimData.idx));
x=x/x(1);
x=repmat(x,1,sizeX/lambda);
x=circshift(x,round(stimData.windowLoc));

pos1=x;
pos2=pos1+jitterStep;

numberOfFramesInPosition=60/jitterFreq;
numberOfFramesInPosition=round(numberOfFramesInPosition/framesPerUp);

if mod(f,2*numberOfFramesInPosition)<numberOfFramesInPosition
    for cc = 1:framesPerUp
        luminanceLevels = contrast*polarity*pos1;
        bitMap(:,:,cc) = luminanceLevels;
    end
else
    for cc = 1:framesPerUp
        luminanceLevels = contrast*polarity*pos2;
        bitMap(:,:,cc) = luminanceLevels;
    end
end
bitMap=mlum*(1+bitMap); % contrast to luminance conversion

%always include this line in a stim function to make the texture from the
%bitmap

texStr.tex = CreateTexture(bitMap,Q);
end
