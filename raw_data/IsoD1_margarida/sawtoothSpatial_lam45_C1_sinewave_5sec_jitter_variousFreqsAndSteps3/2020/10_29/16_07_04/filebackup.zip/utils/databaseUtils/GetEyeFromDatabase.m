function flyEye = GetEyeFromDatabase(pathString)

sysConfig = GetSystemConfiguration;
connDb = connectToDatabase(sysConfig.databasePathLocal, true);
if isempty(connDb)
    connDb = connectToDatabase(sysConfig.databasePathServer);
end

pathString(pathString=='\') = '/';
if strfind(pathString, sysConfig.twoPhotonDataPathLocal)
    relativeDataPath = pathString(length(sysConfig.twoPhotonDataPathLocal)+1:end);
elseif strfind(pathString, sysConfig.twoPhotonDataPathServer)
    relativeDataPath = pathString(length(sysConfig.twoPhotonDataPathServer)+1:end);
else
    relativeDataPath = pathString;
end
relativeDataPath(relativeDataPath=='/') = '\';

flyEye = fetch(connDb, sprintf('select eye from fly as f join stimulusPresentation as sP on f.flyId=sP.fly where sP.relativeDataPath like "%%%s%%"', relativeDataPath));
% flyEye = flyEye{1};